"""Boltgun VR portable launcher. Python 3.10+, Windows x64; GPL-3.0-or-later."""
from pathlib import Path
import argparse, ctypes, hashlib, json, os, shutil, subprocess, time, uuid

ROOT = Path(__file__).resolve().parent

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def verify():
    manifest = json.loads((ROOT / 'manifest.json').read_text(encoding='utf-8'))
    for rel, expected in manifest['files'].items():
        p = (ROOT / rel).resolve()
        if not p.is_relative_to(ROOT) or not p.is_file() or digest(p) != expected:
            raise RuntimeError('Package verification failed: ' + rel)
    return manifest

def atomic_json(path, data):
    temp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    temp.write_text(json.dumps(data, indent=2), encoding='utf-8')
    os.replace(temp, path)

class ProfileSession:
    """Move the existing profile aside, install a clean session, restore on exit.

    Recovery paths are stored before the first move. Game saves are never touched.
    """
    def __init__(self, profile, input_file, run):
        self.profile, self.input, self.run = map(Path, (profile, input_file, run))
        self.backup = self.profile.with_name(self.profile.name + '.backup-' + run.name)
        self.state = {'profile': str(self.profile), 'backup': str(self.backup),
                      'input': str(self.input), 'profile_existed': self.profile.exists(),
                      'input_existed': self.input.exists(), 'state': 'prepared'}

    def install(self, package):
        self.run.mkdir(parents=True, exist_ok=False)
        if self.input.exists():
            shutil.copy2(self.input, self.run / 'Input.ini.before')
        atomic_json(self.run / 'transaction.json', self.state)
        if self.profile.exists():
            if self.backup.exists():
                raise RuntimeError('Backup destination already exists')
            self.profile.rename(self.backup)
        self.state['state'] = 'profile-moved'
        atomic_json(self.run / 'transaction.json', self.state)
        shutil.copytree(package / 'payload', self.profile)
        self.input.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(package / 'game-config/Input.ini', self.input)
        self.state['state'] = 'installed'
        atomic_json(self.run / 'transaction.json', self.state)

    def restore(self):
        # Restore only after the owned game process has exited.
        if self.backup.exists() or not self.state['profile_existed']:
            if self.profile.exists():
                archive = self.run / 'session-profile'
                if archive.exists():
                    raise RuntimeError('Session archive already exists; inspect transaction')
                shutil.move(str(self.profile), str(archive))
            if self.backup.exists():
                self.backup.rename(self.profile)
        if self.state['input_existed']:
            shutil.copy2(self.run / 'Input.ini.before', self.input)
        elif self.input.exists() and self.state['state'] != 'prepared':
            self.input.unlink()
        self.state['state'] = 'restored'
        atomic_json(self.run / 'transaction.json', self.state)

def process_nonce(pid):
    from ctypes import wintypes
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel.OpenProcess.restype = wintypes.HANDLE
    kernel.GetProcessTimes.argtypes = [wintypes.HANDLE] + [ctypes.POINTER(wintypes.FILETIME)] * 4
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    handle = kernel.OpenProcess(0x1000, False, pid)
    if not handle:
        raise ctypes.WinError(ctypes.get_last_error())
    stamps = [wintypes.FILETIME() for _ in range(4)]
    try:
        if not kernel.GetProcessTimes(handle, *[ctypes.byref(x) for x in stamps]):
            raise ctypes.WinError(ctypes.get_last_error())
        created = (stamps[0].dwHighDateTime << 32) | stamps[0].dwLowDateTime
        return f'{pid}:{created + 504911232000000000}'
    finally:
        kernel.CloseHandle(handle)

def main():
    parser = argparse.ArgumentParser(description='Launch the accepted Boltgun VR v23 build with your own save.')
    parser.add_argument('--game', type=Path, help='Full path to Boltgun-Win64-Shipping.exe')
    parser.add_argument('--uevr', type=Path, help='Full path to UEVRInjector.exe, nightly 01143')
    parser.add_argument('--check', action='store_true', help='Verify package only; no game or installation')
    args = parser.parse_args()
    manifest = verify()
    if args.check:
        print('Package verified:', manifest['version'])
        return
    if os.name != 'nt':
        parser.error('Windows x64 is required')
    for name, expected in [('game', 'Boltgun-Win64-Shipping.exe'), ('uevr', 'UEVRInjector.exe')]:
        p = getattr(args, name)
        if p is None or not p.is_file() or p.name != expected:
            parser.error('--' + name + ' must point to ' + expected)
    if digest(args.game) != manifest['tested_game_sha256']:
        parser.error('This game build differs from the tested executable. See docs/RELEASE-NOTES.md.')
    backend = args.uevr.parent / 'UEVRBackend.dll'
    if not backend.is_file() or digest(backend) != manifest['tested_uevr_backend_sha256']:
        parser.error('Use the tested UEVR nightly 01143 build. See docs/INSTALL.md.')
    for image in ['Boltgun-Win64-Shipping.exe', 'UEVRInjector.exe']:
        running = subprocess.run(['tasklist', '/FI', 'IMAGENAME eq ' + image, '/FO', 'CSV', '/NH'], capture_output=True, text=True)
        if running.returncode or image.lower() in running.stdout.lower():
            parser.error('Close existing Boltgun and UEVRInjector processes before launching.')
    local = Path(os.environ['LOCALAPPDATA'])
    profile = Path(os.environ['APPDATA']) / 'UnrealVRMod/Boltgun-Win64-Shipping'
    input_file = local / 'Boltgun/Saved/Config/WindowsNoEditor/Input.ini'
    run = local / 'BoltgunVR/sessions' / (time.strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:8])
    # A kernel mutex covers all copies of this launcher for this Windows session.
    from ctypes import wintypes
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.CreateMutexW.argtypes = [ctypes.c_void_p, wintypes.BOOL, wintypes.LPCWSTR]
    kernel.CreateMutexW.restype = wintypes.HANDLE
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    lock = kernel.CreateMutexW(None, False, 'Local\\BoltgunVRLaunch')
    error = ctypes.get_last_error()
    if not lock or error == 183:
        if lock: kernel.CloseHandle(lock)
        parser.error('Another Boltgun VR launcher is active.')
    session = ProfileSession(profile, input_file, run)
    game = None
    print('Start your headset connection and SteamVR before continuing.')
    print('Session backup:', run)
    try:
        session.install(ROOT)
        env = dict(os.environ)
        layer = str(ROOT / 'runtime/exit-order')
        env['XR_API_LAYER_PATH'] = layer + (os.pathsep + env['XR_API_LAYER_PATH'] if env.get('XR_API_LAYER_PATH') else '')
        env['XR_ENABLE_API_LAYERS'] = 'XR_APILAYER_BOLT_exit_order' + (os.pathsep + env['XR_ENABLE_API_LAYERS'] if env.get('XR_ENABLE_API_LAYERS') else '')
        env.update(BOLT_XR_NONCE_FILE=str(profile/'data/labvisuals.session_nonce'),
                   BOLT_EXIT_TRACE=str(run/'exit-order.bin'), BOLT_EXIT_GUARD='1',
                   SteamAppId='2005010', SteamGameId='2005010')
        for key in ['BOLT_REPLAY_COMMAND','BOLT_REPLAY_LOG','BOLT_XR_CAPTURE_DIR','BOLT_XR_LOG']:
            env.pop(key, None)
        game = subprocess.Popen([str(args.game.resolve()), 'Boltgun', '-dx11', '-windowed', '-ResX=1280', '-ResY=720'], cwd=args.game.parent, env=env)
        (profile/'data/labvisuals.session_nonce').write_text(process_nonce(game.pid))
        if game.wait(timeout=15) is not None:
            raise RuntimeError('Game exited before injection')
    except subprocess.TimeoutExpired:
        try:
            subprocess.Popen([str(args.uevr.resolve()), '--attach=Boltgun-Win64-Shipping.exe'], cwd=args.uevr.parent)
            print('VR launch requested. Keep this window open until you exit Boltgun.')
        finally:
            while game.poll() is None:
                try: game.wait()
                except KeyboardInterrupt: print('Exit Boltgun normally to finish restoring the profile.')
    finally:
        if game is not None:
            while game.poll() is None:
                try: game.wait()
                except KeyboardInterrupt: print('Exit Boltgun normally to restore the profile.')
        if (run/'transaction.json').exists():
            session.restore()
            print('Previous VR profile and input settings restored. Your game progress is saved normally.')
        kernel.CloseHandle(lock)

if __name__ == '__main__':
    main()
