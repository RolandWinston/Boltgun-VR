// Process-owned VR ray -> existing Windows/Slate mouse route. GPL-3.0-or-later.
// No external command file, keyboard injection, or abstract menu activation.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <Xinput.h>
#include <atomic>
#include <bcrypt.h>
#include <uevr/API.h>
#include <filesystem>
#include <fstream>
#include <cstdio>
#include <cstring>
#include <cmath>
static const UEVR_PluginInitializeParam* api;
static std::filesystem::path root;
static DWORD engine_thread;static HWND window;static bool down,authorized;static ULONGLONG stamp;
static std::atomic<bool> session_ready{false},connected{false};static std::atomic<unsigned> maintained{0};
static unsigned events,presses,releases;static float lastx,lasty;
static bool own(HWND w){DWORD id=0;return w&&IsWindow(w)&&GetWindowThreadProcessId(w,&id)&&id==GetCurrentProcessId();}
static bool mouse_button(DWORD flag){INPUT i{};i.type=INPUT_MOUSE;i.mi.dwFlags=flag;return SendInput(1,&i,sizeof(i))==1;}
static void release(){if(down){mouse_button(MOUSEEVENTF_LEFTUP);++releases;}down=false;}
static void input(unsigned int* result,unsigned int index,void* raw){
 if(!authorized||!result||!raw||index!=api->vr->get_lowest_xinput_index())return;
 if(!connected&&!session_ready)return;
 if(*result==ERROR_SUCCESS){if(session_ready)connected=true;return;}
 if(connected){auto* state=(XINPUT_STATE*)raw;*state={};*result=ERROR_SUCCESS;++maintained;}
}
static void event(const char* name,const char* data){
 if(!authorized||GetCurrentThreadId()!=engine_thread||!name||strcmp(name,"boltgun.controller.pointer.v1")||!data)return;
 if(!strcmp(data,"off")){release();stamp=0;return;}
 auto w=GetForegroundWindow();if(!own(w)){release();return;}
 float x,y;int pressed;char extra;
 if(sscanf(data,"%f|%f|%d%c",&x,&y,&pressed,&extra)!=3||!std::isfinite(x)||!std::isfinite(y)||x<0||x>1||y<0||y>1||(pressed!=0&&pressed!=1)){release();return;}
 RECT r{};if(!GetClientRect(w,&r)||r.right<=0||r.bottom<=0){release();return;}
 if(window!=w){release();window=w;}
 lastx=x*(r.right-1);lasty=y*(r.bottom-1);POINT point{(LONG)lastx,(LONG)lasty};
 if(!ClientToScreen(w,&point)){release();return;}
 // Only the focused game cursor moves, while a fresh controller ray hits its menu.
 SetCursorPos(point.x,point.y);
 if(pressed&&!down){if(mouse_button(MOUSEEVENTF_LEFTDOWN)){down=true;++presses;}}
 else if(!pressed)release();
 stamp=GetTickCount64();++events;
}
static void tick(UEVR_UGameEngineHandle,float){engine_thread=GetCurrentThreadId();session_ready=api->vr->is_runtime_ready();if(down&&(!stamp||GetTickCount64()-stamp>100||!own(GetForegroundWindow())))release();}
#include "binding_snapshot.hpp"
static void post(UEVR_UGameEngineHandle,float){
 static ULONGLONG last;auto now=GetTickCount64();if(now-last<500)return;last=now;binding_snapshot();
 std::ofstream f(root/L"data/boltgun-pointer-status.json");f<<"{\"maintained\":"<<maintained.load()<<",\"connected\":"<<(connected?"true":"false")<<",\"events\":"<<events<<",\"presses\":"<<presses<<",\"releases\":"<<releases<<",\"down\":"<<(down?"true":"false")<<",\"x\":"<<lastx<<",\"y\":"<<lasty<<",\"source\":\"production-controller-ray\"}";
}
static bool supported_file(const wchar_t* path) {
    const unsigned char expected[]={0xbd,0x32,0xae,0xcb,0x2e,0xf6,0xfe,0xb3,
        0xfd,0x2e,0xdf,0xb0,0x09,0x5b,0x7e,0x53,0x41,0x76,0xc9,0x2c,0x01,0xd5,0xfa,0x5c,
        0xcc,0x43,0xa0,0xdd,0xc6,0x39,0xb0,0x1a};
    FILE* file{};if(_wfopen_s(&file,path,L"rb")!=0) return false;
    BCRYPT_ALG_HANDLE alg{};BCRYPT_HASH_HANDLE hash{};unsigned char digest[32]{},buffer[65536];
    bool ok=BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,nullptr,0)>=0&&
            BCryptCreateHash(alg,&hash,nullptr,0,nullptr,0,0)>=0;
    while(ok) {
        const size_t count=std::fread(buffer,1,sizeof(buffer),file);
        if(count==0) break;
        ok=BCryptHashData(hash,buffer,static_cast<ULONG>(count),0)>=0;
    }
    ok=ok&&!std::ferror(file)&&BCryptFinishHash(hash,digest,sizeof(digest),0)>=0;
    if(hash) BCryptDestroyHash(hash);if(alg) BCryptCloseAlgorithmProvider(alg,0);std::fclose(file);
    return ok&&std::memcmp(expected,digest,sizeof(expected))==0;
}

extern "C" __declspec(dllexport) void uevr_plugin_required_version(UEVR_PluginVersion*v){if(v)*v={2,39,0};}
extern "C" __declspec(dllexport) bool uevr_plugin_initialize(const UEVR_PluginInitializeParam*p){
 if(!p||!p->version||p->version->major!=2||p->version->minor<39||!p->sdk||!p->vr||!p->callbacks||!p->functions)return false;api=p;
 wchar_t path[32768]{},dir[32768]{};if(!GetModuleFileNameW(nullptr,path,32768)||!supported_file(path))return true;
 api->functions->get_persistent_dir(dir,32768);root=dir;
 FILETIME born{},end{},kernel{},user{};if(!GetProcessTimes(GetCurrentProcess(),&born,&end,&kernel,&user))return true;
 ULARGE_INTEGER t{};t.LowPart=born.dwLowDateTime;t.HighPart=born.dwHighDateTime;
 std::ifstream file(root/L"data/labvisuals.session_nonce");unsigned long long pid{},time{};char colon{};file>>pid>>colon>>time;
 if(!file||colon!=':'||pid!=GetCurrentProcessId()||time!=t.QuadPart+504911232000000000ull)return true;
 authorized=true;api->sdk->callbacks->on_pre_engine_tick(tick);api->sdk->callbacks->on_post_engine_tick(post);api->callbacks->on_custom_event(event);api->callbacks->on_xinput_get_state(input);
 api->functions->log_info("[Boltgun controller pointer] exact executable and process verified");return true;
}
