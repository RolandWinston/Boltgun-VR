// Read-only, reflected InputSettings array snapshot for the fixed UE4 executable.
#include <sstream>
#include <string>
struct BindingArray{unsigned char* data;int count,capacity;};
static std::string binding_name(void* p){wchar_t w[256]{};api->sdk->fname->to_string((UEVR_FNameHandle)p,w,256);std::string out;for(auto x:w){if(!x)break;if(!((x>='A'&&x<='Z')||(x>='a'&&x<='z')||(x>='0'&&x<='9')||x=='_'))return {};out+=(char)x;}return out;}
static bool readable(const void* p,size_t n){MEMORY_BASIC_INFORMATION m{};return p&&n&&VirtualQuery(p,&m,sizeof(m))==sizeof(m)&&m.State==MEM_COMMIT&&!(m.Protect&(PAGE_GUARD|PAGE_NOACCESS))&&(uintptr_t)p+n<=(uintptr_t)m.BaseAddress+m.RegionSize;}
static void binding_snapshot(){
 static unsigned sequence=0;auto s=api->sdk;std::string error;std::ostringstream body;
 do{
 auto cls=s->uobject_array->find_uobject(L"Class /Script/Engine.InputSettings");if(!cls){error="InputSettings class";break;}
 auto o=s->uclass->get_class_default_object((UEVR_UClassHandle)cls);auto prop=s->ustruct->find_property((UEVR_UStructHandle)cls,L"ActionMappings");
 if(!o||!prop){error="ActionMappings property";break;}
 auto inner=s->farrayproperty->get_inner((UEVR_FArrayPropertyHandle)prop);if(!inner){error="ActionMappings inner";break;}
 auto desc=s->fstructproperty->get_struct((UEVR_FStructPropertyHandle)inner);if(!desc){error="ActionMappings struct";break;}
 int size=s->uscriptstruct->get_struct_size(desc);auto action=s->ustruct->find_property((UEVR_UStructHandle)desc,L"ActionName");auto key=s->ustruct->find_property((UEVR_UStructHandle)desc,L"Key");
 if(size<16||size>256||!action||!key){error="Input mapping layout";break;}
 auto keydesc=s->fstructproperty->get_struct((UEVR_FStructPropertyHandle)key);auto keyname=s->ustruct->find_property((UEVR_UStructHandle)keydesc,L"KeyName");if(!keyname){error="KeyName layout";break;}
 int ao=s->fproperty->get_offset(action),ko=s->fproperty->get_offset(key)+s->fproperty->get_offset(keyname);if(ao<0||ko<0||ao+8>size||ko+8>size){error="Name offsets";break;}
 auto array=(BindingArray*)s->uobject->get_property_data(o,L"ActionMappings");if(!readable(array,sizeof(*array))||array->count<0||array->count>1024||array->capacity<array->count||array->capacity>4096||(array->count&&!readable(array->data,(size_t)array->count*size))){error="Array bounds";break;}
 bool first=true;body<<"[";
 for(int i=0;i<array->count;++i){auto row=array->data+i*size;auto a=binding_name(row+ao),k=binding_name(row+ko);if(a.empty()||k.rfind("Gamepad_",0)!=0)continue;
 if(!first)body<<",";first=false;body<<"{\"action\":\""<<a<<"\",\"key\":\""<<k<<"\"";
 for(auto field:{L"bShift",L"bCtrl",L"bAlt",L"bCmd"}){auto fp=s->ustruct->find_property((UEVR_UStructHandle)desc,field);if(!fp){error="Modifier layout";break;}bool value=s->fboolproperty->get_value_from_object((UEVR_FBoolPropertyHandle)fp,row);std::string f;for(auto t=field;*t;++t)f+=(char)*t;body<<",\""<<f<<"\":"<<(value?"true":"false");}body<<"}";
 }body<<"]";
 }while(false);
 auto dest=root/L"data/boltgun-input-bindings.json",tmp=root/L"data/boltgun-input-bindings.tmp";std::ofstream f(tmp);f<<"{\"version\":1,\"sequence\":"<<++sequence<<",\"pid\":"<<GetCurrentProcessId()<<",\"ready\":"<<(error.empty()?"true":"false")<<",\"error\":\""<<error<<"\",\"rows\":"<<(error.empty()?body.str():"[]")<<"}";
 f.close();MoveFileExW(tmp.c_str(),dest.c_str(),MOVEFILE_REPLACE_EXISTING);
}
