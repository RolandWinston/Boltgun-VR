import bpy, math, struct, json, hashlib, sys
from pathlib import Path
from mathutils import Vector

D=Path(__file__).resolve().parent
OUT=D/'models';OUT.mkdir(exist_ok=True)
BASE=D.parent/'payload/data/labvisuals'
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
sc=bpy.context.scene;sc.unit_settings.system='METRIC';sc.unit_settings.scale_length=.01
atlas=bpy.data.images.load(str(BASE/'lab-visual-atlas.png'));atlas.pack()
# Exact palette sample points selected from the existing atlas; accepted assets and texture stay unchanged.
palette=json.loads((D/'palette.json').read_text())
mats={}
for key,entry in palette.items():
 m=bpy.data.materials.new(key);m.use_nodes=True
 t=m.node_tree.nodes.new('ShaderNodeTexImage');t.image=atlas;t.interpolation='Closest'
 bs=m.node_tree.nodes.get('Principled BSDF');m.node_tree.links.new(t.outputs['Color'],bs.inputs['Base Color']);bs.inputs['Roughness'].default_value=.8;bs.inputs['Metallic'].default_value=.1
 mats[key]=m
parts=[]
def finish(o,name,color):
 o.name=name;o.data.materials.append(mats[color]);uv=o.data.uv_layers.active or o.data.uv_layers.new(name='Palette');uv.name='Palette'
 u,v=palette[color]['uv']
 for p in uv.data:p.uv=(u,1-v)
 parts.append(o);return o
def box(name,p,size,color='steel',bevel=.25,rot=0):
 bpy.ops.mesh.primitive_cube_add(size=1,location=p);o=bpy.context.object;o.dimensions=size;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 if bevel and min(size)>=2.1:
  m=o.modifiers.new('single chamfer','BEVEL');m.width=min(bevel,min(size)*.23);m.segments=1;bpy.ops.object.modifier_apply(modifier=m.name)
 o.rotation_euler.y=rot;o['convex_solid']=True;return finish(o,name,color)
def cyl(name,p,r,length,color='steel',axis='x',n=10):
 bpy.ops.mesh.primitive_cylinder_add(vertices=n,radius=r,depth=length,location=p,rotation=(0,math.pi/2,0)if axis=='x'else(math.pi/2,0,0)if axis=='y'else(0,0,0))
 o=bpy.context.object;bpy.ops.object.transform_apply(location=False,rotation=True,scale=True);o['convex_solid']=True;return finish(o,name,color)
def pipe(name,p1,p2,r,color='dark',n=8):
 delta=Vector(p2)-Vector(p1);mid=(Vector(p1)+Vector(p2))*.5
 bpy.ops.mesh.primitive_cylinder_add(vertices=n,radius=r,depth=delta.length,location=mid)
 o=bpy.context.object;o.rotation_euler=delta.to_track_quat('Z','Y').to_euler();bpy.ops.object.transform_apply(location=False,rotation=True,scale=True);o['convex_solid']=True;return finish(o,name,color)
def ring(name,x,y,z,r,inner,length,color='brass',n=10):
 vs=[]
 for xx in (x-length/2,x+length/2):
  for rr in (r,inner):
   for j in range(n):a=2*math.pi*j/n;vs.append((xx,y+rr*math.cos(a),z+rr*math.sin(a)))
 faces=[]
 for j in range(n):
  k=(j+1)%n
  faces.extend([(j,k,2*n+k,2*n+j),(n+k,n+j,3*n+j,3*n+k),(j,n+j,n+k,k),(2*n+k,3*n+k,3*n+j,2*n+j)])
 me=bpy.data.meshes.new(name);me.from_pydata(vs,[],faces);me.update();o=bpy.data.objects.new(name,me);sc.collection.objects.link(o);return finish(o,name,color)
def common():
 box('palm anchored grip',(9,-1.8,0),(4,4.4,12),'dark',.35)
 box('upper grip collar',(10,-1.4,6.7),(6.8,6.1,3),'steel')
 box('guard bottom',(13,-1.8,-4.5),(8.5,5.4,1.3),'steel',.1)
 box('guard front',(16.7,-1.8,1.1),(1.3,5.0,11.8),'steel',.1)
 box('trigger',(12.8,-1.8,1),(1,1.2,4),'dark',.1,rot=-.25)
 for z in (-3,0,3):box('grip checkering',(6.9,-1.8,z),(.28,4.3,.6),'grip_light',0)
def panel(x,width,bodyw,z=13,color='red'):
 for sign in (-1,1):
  y=-.36+sign*(bodyw/2+.08)
  box('armour side panel',(x,y,z),(width,.5,6.7),color,.25)
  for xx in (x-width/2+1,x+width/2-1):
   for zz in (z-2.3,z+2.3):cyl('panel fastener',(xx,y+sign*.35,zz),.38,.28,'steel_light','y',6)
def vents(x,bodyw,z=15,count=4):
 for sign in (-1,1):
  for i in range(count):box('recessed heat vent',(x+i*2.1,-.36+sign*(bodyw/2+.42),z),(1.1,.18,3.8),'dark',.07)
def marks(x,bodyw,z=12):
 for sign in (-1,1):
  y=-.36+sign*(bodyw/2+.51)
  box('chapter plate',(x,y,z),(5,.28,3.7),'dark',.15)
  for dx in (-.65,.65):box('unit II',(x+dx,y+sign*.17,z),(.55,.16,2.2),'bone',.02)
def sights(front=44,top=20):
 box('rear sight support',(11,-.36,top-1),(3,5,2.4),'dark')
 for y in (-2.2,1.48):box('rear sight ears',(11,y,top+1),(2,1.1,2),'steel',.1)
 box('front sight bridge',(front,-.36,top-1.8),(3,4,3.6),'dark',.2)
 box('front sight blade',(front,-.36,top+.4),(1.2,.9,1.3),'steel_light',.08)
def muzzle(x=48.3,r=3.4,inner=2.1,color='steel'):
 ring('hollow muzzle',x,-.36,12.8,r,inner,3,color)
 cyl('deep bore',(x-2.5,-.36,12.8),inner*.99,.1,'dark')
def shoulder(x=4,bodyw=9,z=13):box('rear armoured cap',(x,-.36,z),(4,bodyw+1,9),'dark',.65)

ids=['Shotgun','Plasmagun','HeavyBolter','Meltagun','VolkiteCaliver','VengeanceLauncher','Gravgun','MultiMelta','MissileLauncher']
reports=[]
for index,id in enumerate(ids):
 parts=[];common()
 if id=='Shotgun':
  box('shotgun receiver',(17,-.36,12.8),(23,8.5,9),'steel',.7);shoulder(4,8)
  box('receiver top rail',(19,-.36,18),(27,5,1.5),'dark')
  panel(16,17,8.5,color='gunmetal');marks(13,8.5)
  box('ejection port',(23,-4.9,13.7),(5,.4,2.4),'dark',.2);box('ejection brass',(23,-5.15,13.7),(3.2,.15,1.1),'brass',.1)
  cyl('shot barrel',(36,-.36,12.8),2.5,23,'gunmetal');cyl('lower magazine tube',(34,-.36,7.6),1.7,24,'steel')
  box('pump foregrip',(32,-.36,7.2),(13,6.5,5),'dark',.55)
  for x in range(27,38,2):box('pump ridge',(x,-.36,7.2),(.65,6.8,5.1),'grip_light',.1)
  ring('barrel collar',41,-.36,12.8,3.1,2.6,2,'steel');muzzle(r=2.8,inner=1.7);sights(43,17.2)
 elif id=='Plasmagun':
  box('plasma armoured receiver',(20,-.36,11.8),(30,11.5,11),'red_dark',.9);shoulder(4,10)
  panel(19,23,11.5,color='red');marks(14,11.5,11.7)
  box('plasma coil channel',(30,-.36,16.5),(25,8,5),'dark',.5)
  cyl('exposed plasma core',(30,-.36,18),3.7,22,'energy')
  for x in range(20,42,3):ring('cooling coil',x,-.36,18,4.4,3.7,.8,'steel')
  box('emitter armour',(44,-.36,12.8),(8,10,9),'gunmetal',1.0);muzzle(r=4,inner=2.3)
  cyl('plasma bore light',(46,-.36,12.8),2,.12,'energy');vents(23,11.5,10.5,4)
 elif id=='HeavyBolter':
  box('heavy armoured core',(22,-.36,13),(32,16,14),'red_dark',1);shoulder(4,15)
  panel(22,24,16,color='red');marks(14,16)
  box('magazine housing',(22,-.36,1),(11,12,14),'dark',.7);box('magazine base',(22,-.36,-5.9),(12,13,2),'steel')
  for x in (18,21,24,27):box('magazine stamp',(x,-6.5,0),(.65,.45,10),'gunmetal',.1)
  cyl('reinforced barrel',(42,-.36,12.8),3.5,11,'dark');ring('vented barrel shield',42,-.36,12.8,4.8,3.6,7,'steel');muzzle(r=4.7,inner=2.7)
  for xx in (15,29):box('carry handle riser',(xx,-.36,23),(1.6,3.0,7),'dark')
  box('carry handle grip',(22,-.36,26),(16,3.5,2),'steel');vents(23,16,16,5)
 elif id in ('Meltagun','MultiMelta'):
  multi=id=='MultiMelta';w=17 if multi else 12
  box('heat resistant core',(20,-.36,12),(29,w,12),'dark',.9);shoulder(4,w-1)
  panel(19,23,w,color='red');marks(13,w);vents(22,w,14,4)
  box('upper stepped heat shield',(27,-.36,19),(22,w-2,2.5),'red_dark',.6)
  for y in ([-4.6,3.88]if multi else[-.36]):
   cyl('melta shroud',(40,y,12.8),4.5,12,'brass_dark')
   for x in (35,39,43):ring('heat sink ring',x,y,12.8,4.9,4.5,1,'gunmetal')
   ring('melta hollow muzzle',47.4,y,12.8,4.8,3,4.8,'brass')
   cyl('deep hot bore',(44.7,y,12.8),2.9,.2,'dark')
   for a in range(0,360,90):
    rad=math.radians(a);box('nozzle heat slot',(46.6,y+4.72*math.cos(rad),12.8+4.72*math.sin(rad)),(2.2,.55,.55),'dark',.08)
  cyl('fuel canister',(21,-w/2-3.1,5),3.1,12,'gunmetal')
  for x in (16.4,25.6):ring('canister strap',x,-w/2-3.1,5,3.35,3.1,1,'brass_dark')
  pipe('fuel hose rear',(15,-w/2-3,5),(10,-w/2-2.4,7),.9)
  pipe('fuel hose to receiver',(10,-w/2-2.4,7),(11,-w/2,11),.9)
  sights(30,21)
 elif id=='VolkiteCaliver':
  box('volkite receiver',(17,-.36,12),(25,10.5,11),'red_dark',.75);shoulder(3,10)
  panel(17,19,10.5);marks(12,10.5)
  cyl('coil spine',(35,-.36,12.8),2.7,23,'dark')
  for x in range(26,45,3):ring('volkite ring',x,-.36,12.8,4.2,2.7,1.5,'brass_dark'if x%2 else'brass')
  box('top coil brace',(35,-.36,17.7),(25,2.6,1.6),'steel')
  box('lower coil brace',(34,-.36,8),(23,2.6,1.5),'dark');muzzle(r=3.7,inner=2.2,color='brass');sights(42,19)
 elif id=='VengeanceLauncher':
  box('launcher receiver',(20,-.36,15),(28,12,11),'blue_dark',.8);panel(18,22,12,z=15,color='blue');marks(14,12,15)
  cyl('grenade drum',(24,-.36,4),9.1,12,'dark','y',12)
  for y in (-6.6,5.9):cyl('drum cheek',(24,y,4),8.6,.8,'steel','y',12)
  for a in range(0,360,60):
   rad=math.radians(a);cyl('drum chamber',(24+6*math.cos(rad),-7.1,4+6*math.sin(rad)),1.7,.4,'dark','y',8)
  cyl('drum axle',(24,-7.4,4),2.4,.7,'brass_dark','y',8)
  cyl('launcher barrel',(41,-.36,12.8),4.7,12,'gunmetal');muzzle(r=5.2,inner=3.8);sights(43,20)
 elif id=='Gravgun':
  box('gravity generator',(19,-.36,12),(26,13,12),'blue_dark',.85);panel(18,20,13,color='blue');marks(13,13)
  cyl('gravity cage',(34,-.36,12.8),5.3,13,'gunmetal');cyl('gravity energy core',(40,-.36,12.8),3,15,'energy')
  for x in (30,35,40):ring('field collar',x,-.36,12.8,5.6,3.1,1.1,'steel')
  for a in (0,120,240):
   rad=math.radians(a);y=-.36+5.7*math.cos(rad);z=12.8+5.7*math.sin(rad)
   box('field prong',(43,y,z),(13,2,2),'brass_dark',.4);box('prong tip',(48,y,z),(2.6,2.3,2.3),'steel',.3)
 elif id=='MissileLauncher':
  cyl('missile tube',(25,-.36,13),6.2,44,'dark',n=12)
  for x in (5,18,42,47):ring('launch tube clamp',x,-.36,13,6.8,6.2,2,'steel',12)
  ring('open front',47.6,-.36,13,7,5.1,4.4,'gunmetal',12);cyl('dark tube interior',(43,-.36,13),5,.2,'dark')
  box('top red armour',(25,-.36,19),(27,8,3),'red_dark',.7);panel(24,22,9,z=16.5,color='red')
  box('optical sight housing',(21,-8,18),(11,4,4),'dark',.5);cyl('scope lens',(27,-8,18),1.3,.2,'energy')
 bpy.context.view_layer.update()
 vertices=[];indices=[];lookup={};discarded=0;buried=0
 # Remove only triangles fully inside another known convex solid. Ring cavities
 # are excluded, and all corners must be strictly inside each outward face plane.
 # Convexity makes this proof apply to the entire triangle, not sampled centres.
 solids=[]
 for solid in parts:
  if not solid.get('convex_solid'):continue
  sm=solid.matrix_world;sn=sm.to_3x3().inverted().transposed();world=[sm@v.co for v in solid.data.vertices]
  bounds=([min(p[k]for p in world)for k in range(3)],[max(p[k]for p in world)for k in range(3)])
  planes=[(world[f.vertices[0]],(sn@f.normal).normalized())for f in solid.data.polygons]
  assert all(all((point-origin).dot(normal)<1e-4 for origin,normal in planes)for point in world),'Occluder must be convex with outward normals'
  solids.append((solid,bounds,planes))
 for ob in parts:
  me=ob.data;me.calc_loop_triangles();mat=ob.matrix_world;normal=mat.to_3x3().inverted().transposed();uv=me.uv_layers.active.data
  for tri in me.loop_triangles:
   ps=[mat@me.vertices[me.loops[li].vertex_index].co for li in tri.loops]
   if (ps[1]-ps[0]).cross(ps[2]-ps[0]).length<1e-5:discarded+=1;continue
   hidden=False
   low=[min(p[k]for p in ps)for k in range(3)];high=[max(p[k]for p in ps)for k in range(3)]
   for other,(lower,upper),planes in solids:
    if other==ob or any(low[k]<=lower[k]+1e-4 or high[k]>=upper[k]-1e-4 for k in range(3)):continue
    if all(all((p-origin).dot(n)<-1e-4 for origin,n in planes)for p in ps):hidden=True;break
   if hidden:buried+=1;continue
   face=[]
   for li in tri.loops:
    p=mat@me.vertices[me.loops[li].vertex_index].co;n=(normal@tri.normal).normalized();t=uv[li].uv
    row=tuple(round(v,6)for v in (*p,*n,t.x,1-t.y))
    if row not in lookup:lookup[row]=len(vertices);vertices.append(row)
    face.append(lookup[row])
   indices.extend(face+list(reversed(face)))
 assert vertices and all(math.isfinite(v)for row in vertices for v in row)
 raw=b'BGCHAIN1'+struct.pack('<III',1,len(vertices),len(indices))+b''.join(struct.pack('<8f',*r)for r in vertices)+struct.pack('<'+'I'*len(indices),*indices)
 (OUT/(id+'.bgmesh')).write_bytes(raw)
 lo=[min(v[k]for v in vertices)for k in range(3)];hi=[max(v[k]for v in vertices)for k in range(3)]
 reports.append({'id':id,'vertices':len(vertices),'triangles':len(indices)//3,'unique_visible_triangles':len(indices)//6,'discarded_degenerate':discarded,'removed_buried_triangles':buried,'small_chamfer_minimum':2.1,'bounds':[lo,hi],'anchor':[9,-1.8,0],'muzzle':[49.8,-.36,12.8],'sha256':hashlib.sha256(raw).hexdigest(),'source':'authored Blender low-poly geometry; unchanged existing atlas sampled as palette; official illustrations used as visual reference only'})
 root=bpy.data.objects.new(id,None);sc.collection.objects.link(root)
 for ob in parts:ob.parent=root
 root.location=(index%3*70,index//3*60,0)
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'polished-weapons.blend'))
(OUT/'mesh-report.json').write_text(json.dumps(reports,indent=2))
print('EXPORTED',[(r['id'],r['vertices'],r['triangles'])for r in reports])
