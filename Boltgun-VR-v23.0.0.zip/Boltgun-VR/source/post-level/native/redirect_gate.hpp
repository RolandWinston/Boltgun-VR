#pragma once
#include <cstdint>
namespace boltgun {
enum class RedirectReason { Ready, NoBaseline, WeaponMismatch, InvalidLease, NotForeground, HeartbeatFuture, HeartbeatStale, NoRenderedPose, RenderedPoseFuture, RenderedPoseStale, NoRenderedFrame, RenderedFrameFuture, RenderedFrameSkipped, RenderContinuityChanged, InvalidMuzzle };
struct RedirectGate { bool has_baseline{},weapon_matches{},lease_valid{},foreground{};std::uint64_t now{},heartbeat{},captured{}; };
inline RedirectReason classify_redirect(const RedirectGate& g){
 if(!g.has_baseline)return RedirectReason::NoBaseline;
 if(!g.weapon_matches)return RedirectReason::WeaponMismatch;
 if(!g.lease_valid)return RedirectReason::InvalidLease;
 if(!g.foreground)return RedirectReason::NotForeground;
 if(g.now<g.heartbeat)return RedirectReason::HeartbeatFuture;
 if(g.now-g.heartbeat>75)return RedirectReason::HeartbeatStale;
 if(!g.captured)return RedirectReason::NoRenderedPose;
 if(g.now<g.captured)return RedirectReason::RenderedPoseFuture;
 if(g.now-g.captured>75)return RedirectReason::RenderedPoseStale;
 return RedirectReason::Ready;
}
inline const char* redirect_reason_name(RedirectReason r){
 switch(r){
 case RedirectReason::Ready:return "redirected";
 case RedirectReason::NoBaseline:return "no_baseline";
 case RedirectReason::WeaponMismatch:return "weapon_mismatch";
 case RedirectReason::InvalidLease:return "invalid_lease";
 case RedirectReason::NotForeground:return "not_foreground";
 case RedirectReason::HeartbeatFuture:return "heartbeat_future";
 case RedirectReason::HeartbeatStale:return "heartbeat_stale";
 case RedirectReason::NoRenderedPose:return "no_rendered_pose";
 case RedirectReason::RenderedPoseFuture:return "rendered_pose_future";
 case RedirectReason::RenderedPoseStale:return "rendered_pose_stale";
 case RedirectReason::NoRenderedFrame:return "no_rendered_frame";
 case RedirectReason::RenderedFrameFuture:return "rendered_frame_future";
 case RedirectReason::RenderedFrameSkipped:return "rendered_frame_skipped";
 case RedirectReason::RenderContinuityChanged:return "render_continuity_changed";
 case RedirectReason::InvalidMuzzle:return "invalid_muzzle_transform";
 }
 return "invalid_reason";
}
}
