#pragma once
#include "muzzle_math.hpp"
namespace boltgun {
inline Vec3 grav_beam_owner_origin(Vec3 muzzle,Quat owner_rotation){
 const auto authored=rotate(owner_rotation,{-8.f,8.f,-5.f});
 return {muzzle.x-authored.x,muzzle.y-authored.y,muzzle.z-authored.z};
}
}
