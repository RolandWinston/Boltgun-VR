#include "frame_redirect_gate.hpp"
#include <cassert>
#include <cstdio>
using namespace boltgun;
int main(){
 RedirectGate a{true,true,true,true,6445718,6445703,6445640};
 assert(classify_redirect(a)==RedirectReason::RenderedPoseStale);
 assert(classify_frame_redirect(a,1672,1671,true)==RedirectReason::Ready);
 RedirectGate b{true,true,true,true,6445843,6445812,6445765};
 assert(classify_redirect(b)==RedirectReason::RenderedPoseStale);
 assert(classify_frame_redirect(b,1675,1674,true)==RedirectReason::Ready);
 assert(classify_frame_redirect(a,1673,1671,true)==RedirectReason::RenderedFrameSkipped);
 assert(classify_frame_redirect(a,1670,1671,true)==RedirectReason::RenderedFrameFuture);
 assert(classify_frame_redirect(a,1672,0,true)==RedirectReason::NoRenderedFrame);
 assert(classify_frame_redirect(a,0,1671,true)==RedirectReason::NoRenderedFrame);
 assert(classify_frame_redirect(a,1672,1671,false)==RedirectReason::RenderContinuityChanged);
 auto g=a;g.heartbeat=g.now-76;assert(classify_frame_redirect(g,1672,1671,true)==RedirectReason::HeartbeatStale);
 g=a;g.heartbeat=g.now+1;assert(classify_frame_redirect(g,1672,1671,true)==RedirectReason::HeartbeatFuture);
 g=a;g.captured=g.now+1;assert(classify_frame_redirect(g,1672,1671,true)==RedirectReason::RenderedPoseFuture);
 g=a;g.captured=0;assert(classify_frame_redirect(g,1672,1671,true)==RedirectReason::NoRenderedPose);
 g=a;g.lease_valid=false;assert(classify_frame_redirect(g,1672,1671,true)==RedirectReason::InvalidLease);
 g=a;g.weapon_matches=false;assert(classify_frame_redirect(g,1672,1671,true)==RedirectReason::WeaponMismatch);
 g=a;g.foreground=false;assert(classify_frame_redirect(g,1672,1671,true)==RedirectReason::NotForeground);
 g=a;g.has_baseline=false;assert(classify_frame_redirect(g,1672,1671,true)==RedirectReason::NoBaseline);
 g=a;g.heartbeat=g.now-75;assert(classify_frame_redirect(g,1672,1671,true)==RedirectReason::Ready);
 g=a;g.captured=g.now;assert(classify_frame_redirect(g,1672,1672,true)==RedirectReason::Ready);
 std::puts("{\"boundary_cases\":19,\"passed\":true,\"game_test\":false}");
}
