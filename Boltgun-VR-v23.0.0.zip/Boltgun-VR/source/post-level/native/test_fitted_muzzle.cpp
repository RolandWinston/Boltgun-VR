#include "muzzle_math.hpp"
#include "weapon_fit_landmarks.hpp"
#include <cassert>
#include <cstdio>
using namespace boltgun;
int main(){Transform t{{0,0,0,1},{100,200,300},0,{1,1,1},0},base=t,out{};assert(muzzle_transform(t,kFittedMuzzle,base,base,out));assert(std::fabs(out.translation.x-149.8f)<.0001f);assert(std::fabs(out.translation.y-199.64f)<.0001f);assert(std::fabs(out.translation.z-312.8f)<.0001f);assert(std::fabs(out.translation.x-160.f)>10.f);assert(out.rotation.w==1);std::puts("fitted muzzle at actual exported point; old muzzle rejected");}
