#pragma once
#include "redirect_gate.hpp"
namespace boltgun {
// Keep independent live tracking/ownership gates. A shown mesh is identified by
// the render it belongs to, not by assigning a new timestamp on a direct read.
// The only old condition replaced is the display cache's arbitrary75ms cutoff.
inline RedirectReason classify_frame_redirect(const RedirectGate& g,
 std::uint64_t engine_frame,std::uint64_t captured_frame,bool same_continuity) {
 const auto old=classify_redirect(g);
 if(old!=RedirectReason::Ready && old!=RedirectReason::RenderedPoseStale)return old;
 if(!same_continuity)return RedirectReason::RenderContinuityChanged;
 if(!engine_frame||!captured_frame)return RedirectReason::NoRenderedFrame;
 if(captured_frame>engine_frame)return RedirectReason::RenderedFrameFuture;
 if(engine_frame-captured_frame>1)return RedirectReason::RenderedFrameSkipped;
 return RedirectReason::Ready;
}
}
