#pragma once
#include <cstdint>
namespace boltgun {
// Read the actual displayed component when its owned lease remains valid.
// Freshness authorizes firing separately in classify_frame_redirect.
inline bool capture_display_allowed(bool owned_visible_lease,std::uint64_t now,std::uint64_t heartbeat) {return owned_visible_lease && now>=heartbeat;}
}
