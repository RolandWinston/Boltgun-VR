#pragma once
// Exact source: Lab exported Muzzle; the old native spatial/continuity policy remains.
namespace boltgun { inline constexpr Vec3 kFittedMuzzle{49.7999954f,-0.359999955f,12.8000021f}; }
