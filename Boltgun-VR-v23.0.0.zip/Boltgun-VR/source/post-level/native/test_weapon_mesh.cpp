#include "mesh_data.hpp"
#include <fstream>
#include <iterator>
#include <cassert>
#include <cstdio>
int main(int n,char**v){assert(n>1);for(int j=1;j<n;j++){std::ifstream f(v[j],std::ios::binary);assert(f);std::vector<unsigned char>b((std::istreambuf_iterator<char>(f)),{});chainsword::Mesh m;assert(chainsword::decode(b,m));assert(m.positions.size()>100&&m.indices.size()>100);for(size_t i=0;i<m.indices.size();i+=3){auto a=m.positions[m.indices[i]],c=m.positions[m.indices[i+1]],d=m.positions[m.indices[i+2]];float x=(c.y-a.y)*(d.z-a.z)-(c.z-a.z)*(d.y-a.y),y=(c.z-a.z)*(d.x-a.x)-(c.x-a.x)*(d.z-a.z),z=(c.x-a.x)*(d.y-a.y)-(c.y-a.y)*(d.x-a.x);assert(x*x+y*y+z*z>.000001f);}std::printf("decoded %s %zu vertices\n",v[j],m.positions.size());}}
