// Shared native free-aim path. Live build has no diagnostic input or replay event.
// Executable guard and spawn signature derived from rubocopter/boltgun-vr c74df9a (GPL-3.0-or-later).
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <xinput.h>
#include <bcrypt.h>
#include <atomic>
#include <fstream>
#include <filesystem>
#include <cstdio>
#include <cstring>
#include "../dependencies/uevr/API.h"
#include "muzzle_math.hpp"
#include "weapon_fit_landmarks.hpp"
#include "frame_redirect_gate.hpp"
#include "display_capture_gate.hpp"
#include "switch_input_gate.hpp"
#include "beam_fx_origin.hpp"
using namespace boltgun;
static const UEVR_PluginInitializeParam* api{};
static std::filesystem::path root;
static std::atomic<DWORD> engine_thread{};
static bool session{};
static bool diagnostic{};
static std::atomic<bool> lease_enabled{};
static std::atomic<bool> switch_awaiting_display{};
static std::atomic<unsigned> switch_input_blocks{};
static std::atomic<unsigned long long> lease_revision{};
static unsigned total_shots{},redirected_shots{},display_capture_aged_heartbeat{};
static std::atomic<unsigned long long> continuity{1};
static unsigned long long captured_continuity{};
static unsigned long long engine_frame{},captured_frame{},engine_started{},engine_finished{},stereo_calls{};
#ifdef BOLT_FREEAIM_REPLAY
static bool replay_lease{};
#endif
using SpawnFn=UEVR_UObjectHandle(*)(UEVR_UObjectHandle,UEVR_UClassHandle,void*,const Transform*,UEVR_UObjectHandle);
static SpawnFn original_spawn{};
struct Shot{Transform native{},baseline{},mesh{},output{},actual{};uintptr_t weapon{},projectile{};bool has_baseline{},redirected{},has_actual{};unsigned long long age{};RedirectReason reason{RedirectReason::NoBaseline};unsigned long long decision_now{},heartbeat{},captured{},lease_revision{};bool lease_on{},lease_ready{};unsigned long long frame{},pose_frame{},tick_started{},tick_finished{},stereo_count{},pose_continuity{},current_continuity{};RedirectReason old_reason{RedirectReason::NoBaseline};};
struct SpawnObservation {wchar_t cls[256]{},owner[256]{};Transform native{},actual{};bool has_actual{};unsigned long long at{};uintptr_t projectile{};};
static SpawnObservation spawn_observations[48]{};static unsigned spawn_observation_count{};
struct AimLease{UEVR_UObjectHandle pawn{},weapon{},mesh{};UEVR_UFunctionHandle getter{};Transform pose{};ULONGLONG heartbeat{},captured{};wchar_t mesh_name[256]{};bool ready{};};
static AimLease aim{};
struct HandLease {UEVR_UObjectHandle pawn{},mesh{};Transform pose{};ULONGLONG heartbeat{},captured{};unsigned long long frame{},continuity{1},pose_continuity{};wchar_t name[256]{};bool enabled{},ready{};};
static HandLease hand{};
struct GrenadeShot {Transform native{},hand_pose{},output{},actual{};uintptr_t projectile{};bool redirected{},has_actual{};unsigned long long frame{},pose_frame{},age{};};
static GrenadeShot grenade_shots[16]{};static unsigned grenade_count{},grenade_total{},grenade_redirected{};

static bool foreground();
static bool permitted(){
#ifdef BOLT_FREEAIM_REPLAY
 if(replay_lease)return foreground();
#endif
 return foreground()&&api->vr->is_hmd_active()&&api->vr->is_using_controllers()&&!api->functions->is_drawing_ui();
}

static Shot shots[32]{};static unsigned shot_count{};
static bool live(UEVR_UObjectHandle o){return o&&api->sdk->uobject_hook->exists(o);}
static UEVR_UObjectHandle object_property(UEVR_UObjectHandle o,const wchar_t* k){
 if(!live(o))return nullptr;auto data=api->sdk->uobject->get_property_data(o,k);UEVR_UObjectHandle result{};if(data)std::memcpy(&result,data,sizeof(result));return live(result)?result:nullptr;
}
static bool selected(UEVR_UObjectHandle w){
 auto p=api->sdk->functions->get_local_pawn(0);auto h=object_property(p,L"WeaponHandlerComponent");
 return h&&api->sdk->uobject->get_outer(h)==p&&object_property(h,L"EquippedWeapon")==w;
}
static bool baseline(UEVR_UObjectHandle weapon,Transform& out){
 auto cls=api->sdk->uobject->get_class(weapon);auto fn=api->sdk->ustruct->find_function(reinterpret_cast<UEVR_UStructHandle>(cls),L"GetBarrelTransform");
 if(!fn||api->sdk->ustruct->get_properties_size(reinterpret_cast<UEVR_UStructHandle>(fn))!=48)return false;
 api->sdk->uobject->process_event(weapon,fn,&out);Quat q{};return finite(out.translation)&&normalized(out.rotation,q);
}
static bool reflected_pose(UEVR_UObjectHandle o,Transform& out){
 if(!live(o))return false;
 auto fn=api->sdk->ustruct->find_function(reinterpret_cast<UEVR_UStructHandle>(api->sdk->uobject->get_class(o)),L"K2_GetComponentToWorld");
 if(!fn||api->sdk->ustruct->get_properties_size(reinterpret_cast<UEVR_UStructHandle>(fn))!=48)return false;
 api->sdk->uobject->process_event(o,fn,&out);Quat q{};return finite(out.translation)&&normalized(out.rotation,q);
}
static bool valid_lease(){
 if(!lease_enabled.load()||!permitted()||!aim.ready||!live(aim.pawn)||!live(aim.weapon)||!live(aim.mesh)||api->sdk->functions->get_local_pawn(0)!=aim.pawn||!selected(aim.weapon)||api->sdk->uobject->get_outer(aim.mesh)!=aim.pawn)return false;
 wchar_t name[256]{};api->sdk->fname->to_string(api->sdk->uobject->get_fname(aim.mesh),name,256);
 return std::wcscmp(name,aim.mesh_name)==0;
}
static bool valid_hand(){
 if(!hand.enabled||!hand.ready||!permitted()||!live(hand.pawn)||!live(hand.mesh)||api->sdk->functions->get_local_pawn(0)!=hand.pawn||api->sdk->uobject->get_outer(hand.mesh)!=hand.pawn)return false;
 wchar_t n[256]{};api->sdk->fname->to_string(api->sdk->uobject->get_fname(hand.mesh),n,256);return std::wcscmp(n,hand.name)==0;
}
static bool player_grenade(UEVR_UClassHandle cls,UEVR_UObjectHandle owner){
 if(!live(owner)||owner!=api->sdk->functions->get_local_pawn(0)||!live(reinterpret_cast<UEVR_UObjectHandle>(cls)))return false;
 wchar_t n[256]{};api->sdk->fname->to_string(api->sdk->uobject->get_fname(reinterpret_cast<UEVR_UObjectHandle>(cls)),n,256);
 return !std::wcscmp(n,L"BP_PlayerGrenade_Frag_C")||!std::wcscmp(n,L"BP_PlayerGrenade_Krak_C")||!std::wcscmp(n,L"BP_PlayerGrenade_Vortex_C");
}
static bool grenade_transform(const Transform& original,GrenadeShot& s){
 s.native=original;s.output=original;s.hand_pose=hand.pose;s.frame=engine_frame;s.pose_frame=hand.frame;const auto now=GetTickCount64();s.age=now>=hand.captured?now-hand.captured:0;
 RedirectGate g{};g.has_baseline=true;g.weapon_matches=true;g.lease_valid=valid_hand();g.foreground=foreground();g.now=now;g.heartbeat=hand.heartbeat;g.captured=hand.captured;
 if(classify_frame_redirect(g,engine_frame,hand.frame,hand.pose_continuity==hand.continuity)!=RedirectReason::Ready)return false;
 // Exactly the accepted palm anchor plus 20 cm clear of the hand, with native speed/gravity unchanged.
 return muzzle_transform(hand.pose,{29.308925073f,-2.013539551f,2.f},original,original,s.output);
}
static void align_beam_display();
static void stereo(UEVR_StereoRenderingDeviceHandle,int index,float,UEVR_Vector3f*,UEVR_Rotatorf*,bool){
 if(GetCurrentThreadId()!=engine_thread.load()||!session||(index+1)%2!=0)return;
 ++stereo_calls;const auto now=GetTickCount64();
 __try{if(capture_display_allowed(valid_lease(),now,aim.heartbeat)&&reflected_pose(aim.mesh,aim.pose)){if(now-aim.heartbeat>75)++display_capture_aged_heartbeat;aim.captured=now;captured_frame=engine_frame;captured_continuity=continuity.load();switch_awaiting_display.store(false);align_beam_display();}}
 __except(EXCEPTION_EXECUTE_HANDLER){aim.ready=false;}
 __try{if(capture_display_allowed(valid_hand(),now,hand.heartbeat)&&reflected_pose(hand.mesh,hand.pose)){hand.captured=now;hand.frame=engine_frame;hand.pose_continuity=hand.continuity;}}
 __except(EXCEPTION_EXECUTE_HANDLER){hand.ready=false;}
}
static bool prepare_shot(UEVR_UObjectHandle weapon,const Transform* pose,Shot& s){
 if(!selected(weapon))return false;
 s.native=*pose;s.output=*pose;s.weapon=reinterpret_cast<uintptr_t>(weapon);s.has_baseline=baseline(weapon,s.baseline);
 const auto now=GetTickCount64();
 RedirectGate gate{};gate.has_baseline=s.has_baseline;gate.weapon_matches=weapon==aim.weapon;
 if(gate.has_baseline&&gate.weapon_matches)gate.lease_valid=valid_lease();
 if(gate.has_baseline&&gate.weapon_matches&&gate.lease_valid)gate.foreground=foreground();
 gate.now=now;gate.heartbeat=aim.heartbeat;gate.captured=aim.captured;
 s.frame=engine_frame;s.pose_frame=captured_frame;s.tick_started=engine_started;s.tick_finished=engine_finished;s.stereo_count=stereo_calls;
 s.decision_now=now;s.heartbeat=aim.heartbeat;s.captured=aim.captured;
 s.lease_on=lease_enabled.load();s.lease_ready=aim.ready;s.lease_revision=lease_revision.load();
 s.old_reason=classify_redirect(gate);s.pose_continuity=captured_continuity;s.current_continuity=continuity.load();
 s.reason=classify_frame_redirect(gate,engine_frame,captured_frame,s.pose_continuity==s.current_continuity);
 if(s.reason==RedirectReason::Ready){
  s.mesh=aim.pose;s.age=now-aim.captured;
  s.redirected=muzzle_transform(s.mesh,kFittedMuzzle,s.native,s.baseline,s.output);
  if(!s.redirected)s.reason=RedirectReason::InvalidMuzzle;
 }
 return true;
}
static bool beam_weapon(UEVR_UObjectHandle w);
static unsigned grav_impact_preserved{};
static bool grav_impact(UEVR_UClassHandle cls,UEVR_UObjectHandle w){if(!live(w)||!live(reinterpret_cast<UEVR_UObjectHandle>(cls)))return false;wchar_t n[128]{};api->sdk->fname->to_string(api->sdk->uobject->get_fname(reinterpret_cast<UEVR_UObjectHandle>(cls)),n,128);return beam_weapon(w)&&selected(w)&&!wcscmp(n,L"BP_Projectile_Gravgun_C");}
static UEVR_UObjectHandle spawn(UEVR_UObjectHandle world,UEVR_UClassHandle cls,void* data,const Transform* pose,UEVR_UObjectHandle weapon){
 Shot s{};bool observe=false;GrenadeShot grenade{};bool is_grenade=false;
 if(GetCurrentThreadId()==engine_thread.load()&&session&&pose){
  __try{is_grenade=player_grenade(cls,weapon);if(is_grenade)grenade.redirected=grenade_transform(*pose,grenade);else if(grav_impact(cls,weapon)){++grav_impact_preserved;}else observe=prepare_shot(weapon,pose,s);}
  __except(EXCEPTION_EXECUTE_HANDLER){session=false;aim.ready=false;observe=false;}
 }
 // Exactly one native spawn. Preserve payload, class, ownership and native spread.
 auto result=original_spawn(world,cls,data,is_grenade&&grenade.redirected?&grenade.output:observe&&s.redirected?&s.output:pose,weapon);
 if(diagnostic&&GetCurrentThreadId()==engine_thread.load()&&session&&pose&&beam_weapon(weapon)&&spawn_observation_count<48){
  __try{auto& o=spawn_observations[spawn_observation_count++];o.native=*pose;o.at=GetTickCount64();o.projectile=reinterpret_cast<uintptr_t>(result);
   if(live(reinterpret_cast<UEVR_UObjectHandle>(cls)))api->sdk->fname->to_string(api->sdk->uobject->get_fname(reinterpret_cast<UEVR_UObjectHandle>(cls)),o.cls,256);
   if(live(weapon))api->sdk->fname->to_string(api->sdk->uobject->get_fname(weapon),o.owner,256);
   o.has_actual=reflected_pose(object_property(result,L"RootComponent"),o.actual);
  }__except(EXCEPTION_EXECUTE_HANDLER){}
 }
 if(is_grenade){++grenade_total;if(grenade.redirected)++grenade_redirected;
  __try{grenade.projectile=reinterpret_cast<uintptr_t>(result);grenade.has_actual=reflected_pose(object_property(result,L"RootComponent"),grenade.actual);if(grenade_count>=16){for(unsigned i=1;i<16;i++)grenade_shots[i-1]=grenade_shots[i];grenade_count=15;}grenade_shots[grenade_count++]=grenade;}
  __except(EXCEPTION_EXECUTE_HANDLER){hand.ready=false;}
 }
 if(observe){++total_shots;if(s.redirected)++redirected_shots;}
 if(observe&&shot_count>=32){for(unsigned i=1;i<32;i++)shots[i-1]=shots[i];shot_count=31;}
 if(observe&&shot_count<32){
  __try{s.projectile=reinterpret_cast<uintptr_t>(result);s.has_actual=reflected_pose(object_property(result,L"RootComponent"),s.actual);shots[shot_count++]=s;}
  __except(EXCEPTION_EXECUTE_HANDLER){session=false;aim.ready=false;}
 }
 return result;
}
static void hand_event(const char* name,const char* data){
 if(!session||!name||!data||std::strcmp(name,"boltgun.grenade.hand.v1")||GetCurrentThreadId()!=engine_thread.load())return;
 if(!std::strcmp(data,"off")){hand.enabled=false;++hand.continuity;return;}
 if(!permitted()||std::strlen(data)>70)return;unsigned long long p{},m{};char extra{};if(std::sscanf(data,"%llu|%llu%c",&p,&m,&extra)!=2)return;
 auto pawn=reinterpret_cast<UEVR_UObjectHandle>(p),mesh=reinterpret_cast<UEVR_UObjectHandle>(m);
 __try{auto mc=api->sdk->uobject_array->find_uobject(L"Class /Script/ProceduralMeshComponent.ProceduralMeshComponent");
  if(!live(pawn)||!live(mesh)||!live(mc)||api->sdk->functions->get_local_pawn(0)!=pawn||api->sdk->uobject->get_outer(mesh)!=pawn||reinterpret_cast<UEVR_UObjectHandle>(api->sdk->uobject->get_class(mesh))!=mc)return;
  if(hand.pawn!=pawn||hand.mesh!=mesh){auto c=hand.continuity+1;hand={};hand.continuity=c;}
  hand.pawn=pawn;hand.mesh=mesh;hand.heartbeat=GetTickCount64();hand.enabled=true;hand.ready=true;api->sdk->fname->to_string(api->sdk->uobject->get_fname(mesh),hand.name,256);
 }__except(EXCEPTION_EXECUTE_HANDLER){hand.ready=false;}
}

static void aim_event(const char* name,const char* data){
 if(!session||!name||!data)return;
 bool replay=false;
 bool matches=!std::strcmp(name,"boltgun.freeaim.v1");
#ifdef BOLT_FREEAIM_REPLAY
 replay=!std::strcmp(name,"boltgun.freeaim.replay.v1");matches=matches||replay;
#endif
 if(!matches)return;
 if(!std::strcmp(data,"off")){switch_awaiting_display.store(false);lease_enabled.store(false);++continuity;++lease_revision;return;}
 if(GetCurrentThreadId()!=engine_thread.load()||!foreground()||std::strlen(data)>100)return;
#ifdef BOLT_FREEAIM_REPLAY
 replay_lease=replay;
#else
 (void)replay;
#endif
 if(!permitted()){lease_enabled.store(false);return;}
 unsigned long long p{},w{},m{};char extra{};
 if(std::sscanf(data,"%llu|%llu|%llu%c",&p,&w,&m,&extra)!=3)return;
 const auto pawn=reinterpret_cast<UEVR_UObjectHandle>(p),weapon=reinterpret_cast<UEVR_UObjectHandle>(w),mesh=reinterpret_cast<UEVR_UObjectHandle>(m);
 __try{
  const auto mc=api->sdk->uobject_array->find_uobject(L"Class /Script/ProceduralMeshComponent.ProceduralMeshComponent");
  const auto wc=api->sdk->uobject_array->find_uobject(L"Class /Script/Boltgun.BGRangedWeaponBase");
  if(!live(pawn)||!live(weapon)||!live(mesh)||!live(mc)||!live(wc)||api->sdk->functions->get_local_pawn(0)!=pawn||!selected(weapon)||api->sdk->uobject->get_outer(mesh)!=pawn||reinterpret_cast<UEVR_UObjectHandle>(api->sdk->uobject->get_class(mesh))!=mc||!api->sdk->uobject->is_a(weapon,reinterpret_cast<UEVR_UClassHandle>(wc)))return;
  if(aim.pawn!=pawn||aim.mesh!=mesh||aim.weapon!=weapon){aim={};++continuity;switch_awaiting_display.store(true);}
  aim.pawn=pawn;aim.mesh=mesh;aim.weapon=weapon;aim.heartbeat=GetTickCount64();aim.ready=true;lease_enabled.store(true);++lease_revision;
  api->sdk->fname->to_string(api->sdk->uobject->get_fname(mesh),aim.mesh_name,256);
 }__except(EXCEPTION_EXECUTE_HANDLER){aim={};}
}
static void switch_input(unsigned* result,unsigned user,void* packet){
 if(!session||!result||*result!=ERROR_SUCCESS||!packet||user!=api->vr->get_lowest_xinput_index())return;
 if(hold_switch_trigger(lease_enabled.load(),switch_awaiting_display.load())){
  auto state=static_cast<XINPUT_STATE*>(packet);
  if(state->Gamepad.bRightTrigger){state->Gamepad.bRightTrigger=0;++switch_input_blocks;}
 }
}
static bool foreground(){DWORD pid{};GetWindowThreadProcessId(GetForegroundWindow(),&pid);return pid==GetCurrentProcessId();}
static void write_pose(std::ofstream& f,const Transform&t){
 f<<"{\"position\":["<<t.translation.x<<","<<t.translation.y<<","<<t.translation.z<<"],\"rotation\":["<<t.rotation.x<<","<<t.rotation.y<<","<<t.rotation.z<<","<<t.rotation.w<<"]}";
}
static void sample_frame_time();
static void tick(UEVR_UGameEngineHandle,float){engine_thread.store(GetCurrentThreadId());++engine_frame;sample_frame_time();engine_started=GetTickCount64();}

static bool beam_weapon(UEVR_UObjectHandle w){
 if(!live(w))return false;wchar_t n[128]{};auto c=api->sdk->uobject->get_class(w);
 api->sdk->fname->to_string(api->sdk->uobject->get_fname(reinterpret_cast<UEVR_UObjectHandle>(c)),n,128);
 return !wcscmp(n,L"BP_VolkiteCaliver_C")||!wcscmp(n,L"BP_Gravgun_C");
}
// Scope the native trace adapter to the two exact player beam implementations.
// Kismet SphereTraceSingleByProfile ABI and these call sites were checked in the
// pinned 4.27 executable. Preserve the original collision/damage implementation.
struct BeamScope {UEVR_UObjectHandle weapon{};Transform muzzle{};Vec3 from{},to{},impact{};bool active{},traced{},hit{},allow_zero_origin{};float startup_range{};};
static thread_local BeamScope beam_scope{};
using BeamFxFn=void(*)(UEVR_UObjectHandle);
using GravFxFn=void(*)(UEVR_UObjectHandle,float);
using SphereFn=bool(*)(UEVR_UObjectHandle,const Vec3*,const Vec3*,float,uint64_t,bool,const void*,uint8_t,void*,bool,const void*,const void*,float);
static BeamFxFn original_volkite_fx{},original_volkite_fire{},original_grav_fire{};
static GravFxFn original_grav_fx{};
static SphereFn original_beam_sphere{};
static bool beam_probe_enabled{};
static unsigned beam_trace_total{},beam_trace_redirected{},beam_fx_moves{};
static void vec_json(std::ostream&f,Vec3 v){f<<"["<<v.x<<","<<v.y<<","<<v.z<<"]";}
static BeamScope begin_beam(UEVR_UObjectHandle w){
 BeamScope s{};
 if(GetCurrentThreadId()!=engine_thread.load()||!session||!beam_weapon(w))return s;
 Transform b{};Shot shot{};
 if(baseline(w,b)&&prepare_shot(w,&b,shot)&&shot.redirected){s.weapon=w;s.muzzle=shot.output;s.active=true;}
 return s;
}
static UEVR_UObjectHandle beam_hit_actor(const void* hit){
 if(!hit)return nullptr;auto cls=api->sdk->uobject_array->find_uobject(L"Class /Script/Engine.GameplayStatics");if(!live(cls))return nullptr;
 auto c=reinterpret_cast<UEVR_UStructHandle>(cls);auto fn=api->sdk->ustruct->find_function(c,L"BreakHitResult");if(!fn)return nullptr;auto st=reinterpret_cast<UEVR_UStructHandle>(fn);
 int size=api->sdk->ustruct->get_properties_size(st);auto hp=api->sdk->ustruct->find_property(st,L"Hit");auto ap=api->sdk->ustruct->find_property(st,L"HitActor");if(!hp||!ap||size>512)return nullptr;
 auto hs=api->sdk->fstructproperty->get_struct(reinterpret_cast<UEVR_FStructPropertyHandle>(hp));int n=api->sdk->uscriptstruct->get_struct_size(hs);int ho=api->sdk->fproperty->get_offset(hp),ao=api->sdk->fproperty->get_offset(ap);if(n!=136||ho<0||ao<0||ho+n>size||ao+8>size)return nullptr;
 alignas(16) unsigned char args[512]{};std::memcpy(args+ho,hit,n);api->sdk->uobject->process_event(api->sdk->uclass->get_class_default_object(reinterpret_cast<UEVR_UClassHandle>(cls)),fn,args);UEVR_UObjectHandle actor{};std::memcpy(&actor,args+ao,8);return live(actor)?actor:nullptr;
}
static bool beam_sphere(UEVR_UObjectHandle world,const Vec3* start,const Vec3* end,float radius,uint64_t profile,bool complex,const void* ignore,uint8_t debug,void* hit,bool ignore_self,const void* color,const void* hit_color,float draw_time){
 auto& c=beam_scope;Vec3 a{},b{};bool changed=false;
 if(c.active&&world==c.weapon&&start&&end&&finite(*start)&&finite(*end)){
  auto d=Vec3{end->x-start->x,end->y-start->y,end->z-start->z};float length=std::sqrt(d.x*d.x+d.y*d.y+d.z*d.z);
  if(std::isfinite(c.startup_range)&&c.startup_range>0.01f&&c.startup_range<100000.f)length=c.startup_range;
  if(std::isfinite(length)&&(length>0.01f||c.allow_zero_origin)&&length<100000.f){auto f=rotate(c.muzzle.rotation,{1,0,0});a=c.muzzle.translation;b={a.x+length*f.x,a.y+length*f.y,a.z+length*f.z};changed=true;}
 }
 const bool result=original_beam_sphere(world,changed?&a:start,changed?&b:end,radius,profile,complex,ignore,debug,hit,ignore_self,color,hit_color,draw_time);
 if(c.active&&world==c.weapon){++beam_trace_total;if(changed){++beam_trace_redirected;c.from=a;c.to=b;c.impact=b;c.hit=result;c.traced=true;if(result&&hit)std::memcpy(&c.impact,static_cast<unsigned char*>(hit)+24,12);}
  if(beam_probe_enabled&&beam_trace_total<4000){std::ofstream f(root/L"data/beam-traces.jsonl",std::ios::app);wchar_t n[128]{};api->sdk->fname->to_string(api->sdk->uobject->get_fname(world),n,128);auto actor=beam_hit_actor(hit);wchar_t an[128]{};if(actor)api->sdk->fname->to_string(api->sdk->uobject->get_fname(actor),an,128);f<<"{\"hit_actor\":\""<<std::string(an,an+wcslen(an))<<"\",\"at_ms\":"<<GetTickCount64()<<",\"weapon\":\""<<std::string(n,n+wcslen(n))<<"\",\"redirected\":"<<(changed?"true":"false")<<",\"hit\":"<<(result?"true":"false")<<",\"startup_range\":"<<c.startup_range<<",\"native_start\":";vec_json(f,*start);f<<",\"native_end\":";vec_json(f,*end);f<<",\"start\":";vec_json(f,changed?a:*start);f<<",\"end\":";vec_json(f,changed?b:*end);f<<",\"impact\":";vec_json(f,c.impact);f<<",\"muzzle\":";write_pose(f,c.muzzle);f<<"}\n";}
 }
 return result;
}
static bool set_beam_component(UEVR_UObjectHandle component,const Transform& pose){
 if(!live(component))return false;
 auto cls=reinterpret_cast<UEVR_UStructHandle>(api->sdk->uobject->get_class(component));
 auto fn=api->sdk->ustruct->find_function(cls,L"K2_SetWorldTransform");if(!fn)return false;
 auto st=reinterpret_cast<UEVR_UStructHandle>(fn);int size=api->sdk->ustruct->get_properties_size(st);if(size<48||size>512)return false;
 auto p=api->sdk->ustruct->find_property(st,L"NewTransform");if(!p)return false;
 auto desc=api->sdk->fstructproperty->get_struct(reinterpret_cast<UEVR_FStructPropertyHandle>(p));if(!desc||api->sdk->uscriptstruct->get_struct_size(desc)!=48)return false;
 int offset=api->sdk->fproperty->get_offset(p);if(offset<0||offset+48>size)return false;
 for(auto k:{L"bSweep",L"SweepHitResult",L"bTeleport"}){auto x=api->sdk->ustruct->find_property(st,k);if(!x)return false;int o=api->sdk->fproperty->get_offset(x);if(o<offset+48||o>=size)return false;}
 alignas(16) unsigned char args[512]{};std::memcpy(args+offset,&pose,48);api->sdk->uobject->process_event(component,fn,args);return true;
}
static void place_beam_fx(const BeamScope& c){
 if(!c.active||!c.traced)return;
 for(auto k:{L"LaserFXSystem",L"LaserMuzzelFlashComponent"}){
  auto component=object_property(c.weapon,k);Transform old{};if(!reflected_pose(component,old))continue;
  Transform pose=old;pose.translation=c.muzzle.translation;
  // Native Niagara beams extend along local -X; keep that authored basis.
  pose.rotation=multiply(c.muzzle.rotation,{0,0,1,0});
  // The shipped Grav Niagara tube adds local (-8,8,-5) cm to its owner.
  // Compensate only this beam system, leaving its authored spread and native hit unchanged.
  if(!wcscmp(k,L"LaserFXSystem")){
   wchar_t name[128]{};auto cls=api->sdk->uobject->get_class(c.weapon);
   api->sdk->fname->to_string(api->sdk->uobject->get_fname(reinterpret_cast<UEVR_UObjectHandle>(cls)),name,128);
   if(!wcscmp(name,L"BP_Gravgun_C"))pose.translation=grav_beam_owner_origin(c.muzzle.translation,pose.rotation);
  }

  if(set_beam_component(component,pose))++beam_fx_moves;
 }
 // A no-hit trace must still leave the native Gravgun target at the hand ray end.
 if(!c.hit){auto end=object_property(c.weapon,L"TargetLaserEnd");Transform p{};if(reflected_pose(end,p)){p.translation=c.to;set_beam_component(end,p);}}
}
static void volkite_fx(UEVR_UObjectHandle w){
 auto previous=beam_scope;beam_scope=begin_beam(w);original_volkite_fx(w);place_beam_fx(beam_scope);beam_scope=previous;
}
static void volkite_fire(UEVR_UObjectHandle w){
 auto previous=beam_scope;beam_scope=begin_beam(w);original_volkite_fire(w);beam_scope=previous;
}
static void grav_fx(UEVR_UObjectHandle w,float dt){
 auto previous=beam_scope;beam_scope=begin_beam(w);beam_scope.allow_zero_origin=true;original_grav_fx(w,dt);place_beam_fx(beam_scope);beam_scope=previous;
}
static void beam_probe();
static void align_beam_display(){
 auto c=begin_beam(aim.weapon);if(!c.active)return;c.traced=true;c.hit=true;place_beam_fx(c);beam_probe();
}
static void grav_fire(UEVR_UObjectHandle w){
 auto previous=beam_scope;beam_scope=begin_beam(w);beam_scope.allow_zero_origin=true;
 // Grav FX normally ramps CurrentLaserLength from zero. Native Fire then spawns
 // the persistent damage effect at TargetLaserEnd. Resolve its initial target
 // using the configured reach, without advancing or writing the animation timer.
 // Offsets are verified against the pinned executable's setup/FX routines.
 if(beam_scope.active){
  auto cls=reinterpret_cast<UEVR_UStructHandle>(api->sdk->uobject->get_class(w));
  if(api->sdk->ustruct->get_properties_size(cls)>=0x4d0){float reach{};std::memcpy(&reach,reinterpret_cast<const unsigned char*>(w)+0x4cc,sizeof(reach));
   if(std::isfinite(reach)&&reach>0.01f&&reach<100000.f)beam_scope.startup_range=reach;
  }
  original_grav_fx(w,0.f);place_beam_fx(beam_scope);beam_scope.startup_range=0.f;
 }
 original_grav_fire(w);beam_scope=previous;
}
static bool effect_active(UEVR_UObjectHandle w){
 auto c=object_property(w,L"LaserFXSystem");if(!live(c))return false;
 auto fn=api->sdk->ustruct->find_function(reinterpret_cast<UEVR_UStructHandle>(api->sdk->uobject->get_class(c)),L"IsActive");
 if(!fn||api->sdk->ustruct->get_properties_size(reinterpret_cast<UEVR_UStructHandle>(fn))!=1)return false;
 unsigned char value{};api->sdk->uobject->process_event(c,fn,&value);return value!=0;
}
static bool benchmark{};static LARGE_INTEGER benchmark_last{},benchmark_frequency{};static double benchmark_ms[2400]{};static unsigned benchmark_count{};
static void sample_frame_time(){
 if(!benchmark||benchmark_count>=2400)return;LARGE_INTEGER now{};QueryPerformanceCounter(&now);
 if(benchmark_last.QuadPart&&benchmark_frequency.QuadPart)benchmark_ms[benchmark_count++]=1000.*double(now.QuadPart-benchmark_last.QuadPart)/double(benchmark_frequency.QuadPart);
 benchmark_last=now;
}
static void benchmark_status(){
 if(!benchmark&&std::filesystem::exists(root/L"data/beam-performance.start")){benchmark=true;beam_probe_enabled=false;QueryPerformanceFrequency(&benchmark_frequency);}
 if(!benchmark)return;std::ofstream f(root/L"data/beam-performance.json");f<<"{\"frame_ms\":[";for(unsigned i=0;i<benchmark_count;i++){if(i)f<<",";f<<benchmark_ms[i];}f<<"]}";
}
static void beam_fix_status(){
 if(!beam_probe_enabled)return;std::ofstream f(root/L"data/beam-fix-status.json");f<<"{\"traces\":"<<beam_trace_total<<",\"redirected\":"<<beam_trace_redirected<<",\"fx_moves\":"<<beam_fx_moves<<",\"grav_impact_preserved\":"<<grav_impact_preserved<<"}";
}

static void beam_metadata(UEVR_UObjectHandle w){
 static UEVR_UObjectHandle last{};if(last==w)return;last=w;
 auto c=reinterpret_cast<UEVR_UStructHandle>(api->sdk->uobject->get_class(w));
 std::ofstream f(root/L"data/beam-metadata.jsonl",std::ios::app);
 wchar_t wn[128]{};api->sdk->fname->to_string(api->sdk->uobject->get_fname(w),wn,128);
 const wchar_t* names[]={L"GetBarrelTransform",L"GetBarrelTransformAccuracyDeviated",L"WeaponHitLineTrace",L"WeaponHitMultiTraces",L"Fire",L"StartFiring",L"StopFiring",L"EndFire",L"GetTargetLaserEnd"};
 for(auto n:names){auto fn=api->sdk->ustruct->find_function(c,n);if(!fn)continue;
 f<<"{\"weapon\":\""<<std::string(wn,wn+wcslen(wn))<<"\",\"function\":\""<<std::string(n,n+wcslen(n))<<"\",\"rva\":"<<(reinterpret_cast<uintptr_t>(api->sdk->ufunction->get_native_function(fn))-reinterpret_cast<uintptr_t>(GetModuleHandleW(nullptr)))<<",\"size\":"<<api->sdk->ustruct->get_properties_size(reinterpret_cast<UEVR_UStructHandle>(fn))<<",\"fields\":[";
 bool first=true;auto fields=api->sdk->ustruct->get_child_properties(reinterpret_cast<UEVR_UStructHandle>(fn));
 for(int i=0;fields&&i<32;i++,fields=api->sdk->ffield->get_next(fields)){
  wchar_t k[128]{};api->sdk->fname->to_string(api->sdk->ffield->get_fname(fields),k,128);auto pr=api->sdk->ustruct->find_property(reinterpret_cast<UEVR_UStructHandle>(fn),k);if(!pr)continue;
  if(!first)f<<",";first=false;f<<"{\"name\":\""<<std::string(k,k+wcslen(k))<<"\",\"offset\":"<<api->sdk->fproperty->get_offset(pr)<<"}";
 }f<<"]}\n";}
}
static void beam_probe(){
 if(!beam_probe_enabled||!live(aim.weapon)||!beam_weapon(aim.weapon)||!selected(aim.weapon))return;
 static unsigned count{};static ULONGLONG last{};const auto now=GetTickCount64();if(now-last<80||count>=1600)return;last=now;++count;
 beam_metadata(aim.weapon);Transform b{},m{};bool hb=baseline(aim.weapon,b);bool hm=hb&&muzzle_transform(aim.pose,kFittedMuzzle,b,b,m);
 std::ofstream f(root/L"data/beam-pose.jsonl",std::ios::app);wchar_t name[128]{};api->sdk->fname->to_string(api->sdk->uobject->get_fname(aim.weapon),name,128);
 f<<"{\"active\":"<<(effect_active(aim.weapon)?"true":"false")<<",\"at_ms\":"<<now<<",\"weapon\":\""<<std::string(name,name+wcslen(name))<<"\",\"frame\":"<<engine_frame<<",\"pose_frame\":"<<captured_frame<<",\"heartbeat_age\":"<<(now-aim.heartbeat)<<",\"lease\":"<<(valid_lease()?"true":"false")<<",\"has_muzzle\":"<<(hm?"true":"false")<<",\"muzzle\":";write_pose(f,m);f<<",\"barrel\":";write_pose(f,b);
 for(auto key:{L"LaserFXSystem",L"LaserMuzzelFlashComponent",L"LaserImpactFXSystem",L"TargetLaserEnd"}){auto c=object_property(aim.weapon,key);Transform t{};if(reflected_pose(c,t)){f<<",\""<<std::string(key,key+wcslen(key))<<"\":";write_pose(f,t);}}
 if(auto q=api->sdk->uobject->get_property_data(aim.weapon,L"LaserImpactLocation")){Vec3 v{};std::memcpy(&v,q,sizeof(v));f<<",\"LaserImpactLocation\":["<<v.x<<","<<v.y<<","<<v.z<<"]";}
 f<<"}\n";
}
static void post(UEVR_UGameEngineHandle,float){
 engine_finished=GetTickCount64();static ULONGLONG last{};const auto now=GetTickCount64();if(now-last<200)return;last=now;
 __try{beam_fix_status();benchmark_status();}__except(EXCEPTION_EXECUTE_HANDLER){}
 std::ofstream f(root/L"data/boltgun-freeaim-status.json",std::ios::trunc);
 f<<"{\"pid\":"<<GetCurrentProcessId()<<",\"session\":"<<(session?"true":"false")<<",\"total\":"<<total_shots<<",\"redirected\":"<<redirected_shots<<",\"lease\":"<<(lease_enabled.load()?"true":"false")<<",\"display_capture_aged_heartbeat\":"<<display_capture_aged_heartbeat<<",\"switch_input_blocks\":"<<switch_input_blocks.load()<<",\"shots\":[";
 for(unsigned i=0;i<shot_count;i++){if(i)f<<",";auto&s=shots[i];f<<"{\"weapon\":"<<s.weapon<<",\"projectile\":"<<s.projectile<<",\"native\":";write_pose(f,s.native);f<<",\"has_baseline\":"<<(s.has_baseline?"true":"false")<<",\"baseline\":";write_pose(f,s.baseline);f<<",\"redirected\":"<<(s.redirected?"true":"false")<<",\"age_ms\":"<<s.age<<",\"mesh\":";write_pose(f,s.mesh);f<<",\"output\":";write_pose(f,s.output);f<<",\"has_actual\":"<<(s.has_actual?"true":"false")<<",\"actual\":";write_pose(f,s.actual);f<<",\"decision\":{\"reason\":\""<<redirect_reason_name(s.reason)<<"\",\"clock\":\"GetTickCount64_ms\",\"now_ms\":"<<s.decision_now<<",\"heartbeat_ms\":"<<s.heartbeat<<",\"captured_ms\":"<<s.captured<<",\"lease_revision\":"<<s.lease_revision<<",\"lease_enabled\":"<<(s.lease_on?"true":"false")<<",\"lease_ready\":"<<(s.lease_ready?"true":"false")<<",\"engine_frame\":"<<s.frame<<",\"captured_frame\":"<<s.pose_frame<<",\"engine_started_ms\":"<<s.tick_started<<",\"engine_finished_ms\":"<<s.tick_finished<<",\"stereo_calls\":"<<s.stereo_count<<",\"captured_continuity\":"<<s.pose_continuity<<",\"current_continuity\":"<<s.current_continuity<<",\"legacy_reason\":\""<<redirect_reason_name(s.old_reason)<<"\"}}";}
 f<<"]}";
 if(!diagnostic)return;std::ofstream g(root/L"data/boltgun-spawn-observation.json");g<<"{\"events\":[";
 for(unsigned i=0;i<spawn_observation_count;i++){if(i)g<<",";auto&o=spawn_observations[i];std::string c(o.cls,o.cls+wcslen(o.cls)),w(o.owner,o.owner+wcslen(o.owner));g<<"{\"at_ms\":"<<o.at<<",\"class\":\""<<c<<"\",\"owner\":\""<<w<<"\",\"projectile\":"<<o.projectile<<",\"native\":";write_pose(g,o.native);g<<",\"has_actual\":"<<(o.has_actual?"true":"false")<<",\"actual\":";write_pose(g,o.actual);g<<"}";}g<<"]}";
}
static void grenade_post(UEVR_UGameEngineHandle,float){
 static ULONGLONG last{};auto now=GetTickCount64();if(now-last<200)return;last=now;
 std::ofstream f(root/L"data/boltgun-grenade-status.json");f<<"{\"total\":"<<grenade_total<<",\"redirected\":"<<grenade_redirected<<",\"hand_ready\":"<<(valid_hand()?"true":"false")<<",\"shots\":[";
 for(unsigned i=0;i<grenade_count;i++){if(i)f<<",";auto&s=grenade_shots[i];f<<"{\"redirected\":"<<(s.redirected?"true":"false")<<",\"projectile\":"<<s.projectile<<",\"frame\":"<<s.frame<<",\"pose_frame\":"<<s.pose_frame<<",\"age_ms\":"<<s.age<<",\"native\":";write_pose(f,s.native);f<<",\"hand\":";write_pose(f,s.hand_pose);f<<",\"output\":";write_pose(f,s.output);f<<",\"has_actual\":"<<(s.has_actual?"true":"false")<<",\"actual\":";write_pose(f,s.actual);f<<"}";}f<<"]}";
}
static bool supported_file(const wchar_t* path) {
    const unsigned char expected[]={0xbd,0x32,0xae,0xcb,0x2e,0xf6,0xfe,0xb3,
        0xfd,0x2e,0xdf,0xb0,0x09,0x5b,0x7e,0x53,0x41,0x76,0xc9,0x2c,0x01,0xd5,0xfa,0x5c,
        0xcc,0x43,0xa0,0xdd,0xc6,0x39,0xb0,0x1a};
    FILE* file{};if(_wfopen_s(&file,path,L"rb")!=0) return false;
    BCRYPT_ALG_HANDLE alg{};BCRYPT_HASH_HANDLE hash{};unsigned char digest[32]{},buffer[65536];
    bool ok=BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,nullptr,0)>=0&&
            BCryptCreateHash(alg,&hash,nullptr,0,nullptr,0,0)>=0;
    while(ok) {
        const size_t count=std::fread(buffer,1,sizeof(buffer),file);
        if(count==0) break;
        ok=BCryptHashData(hash,buffer,static_cast<ULONG>(count),0)>=0;
    }
    ok=ok&&!std::ferror(file)&&BCryptFinishHash(hash,digest,sizeof(digest),0)>=0;
    if(hash) BCryptDestroyHash(hash);if(alg) BCryptCloseAlgorithmProvider(alg,0);std::fclose(file);
    return ok&&std::memcmp(expected,digest,sizeof(expected))==0;
}
static bool supported_module(unsigned char* module) {
    const auto dos=reinterpret_cast<IMAGE_DOS_HEADER*>(module);
    if(dos->e_magic!=IMAGE_DOS_SIGNATURE||dos->e_lfanew<=0||dos->e_lfanew>4096) return false;
    const auto nt=reinterpret_cast<IMAGE_NT_HEADERS64*>(module+dos->e_lfanew);
    if(nt->Signature!=IMAGE_NT_SIGNATURE||nt->FileHeader.Machine!=IMAGE_FILE_MACHINE_AMD64||
       nt->OptionalHeader.SizeOfImage!=0x5462000||nt->FileHeader.TimeDateStamp!=0x667c945d) return false;
    const unsigned char prefix[]={0x48,0x89,0x5c,0x24,0x08,0x57,0x48,0x83,0xec,0x70,
        0x48,0x8b,0x01,0x48,0x8b,0xfa,0x0f,0x29,0x74,0x24,0x60,0x48,0x8b,0xd9,
        0x0f,0x29,0x7c,0x24,0x50,0x0f,0x28,0xf3};
    const unsigned char spawn_prefix[]={0x48,0x89,0x5c,0x24,0x10,0x55,0x56,0x57,
        0x41,0x56,0x41,0x57,0x48,0x8b,0xec,0x48,0x83,0xec,0x70,0x48,0x8b,0x7d,0x50,
        0x4d,0x8b,0xf1,0x4d,0x8b,0xf8,0x48,0x8b,0xda};
    const unsigned char check_beam_sphere[]={0x40,0x53,0x55,0x56,0x57,0x41,0x54,0x41,0x56,0x41,0x57,0x48,0x81,0xec,0xe0,0x0};
    if(std::memcmp(module+0x2c5b940,check_beam_sphere,16))return false;
    const unsigned char check_volkite_fx[]={0x48,0x8b,0xc4,0x48,0x89,0x58,0x10,0x55,0x48,0x8d,0x68,0x88,0x48,0x81,0xec,0x70};
    if(std::memcmp(module+0x10a5c50,check_volkite_fx,16))return false;
    const unsigned char check_volkite_fire[]={0x48,0x8b,0xc4,0x55,0x57,0x48,0x8d,0xa8,0xf8,0xfe,0xff,0xff,0x48,0x81,0xec,0xf8};
    if(std::memcmp(module+0x107a470,check_volkite_fire,16))return false;
    const unsigned char check_grav_fx[]={0x48,0x8b,0xc4,0x48,0x89,0x58,0x18,0x55,0x56,0x57,0x48,0x8d,0xa8,0xa8,0xfe,0xff};
    if(std::memcmp(module+0x10a5630,check_grav_fx,16))return false;
    const unsigned char check_grav_fire[]={0x4c,0x8b,0xdc,0x55,0x49,0x8d,0xab,0x28,0xff,0xff,0xff,0x48,0x81,0xec,0xd0,0x1};
    if(std::memcmp(module+0x1077dc0,check_grav_fire,16))return false;
    return std::memcmp(module+0x107d1d0,prefix,sizeof(prefix))==0&&
           std::memcmp(module+0x10616a0,spawn_prefix,sizeof(spawn_prefix))==0;
}

extern "C" __declspec(dllexport) void uevr_plugin_required_version(UEVR_PluginVersion*v){if(v)*v={2,39,0};}
extern "C" __declspec(dllexport) bool uevr_plugin_initialize(const UEVR_PluginInitializeParam*p){
 if(!p||!p->version||p->version->major!=2||p->version->minor<39||!p->sdk||!p->vr||!p->callbacks||!p->functions)return false;api=p;
 wchar_t path[32768]{},dir[32768]{};
 if(!GetModuleFileNameW(nullptr,path,32768)||!supported_file(path)||!supported_module(reinterpret_cast<unsigned char*>(GetModuleHandleW(nullptr))))return true;
 api->functions->get_persistent_dir(dir,32768);root=dir;
 FILETIME born{},exit{},kernel{},user{};if(!GetProcessTimes(GetCurrentProcess(),&born,&exit,&kernel,&user))return true;
 ULARGE_INTEGER t{};t.LowPart=born.dwLowDateTime;t.HighPart=born.dwHighDateTime;
 std::ifstream file(root/L"data/labvisuals.session_nonce");unsigned long long pid{},stamp{};char colon{};file>>pid>>colon>>stamp;
 if(!file||colon!=':'||pid!=GetCurrentProcessId()||stamp!=t.QuadPart+504911232000000000ull)return true;
 beam_probe_enabled=std::filesystem::exists(root/L"data/beam-probe.enabled");
 session=true;diagnostic=std::filesystem::exists(root/L"data/agent-native-token.txt");
 api->sdk->callbacks->on_post_calculate_stereo_view_offset(stereo);api->sdk->callbacks->on_pre_engine_tick(tick);api->sdk->callbacks->on_post_engine_tick(post);api->callbacks->on_custom_event(aim_event);api->callbacks->on_xinput_get_state(switch_input);api->callbacks->on_custom_event(hand_event);api->sdk->callbacks->on_post_engine_tick(grenade_post);

 const auto module=reinterpret_cast<unsigned char*>(GetModuleHandleW(nullptr));
 const auto hook_beam_sphere=api->functions->register_inline_hook(module+0x2c5b940,reinterpret_cast<void*>(beam_sphere),reinterpret_cast<void**>(&original_beam_sphere));
 api->functions->log_info("[Boltgun beam] beam_sphere hook=%d",hook_beam_sphere);
 const auto hook_volkite_fx=api->functions->register_inline_hook(module+0x10a5c50,reinterpret_cast<void*>(volkite_fx),reinterpret_cast<void**>(&original_volkite_fx));
 api->functions->log_info("[Boltgun beam] volkite_fx hook=%d",hook_volkite_fx);
 const auto hook_volkite_fire=api->functions->register_inline_hook(module+0x107a470,reinterpret_cast<void*>(volkite_fire),reinterpret_cast<void**>(&original_volkite_fire));
 api->functions->log_info("[Boltgun beam] volkite_fire hook=%d",hook_volkite_fire);
 const auto hook_grav_fx=api->functions->register_inline_hook(module+0x10a5630,reinterpret_cast<void*>(grav_fx),reinterpret_cast<void**>(&original_grav_fx));
 api->functions->log_info("[Boltgun beam] grav_fx hook=%d",hook_grav_fx);
 const auto hook_grav_fire=api->functions->register_inline_hook(module+0x1077dc0,reinterpret_cast<void*>(grav_fire),reinterpret_cast<void**>(&original_grav_fire));
 api->functions->log_info("[Boltgun beam] grav_fire hook=%d",hook_grav_fire);
 const auto id=api->functions->register_inline_hook(reinterpret_cast<unsigned char*>(GetModuleHandleW(nullptr))+0x10616a0,reinterpret_cast<void*>(spawn),reinterpret_cast<void**>(&original_spawn));
 api->functions->log_info("[Boltgun free aim] exact executable and nonce verified; native spawn hook=%d; diagnostic=BOLT-SHOT-FRAME-FIX-01",id);return true;
}

