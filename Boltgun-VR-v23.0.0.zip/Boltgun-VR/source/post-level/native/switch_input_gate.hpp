#pragma once
namespace boltgun { inline bool hold_switch_trigger(bool lease_enabled,bool awaiting_display) {return lease_enabled&&awaiting_display;} }
