#include "redirect_gate.hpp"
#include <cassert>
#include <cstdio>
#ifdef NDEBUG
#error Assertions must be enabled in this differential test.
#endif
using namespace boltgun;
bool original(const RedirectGate&g){return g.has_baseline&&g.weapon_matches&&g.lease_valid&&g.foreground&&g.now>=g.heartbeat&&g.now-g.heartbeat<=75&&g.captured&&g.now>=g.captured&&g.now-g.captured<=75;}
int main(){
 unsigned count=0;
 const std::uint64_t clocks[]={0,1,24,25,26,99,100,101,175,176};
 for(unsigned mask=0;mask<16;mask++)for(auto now:clocks)for(auto hb:clocks)for(auto cap:clocks){
  RedirectGate g{bool(mask&1),bool(mask&2),bool(mask&4),bool(mask&8),now,hb,cap};
  assert((classify_redirect(g)==RedirectReason::Ready)==original(g));count++;
 }
 RedirectGate g{true,true,true,true,100,100,100};
 g.captured=25;assert(classify_redirect(g)==RedirectReason::Ready);
 g.captured=24;assert(classify_redirect(g)==RedirectReason::RenderedPoseStale);
 g.captured=0;assert(classify_redirect(g)==RedirectReason::NoRenderedPose);
 g.captured=101;assert(classify_redirect(g)==RedirectReason::RenderedPoseFuture);
 g.captured=100;g.heartbeat=24;assert(classify_redirect(g)==RedirectReason::HeartbeatStale);
 g.heartbeat=101;assert(classify_redirect(g)==RedirectReason::HeartbeatFuture);
 g.heartbeat=100;g.lease_valid=false;assert(classify_redirect(g)==RedirectReason::InvalidLease);
 std::printf("{\"equivalence_cases\":%u,\"explicit_boundary_cases\":7,\"passed\":true,\"game_loaded\":false}\n",count);
}
