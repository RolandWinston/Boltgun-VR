import bpy,math,struct,json,hashlib
from pathlib import Path
from mathutils import Vector
D=Path(__file__).resolve().parent;OUT=D/'weapons';OUT.mkdir(exist_ok=True)
C=D.parent.parent/'payload/data/labvisuals'
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene;scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=.01
atlas=bpy.data.images.load(str(C/'lab-visual-atlas.png'));atlas.pack();quad={'blue':(.01,.01,.23,.48),'gold':(.26,.01,.23,.48),'red':(.01,.51,.23,.48),'dark':(.26,.51,.23,.48),'steel':(.26,.51,.23,.48)}
mats={}
for key,(u,v,w,h) in quad.items():
 m=bpy.data.materials.new('approved_'+key);m.use_nodes=True;t=m.node_tree.nodes.new('ShaderNodeTexImage');t.image=atlas;t.interpolation='Closest';bs=m.node_tree.nodes.get('Principled BSDF');m.node_tree.links.new(t.outputs['Color'],bs.inputs['Base Color']);bs.inputs['Roughness'].default_value=.64;mats[key]=m
parts=[]
def finish(o,name,color):
 o.name=name;o.data.materials.append(mats[color]);bpy.context.view_layer.objects.active=o
 bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(island_margin=.03);bpy.ops.object.mode_set(mode='OBJECT');u,v,w,h=quad[color]
 for uv in o.data.uv_layers.active.data:uv.uv=(u+uv.uv.x*w,1-(v+uv.uv.y*h))
 parts.append(o);return o
def box(name,p,size,color='steel',bevel=.35):
 bpy.ops.mesh.primitive_cube_add(size=1,location=p);o=bpy.context.object;o.dimensions=size;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 if bevel:m=o.modifiers.new('edge','BEVEL');m.width=bevel;m.segments=1;bpy.ops.object.modifier_apply(modifier=m.name)
 return finish(o,name,color)
def tube(name,x,y,z,r,length,color='steel',axis='x'):
 bpy.ops.mesh.primitive_cylinder_add(vertices=12,radius=r,depth=length,location=(x,y,z),rotation=(0,math.pi/2,0)if axis=='x'else(math.pi/2,0,0));o=bpy.context.object;bpy.ops.object.transform_apply(location=False,rotation=True,scale=True);return finish(o,name,color)
def common():
 box('palm_grip',(9,-1.8,0),(4,4.4,12),'dark',.45);box('grip_upper',(10,-1.3,7),(7,6,4),'steel');box('trigger_guard',(14,-1.8,-4),(10,5.3,1.4),'steel',.2);box('trigger',(12,-1.8,0),(1.1,1.2,4),'gold',.1)
 for z in [-4,-1,2]:box('grip_rib',(7,-1.8,z),(.7,4.6,.7),'steel',.1)
def trim():
 box('rear_sight',(10,-.36,21),(2,4,2),'dark');box('front_sight',(44,-.36,19),(1.4,2,2),'gold');
 for y in [-5.6,5.0]:box('side_emblem',(18,y,14),(6,.65,2),'gold')
ids=['Shotgun','Plasmagun','HeavyBolter','Meltagun','VolkiteCaliver','VengeanceLauncher','Gravgun','MultiMelta','MissileLauncher'];reports=[]
for ix,id in enumerate(ids):
 parts=[];common()
 if id=='Shotgun':
  box('receiver',(18,-.36,12.8),(23,9,10),'steel');tube('upper_barrel',36,-.36,12.8,2.4,27);tube('lower_tube',34,-.36,7.5,1.8,25,'dark');box('pump',(33,-.36,7),(13,7,5),'dark')
  for x in range(28,40,2):box('pump_rib',(x,-.36,7),(1,7.5,5.5),'steel',.1)
 elif id=='Plasmagun':
  box('plasma_body',(24,-.36,11),(34,12,11),'red');tube('plasma_core',31,-.36,17,5,24,'blue')
  for x in range(21,44,3):tube('coil_rib',x,-.36,17,5.6,.85,'steel')
  tube('emitter',46,-.36,12.8,4,7,'steel');tube('energy_aperture',49.3,-.36,12.8,2.7,.5,'blue')
 elif id=='HeavyBolter':
  box('heavy_receiver',(23,-.36,13),(32,17,15),'red');box('heavy_magazine',(23,-.36,0),(12,13,18),'steel');tube('heavy_barrel',43,-.36,12.8,4,13);box('carry_handle',(23,-.36,25),(15,4,2),'dark');box('carry_mount',(16,-.36,22),(2,4,6));box('carry_mount',(30,-.36,22),(2,4,6))
  for x in range(14,33,4):box('cooling_vent',(x,8.4,14),(2,1,8),'dark',.1)
 elif id in ['Meltagun','MultiMelta']:
  box('heat_receiver',(22,-.36,12),(30,13 if id=='Meltagun'else 19,13),'red');tube('fuel_tank',22,-8,5,4.2,15,'gold')
  for y in ([-.36]if id=='Meltagun'else[-5.5,4.8]):
   tube('melta_nozzle',42,y,12.8,4.5 if id=='Meltagun'else 4.1,15,'gold');tube('bore',49.3,y,12.8,2.8,.7,'dark')
   for x in [37,41,45]:tube('heat_ring',x,y,12.8,5,.8,'steel')
 elif id=='VolkiteCaliver':
  box('volkite_receiver',(19,-.36,12),(25,11,12),'red');tube('ray_core',36,-.36,12.8,3.1,26,'dark')
  for x in range(25,48,4):tube('ray_coil',x,-.36,12.8,4.8,2,'gold')
  box('upper_rail',(34,-.36,19),(25,3,1.4),'steel');tube('ray_aperture',49,-.36,12.8,2.6,1,'blue')
 elif id=='VengeanceLauncher':
  box('launcher_receiver',(22,-.36,15),(30,13,12),'blue');tube('drum',23,-.36,5,10,13,'steel',axis='y');tube('grenade_barrel',42,-.36,12.8,5.2,15,'steel');tube('bore',49.3,-.36,12.8,4.1,.6,'dark')
  for a in range(0,360,45):
   rad=math.radians(a);box('drum_lock',(23+8*math.cos(rad),-7.3,5+8*math.sin(rad)),(2,1,2),'gold',.15)
 elif id=='Gravgun':
  box('grav_body',(21,-.36,12),(28,15,14),'blue');tube('grav_cell',34,-.36,12.8,5.5,16,'steel');tube('grav_core',43,-.36,12.8,3.3,8,'blue')
  for a in [0,120,240]:
   rad=math.radians(a);y=-.36+6*math.cos(rad);z=12.8+6*math.sin(rad);box('grav_prong',(43,y,z),(12,2,2),'gold',.3)
 elif id=='MissileLauncher':
  tube('launcher_tube',26,-.36,13,7,45,'dark');tube('rear_band',5,-.36,13,8,3,'steel');tube('front_band',47,-.36,13,8,4,'steel');box('sight_box',(23,-8.6,18),(13,4,5),'gold');box('upper_armour',(25,-.36,20),(28,9,2),'red')
 trim()
 # Common front plane gives all weapons the same accepted hand anchor and tested muzzle point.
 if id not in ['MultiMelta','MissileLauncher','Gravgun']:tube('bore_inset',49.55,-.36,12.8,1.5,.35,'dark')
 bpy.context.view_layer.update();verts=[];indices=[]
 for o in parts:
  me=o.data;me.calc_loop_triangles();mat=o.matrix_world;normal=mat.to_3x3().inverted().transposed();uv=me.uv_layers.active.data
  for tri in me.loop_triangles:
   triangle=[mat@me.vertices[me.loops[li].vertex_index].co for li in tri.loops]
   if (triangle[1]-triangle[0]).cross(triangle[2]-triangle[0]).length<=.001:continue
   start=len(verts)
   for li in tri.loops:
    vi=me.loops[li].vertex_index;p=mat@me.vertices[vi].co;n=(normal@tri.normal).normalized();t=uv[li].uv;verts.append((*p,*n,t.x,1-t.y))
   indices.extend([start,start+1,start+2,start,start+2,start+1])
 assert all(math.isfinite(v)for row in verts for v in row);raw=b'BGCHAIN1'+struct.pack('<III',1,len(verts),len(indices))+b''.join(struct.pack('<8f',*v)for v in verts)+struct.pack('<'+'I'*len(indices),*indices)
 path=OUT/(id+'.bgmesh');path.write_bytes(raw);(C/path.name).write_bytes(raw)
 lo=[min(v[i]for v in verts)for i in range(3)];hi=[max(v[i]for v in verts)for i in range(3)];reports.append({'id':id,'vertices':len(verts),'triangles':len(indices)//3,'bounds':[lo,hi],'anchor':[9,-1.8,0],'muzzle':[49.8,-.36,12.8],'sha256':hashlib.sha256(raw).hexdigest(),'source':'new Blender geometry; same approved atlas; existing Bolter/arms unchanged'})
 root=bpy.data.objects.new(id,None);scene.collection.objects.link(root)
 for o in parts:o.parent=root
 root.location=(ix%3*68,ix//3*55,0)
 # Durable editable source includes every distinct mesh, with the unshifted local mount.
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'post-level-weapons.blend'))
(OUT/'mesh-report.json').write_text(json.dumps(reports,indent=2));print('MODELS_EXPORTED',[(x['id'],x['triangles'])for x in reports])
