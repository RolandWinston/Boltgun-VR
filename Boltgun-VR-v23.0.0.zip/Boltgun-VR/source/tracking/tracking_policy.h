#pragma once
#include <math.h>
#include <stdint.h>
/* OpenXR VALID + TRACKED for both position and orientation. VALID alone may be inferred. */
static int sf_pose_valid(int result, int active, uint64_t flags, const float p[3], const float q[4]) {
    if (result != 0 || !active || (flags & 15u) != 15u) return 0;
    for (int i=0;i<3;++i) if (!isfinite(p[i]) || fabsf(p[i])>1000.f) return 0;
    float n=0;
    for (int i=0;i<4;++i) {if (!isfinite(q[i])) return 0; n+=q[i]*q[i];}
    return n>.81f && n<1.21f;
}
static int sf_frame_valid(int same_session,int64_t age_ticks,int64_t frequency,int should_render,int focused,int foreground) {
    return same_session && age_ticks>=0 && frequency>0 && (double)age_ticks/frequency<=0.075 && should_render && focused && foreground;
}
