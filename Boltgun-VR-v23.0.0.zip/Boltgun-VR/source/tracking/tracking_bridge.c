/* Observation-only UEVR plugin. Never writes game state, input, damage or global XR settings. */
#define WIN32_LEAN_AND_MEAN
#define XR_NO_PROTOTYPES
#include <windows.h>
#include <bcrypt.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <uevr/API.h>
#include <openxr/openxr.h>
#include <openxr/openxr_loader_negotiation.h>
#include "tracking_policy.h"
#include "../reference/MinHook-1.3.4/include/MinHook.h"
#define SIFUVR_TRACKING_LIFECYCLE 1
static const UEVR_PluginInitializeParam* sf_api;
static PFN_xrGetInstanceProcAddr sf_getproc;
static PFN_xrWaitFrame sf_wait_original;
static PFN_xrPollEvent sf_poll_original;
static PFN_xrSyncActions sf_sync_original;
static int sf_sync_hook=-1;
static PFN_xrDestroySession sf_destroy_session_original;
static PFN_xrDestroyInstance sf_destroy_instance_original;
static void (*sf_backend_destroy_original)(void*);
static int sf_backend_hook=-1;
static PFN_xrCreateActionSpace sf_create;
static PFN_xrDestroySpace sf_destroy;
static PFN_xrStringToPath sf_path;
static PFN_xrLocateSpace sf_locate;
static PFN_xrGetActionStatePose sf_state;
static SRWLOCK sf_lock=SRWLOCK_INIT;
/* Only plugin-issued XR reads share this lock. Destruction waits for those reads,
   then invalidates handles before forwarding exactly one original destroy call. */
static SRWLOCK sf_runtime_lock=SRWLOCK_INIT;
typedef struct {XrSession session; XrInstance instance; XrTime time; int64_t ticks; int render; XrSession focus_session; XrSessionState focus; XrSession change_session; XrTime change_time; uint64_t generation; uint64_t focus_revision;} SfFrame;
static SfFrame sf_frame;
static XrInstance sf_instance;
static XrSession sf_session;
static XrAction sf_action,sf_aim_action;
static XrSpace sf_spaces[4];
static XrPath sf_paths[2];
static int sf_wait_hook=-1,sf_poll_hook=-1,sf_attempts=0;
static int sf_destroy_session_hook=-1,sf_destroy_instance_hook=-1;
static int sf_invalidated=1;
static int sf_initialized;
static _Thread_local int sf_teardown_depth;
typedef BOOLEAN (WINAPI *SfDllShutdownInProgress)(void);
static SfDllShutdownInProgress sf_dll_shutdown;
static ULONGLONG sf_retry_at;
static const char* sf_failure="none";
static XrResult sf_failure_result=XR_SUCCESS;
static uint64_t sf_epoch=0,sf_sequence=0;
static XrTime sf_last_time,sf_applied_change;
static LARGE_INTEGER sf_frequency;
#ifdef SIFUVR_SCREEN_EXTENSION
#include "screen_bridge.h"
#endif
#ifdef SIFUVR_MOTION_INPUT_EXTENSION
#include "../candidates/motion-input/native/tracking_motion.h"
#endif
static XrResult XRAPI_PTR sf_wait(XrSession s,const XrFrameWaitInfo* info,XrFrameState* state) {
    uint64_t generation;
    AcquireSRWLockShared(&sf_lock);generation=sf_frame.generation;ReleaseSRWLockShared(&sf_lock);
    XrResult result=sf_wait_original(s,info,state);
    LARGE_INTEGER now;QueryPerformanceCounter(&now);
    AcquireSRWLockExclusive(&sf_lock);
    /* A late wait completion must not resurrect a session invalidated meanwhile. */
    if (generation==sf_frame.generation) {
        sf_frame.session=s;sf_frame.ticks=now.QuadPart;
        sf_frame.time=result==XR_SUCCESS && state ? state->predictedDisplayTime:0;
        sf_frame.render=result==XR_SUCCESS && state && state->shouldRender;
    }
    ReleaseSRWLockExclusive(&sf_lock);
    return result;
}
static XrResult XRAPI_PTR sf_poll(XrInstance instance,XrEventDataBuffer* event) {
    uint64_t generation;
    AcquireSRWLockShared(&sf_lock);generation=sf_frame.generation;ReleaseSRWLockShared(&sf_lock);
    XrResult result=sf_poll_original(instance,event);
    AcquireSRWLockExclusive(&sf_lock);
    if (generation!=sf_frame.generation) {ReleaseSRWLockExclusive(&sf_lock);return result;}
    if (result==XR_ERROR_INSTANCE_LOST || (result==XR_SUCCESS && event && event->type==XR_TYPE_EVENT_DATA_INSTANCE_LOSS_PENDING)) {
        uint64_t next=sf_frame.generation+1;
        memset(&sf_frame,0,sizeof(sf_frame));sf_frame.generation=next;
#ifdef SIFUVR_SCREEN_EXTENSION
        sf_screen_invalidate_locked("instance_lost");
#endif
        ReleaseSRWLockExclusive(&sf_lock);return result;
    }
    if (result==XR_SUCCESS || result==XR_EVENT_UNAVAILABLE) {
        if (sf_frame.instance && sf_frame.instance!=instance) {
            uint64_t next=sf_frame.generation+1;
            memset(&sf_frame,0,sizeof(sf_frame));sf_frame.generation=next;
        }
        sf_frame.instance=instance;
    }
    if (result==XR_SUCCESS && event && event->type==XR_TYPE_EVENT_DATA_SESSION_STATE_CHANGED) {
        const XrEventDataSessionStateChanged* change=(const XrEventDataSessionStateChanged*)event;
        sf_frame.instance=instance;sf_frame.focus_session=change->session;sf_frame.focus=change->state;
        ++sf_frame.focus_revision;
#ifdef SIFUVR_SCREEN_EXTENSION
        if (change->state!=XR_SESSION_STATE_FOCUSED) sf_screen_invalidate_locked("session_not_focused");
#endif
        if (change->state==XR_SESSION_STATE_STOPPING || change->state==XR_SESSION_STATE_EXITING || change->state==XR_SESSION_STATE_LOSS_PENDING) {
            sf_frame.time=0;sf_frame.render=0;++sf_frame.generation;
        }
    }
    if (result==XR_SUCCESS && event && event->type==XR_TYPE_EVENT_DATA_REFERENCE_SPACE_CHANGE_PENDING) {
        const XrEventDataReferenceSpaceChangePending* change=(const XrEventDataReferenceSpaceChangePending*)event;
        sf_frame.change_session=change->session;sf_frame.change_time=change->changeTime;
#ifdef SIFUVR_SCREEN_EXTENSION
        sf_screen_invalidate_locked("reference_space_change");
#endif
    }
    ReleaseSRWLockExclusive(&sf_lock);
    return result; /* Observe the original event; do not consume another event. */
}
/* Observe the game's one existing synchronization call. Never synchronize here. */
static XrResult XRAPI_PTR sf_sync(XrSession session,const XrActionsSyncInfo* info) {
    uint64_t generation,revision;
    AcquireSRWLockShared(&sf_lock);
    generation=sf_frame.generation;revision=sf_frame.focus_revision;
    ReleaseSRWLockShared(&sf_lock);
    XrResult result=sf_sync_original(session,info);
    AcquireSRWLockExclusive(&sf_lock);
    /* A later event, destruction, or sync result always wins over this completion. */
    if (generation==sf_frame.generation && revision==sf_frame.focus_revision
        && sf_frame.instance && sf_frame.session==session
        && (!sf_frame.focus_session || sf_frame.focus_session==session)
        && sf_frame.focus!=XR_SESSION_STATE_STOPPING && sf_frame.focus!=XR_SESSION_STATE_EXITING
        && sf_frame.focus!=XR_SESSION_STATE_LOSS_PENDING) {
        sf_frame.focus_session=session;
        sf_frame.focus=result==XR_SUCCESS ? XR_SESSION_STATE_FOCUSED : XR_SESSION_STATE_UNKNOWN;
        ++sf_frame.focus_revision;
    }
    ReleaseSRWLockExclusive(&sf_lock);
    return result;
}
static int sf_get(const char* name,void* out) {
    sf_failure=name;
    if (!sf_getproc) {sf_failure_result=XR_ERROR_FUNCTION_UNSUPPORTED;return 0;}
    sf_failure_result=sf_getproc(sf_instance,name,(PFN_xrVoidFunction*)out);
    return sf_failure_result==XR_SUCCESS && *(void**)out;
}
static void sf_drop_spaces(void) {
    /* Session replacement destroys old session-owned spaces itself; never destroy stale handles. */
    memset(sf_spaces,0,sizeof(sf_spaces));sf_action=sf_aim_action=XR_NULL_HANDLE;sf_last_time=0;sf_applied_change=0;
}
static XrResult XRAPI_PTR sf_destroy_session(XrSession session) {
    /* Three captured crashes begin inside SteamVR xrDestroySession during DLL
       process teardown, after its required singleton has gone. The OS is already
       reclaiming the process. Do not lock, log, call XR or access UEVR here. */
    if (sf_dll_shutdown && sf_dll_shutdown()) return XR_SUCCESS;
    if (sf_teardown_depth) return sf_destroy_session_original(session);
    AcquireSRWLockExclusive(&sf_runtime_lock);
    ++sf_teardown_depth;
    AcquireSRWLockExclusive(&sf_lock);
    #ifdef SIFUVR_SCREEN_EXTENSION
    if (sf_screen_snapshot.session==session) sf_screen_invalidate_locked("session_destroyed");
#endif
    if (sf_frame.session==session || sf_frame.focus_session==session) {
        XrInstance instance=sf_frame.instance;uint64_t generation=sf_frame.generation+1;
        memset(&sf_frame,0,sizeof(sf_frame));sf_frame.instance=instance;sf_frame.generation=generation;
    }
    ReleaseSRWLockExclusive(&sf_lock);
    if (sf_session==session) {sf_drop_spaces();sf_session=XR_NULL_HANDLE;++sf_epoch;sf_invalidated=1;sf_attempts=0;sf_retry_at=0;}
#ifdef SIFUVR_FADE_EXTENSION
    AcquireSRWLockExclusive(&sf_lock);if(sff.session==session)sff_destroy_locked();ReleaseSRWLockExclusive(&sf_lock);
#endif
    XrResult result=sf_destroy_session_original(session);
    --sf_teardown_depth;
    ReleaseSRWLockExclusive(&sf_runtime_lock);
    return result;
}
static XrResult XRAPI_PTR sf_destroy_instance(XrInstance instance) {
    if (sf_dll_shutdown && sf_dll_shutdown()) return XR_SUCCESS;
    if (sf_teardown_depth) return sf_destroy_instance_original(instance);
    AcquireSRWLockExclusive(&sf_runtime_lock);
    ++sf_teardown_depth;
    AcquireSRWLockExclusive(&sf_lock);
    #ifdef SIFUVR_SCREEN_EXTENSION
    if (sf_screen_snapshot.instance==instance) sf_screen_invalidate_locked("instance_destroyed");
#endif
    if (sf_frame.instance==instance) {
        uint64_t generation=sf_frame.generation+1;memset(&sf_frame,0,sizeof(sf_frame));sf_frame.generation=generation;
    }
    ReleaseSRWLockExclusive(&sf_lock);
    if (sf_instance==instance) {sf_drop_spaces();sf_instance=XR_NULL_HANDLE;sf_session=XR_NULL_HANDLE;++sf_epoch;sf_invalidated=1;sf_attempts=0;sf_retry_at=0;}
#ifdef SIFUVR_FADE_EXTENSION
    AcquireSRWLockExclusive(&sf_lock);if(sff.instance==instance)sff_destroy_locked();ReleaseSRWLockExclusive(&sf_lock);
#endif
    XrResult result=sf_destroy_instance_original(instance);
    --sf_teardown_depth;
    ReleaseSRWLockExclusive(&sf_runtime_lock);
    return result;
}
static void sf_backend_destroy(void* runtime) {
    if (sf_dll_shutdown && sf_dll_shutdown()) return;
#ifdef SIFUVR_SCREEN_EXTENSION
    sf_screen_invalidate("backend_destroyed");
#endif
    sf_backend_destroy_original(runtime);
}
static int sf_hooks_ready(void) {
    return sf_wait_hook>=0 && sf_poll_hook>=0 && sf_destroy_session_hook>=0 && sf_destroy_instance_hook>=0
        && sf_wait_original && sf_poll_original && sf_destroy_session_original && sf_destroy_instance_original
        && sf_sync_hook>=0 && sf_sync_original;
}
static int sf_install_hook(PFN_xrVoidFunction target,void* callback,int* id,void** original) {
    if (*id>=0) return *original!=NULL;
    *id=sf_api->functions->register_inline_hook((void*)target,callback,original);
    /* UEVR writes original before enabling. Enable failure destroys that trampoline. */
    if (*id<0) {*original=NULL;return 0;}
    return *original!=NULL;
}
/* UEVR owns its registered hooks and destroys them before late XR teardown.
   Keep only these two shutdown guards in our pinned DLL's C-owned hook storage.
   No MH_Uninitialize/heap cleanup is run in process detach; the OS reclaims it. */
static int sf_install_owned_hook(PFN_xrVoidFunction target,void* callback,int* id,void** original) {
    if (*id>=0) return *original!=NULL;
    MH_STATUS status=MH_Initialize();
    if (status!=MH_OK && status!=MH_ERROR_ALREADY_INITIALIZED) return 0;
    status=MH_CreateHook((void*)target,callback,original);
    if (status!=MH_OK) {*original=NULL;return 0;}
    status=MH_EnableHook((void*)target);
    if (status!=MH_OK) {MH_RemoveHook((void*)target);*original=NULL;return 0;}
    *id=1;return *original!=NULL;
}
static int sf_backend_fingerprint(HMODULE module) {
    static const unsigned char expected_hash[32]={0x1a,0x34,0xcf,0x65,0xe4,0xc1,0x20,0x02,0xec,0x96,0x7e,0xd1,0x67,0xdd,0xda,0x4e,0x1c,0xc7,0xae,0x1d,0xa8,0x21,0x57,0xd0,0xe2,0x79,0x59,0x7b,0xed,0xde,0xed,0x75};
    wchar_t path[32768];if(!GetModuleFileNameW(module,path,32768))return 0;
    HANDLE file=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
    if(file==INVALID_HANDLE_VALUE)return 0;
    BCRYPT_ALG_HANDLE alg=NULL;BCRYPT_HASH_HANDLE hash=NULL;unsigned char digest[32],buffer[65536];DWORD got=0;int ok=0;
    if(BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,NULL,0)<0)goto done;
    if(BCryptCreateHash(alg,&hash,NULL,0,NULL,0,0)<0)goto done;
    for(;;){if(!ReadFile(file,buffer,sizeof(buffer),&got,NULL))goto done;if(!got)break;if(BCryptHashData(hash,buffer,got,0)<0)goto done;}
    if(BCryptFinishHash(hash,digest,sizeof(digest),0)<0)goto done;
    ok=memcmp(digest,expected_hash,sizeof(digest))==0;
done:
    if(hash)BCryptDestroyHash(hash);if(alg)BCryptCloseAlgorithmProvider(alg,0);CloseHandle(file);return ok;
}
static int sf_install_backend_guard(void) {
    /* Exact pinned nightly SHA and entire227-byte function are both required.
       Source/PE/unwind identify OpenXR::destroy; ordinary calls forward unchanged. */
    static const unsigned char expected_code[]={0x48,0x89,0x5c,0x24,0x10,0x57,0x48,0x83,0xec,0x20,0x48,0x8b,0xd9,0x80,0x79,0x08,0x00,0x0f,0x84,0xa1,0x00,0x00,0x00,0x48,0x8d,0xb9,0xe0,0x02,0x00,0x00,0x48,0x89,0x7c,0x24,0x30,0x48,0x8b,0xcf,0xe8,0xc5,0x39,0x53,0x00,0x85,0xc0,0x0f,0x85,0xa5,0x00,0x00,0x00,0x81,0xbb,0x2c,0x03,0x00,0x00,0xff,0xff,0xff,0x7f,0x0f,0x84,0x80,0x00,0x00,0x00,0x48,0x8b,0x8b,0x20,0x04,0x00,0x00,0x48,0x85,0xc9,0x74,0x19,0x38,0x83,0xd0,0x02,0x00,0x00,0x74,0x05,0xe8,0x84,0xb0,0x12,0x00,0x48,0x8b,0x8b,0x20,0x04,0x00,0x00,0xe8,0x18,0xaf,0x12,0x00,0x48,0x8b,0x0d,0xa9,0xf8,0x90,0x00,0x48,0x85,0xc9,0x74,0x19,0x80,0xbb,0xa1,0x09,0x00,0x00,0x00,0x74,0x10,0xe8,0x4e,0xa9,0x12,0x00,0x48,0xc7,0x05,0x8b,0xf8,0x90,0x00,0x00,0x00,0x00,0x00,0x48,0xc7,0x83,0x20,0x04,0x00,0x00,0x00,0x00,0x00,0x00,0x66,0xc7,0x83,0xd0,0x02,0x00,0x00,0x00,0x00,0x48,0xc7,0x83,0x38,0x04,0x00,0x00,0x00,0x00,0x00,0x00,0xc6,0x43,0x0f,0x00,0x48,0x8b,0xcf,0xe8,0x58,0x3a,0x53,0x00,0x48,0x8b,0x5c,0x24,0x38,0x48,0x83,0xc4,0x20,0x5f,0xc3,0xc7,0x83,0x2c,0x03,0x00,0x00,0xfe,0xff,0xff,0x7f,0xb9,0x06,0x00,0x00,0x00,0xe8,0x39,0x3e,0x53,0x00,0xcc,0xb9,0x05,0x00,0x00,0x00,0xe8,0x2e,0x3e,0x53,0x00,0xcc};
    HMODULE backend=sf_api->uevr_module;
    if(!backend || !sf_backend_fingerprint(backend))return 0;
    unsigned char* target=(unsigned char*)backend+0x18f050;
    if(memcmp(target,expected_code,sizeof(expected_code)))return 0;
    return sf_install_owned_hook((PFN_xrVoidFunction)target,(void*)sf_backend_destroy,&sf_backend_hook,(void**)&sf_backend_destroy_original);
}
static int sf_bind(void) {
    if (!sf_get("xrCreateActionSpace",&sf_create) || !sf_get("xrDestroySpace",&sf_destroy) || !sf_get("xrStringToPath",&sf_path) || !sf_get("xrLocateSpace",&sf_locate) || !sf_get("xrGetActionStatePose",&sf_state)) return 0;
    sf_action=(XrAction)sf_api->vr->get_action_handle("/actions/default/in/GripPose");
    sf_aim_action=(XrAction)sf_api->vr->get_action_handle("/actions/default/in/Pose");
    if (!sf_action || !sf_aim_action) {sf_failure="UEVR grip/aim handles";sf_failure_result=XR_ERROR_HANDLE_INVALID;return 0;}
    for (int i=0;i<2;++i) {
        sf_failure=i==0?"left xrStringToPath":"right xrStringToPath";
        sf_failure_result=sf_path(sf_instance,i==0?"/user/hand/left":"/user/hand/right",&sf_paths[i]);
        if (sf_failure_result!=XR_SUCCESS) goto failed;
    }
    for (int i=0;i<4;++i) {
        XrActionSpaceCreateInfo ci={XR_TYPE_ACTION_SPACE_CREATE_INFO};
        ci.action=i<2?sf_action:sf_aim_action;ci.subactionPath=sf_paths[i%2];ci.poseInActionSpace.orientation.w=1.f;
        sf_failure=i<2?"grip xrCreateActionSpace":"aim xrCreateActionSpace";
        sf_failure_result=sf_create(sf_session,&ci,&sf_spaces[i]);
        if (sf_failure_result!=XR_SUCCESS) goto failed;
    }
    return 1;
failed:
    for (int i=0;i<4;++i) {if (sf_spaces[i]) sf_destroy(sf_spaces[i]);sf_spaces[i]=XR_NULL_HANDLE;}
    return 0;
}
static int sf_hooks(void) {
    XrInstance instance=(XrInstance)sf_api->openxr->get_xr_instance();
    HMODULE loader=GetModuleHandleW(L"openxr_loader.dll");
    sf_failure="OpenXR module";sf_failure_result=XR_ERROR_INITIALIZATION_FAILED;
    if (!loader || !instance) return 0;
    sf_getproc=(PFN_xrGetInstanceProcAddr)GetProcAddress(loader,"xrGetInstanceProcAddr");
    PFN_xrVoidFunction wait=NULL,poll=NULL,destroy_session=NULL,destroy_instance=NULL,sync=NULL;
    sf_failure="loader xrGetInstanceProcAddr";
    sf_failure_result=sf_getproc?sf_getproc(instance,"xrWaitFrame",&wait):XR_ERROR_FUNCTION_UNSUPPORTED;
    if (sf_failure_result==XR_ERROR_HANDLE_INVALID) {
        /* This pinned UEVR backend statically links its loader. The separately injected
           loader DLL has a different instance registry. Query the already loaded
           SteamVR runtime interface; never create another XR instance or session. */
        HMODULE runtime=GetModuleHandleW(L"vrclient_x64.dll");
        sf_failure="existing SteamVR runtime interface";
        if (!runtime) return 0;
        PFN_xrNegotiateLoaderRuntimeInterface negotiate=(PFN_xrNegotiateLoaderRuntimeInterface)GetProcAddress(runtime,"xrNegotiateLoaderRuntimeInterface");
        if (!negotiate) return 0;
        XrNegotiateLoaderInfo info={XR_LOADER_INTERFACE_STRUCT_LOADER_INFO,XR_LOADER_INFO_STRUCT_VERSION,sizeof(info),1,1,XR_MAKE_VERSION(1,0,0),XR_CURRENT_API_VERSION};
        XrNegotiateRuntimeRequest request={XR_LOADER_INTERFACE_STRUCT_RUNTIME_REQUEST,XR_RUNTIME_INFO_STRUCT_VERSION,sizeof(request)};
        sf_failure_result=negotiate(&info,&request);
        if (sf_failure_result!=XR_SUCCESS || request.runtimeInterfaceVersion!=1 || !request.getInstanceProcAddr) return 0;
        sf_getproc=request.getInstanceProcAddr;
        sf_failure="SteamVR xrWaitFrame dispatch";
        sf_failure_result=sf_getproc(instance,"xrWaitFrame",&wait);
        if (sf_failure_result==XR_SUCCESS) sf_api->functions->log_info("[BOLT-TRACKING-0.2] resolved existing SteamVR dispatch; separate loader registry rejected instance");
    }
    if (sf_failure_result!=XR_SUCCESS || !wait) return 0;
    sf_failure="xrPollEvent dispatch";sf_failure_result=sf_getproc(instance,"xrPollEvent",&poll);
    if (sf_failure_result!=XR_SUCCESS || !poll) return 0;
    sf_failure="xrDestroySession dispatch";sf_failure_result=sf_getproc(instance,"xrDestroySession",&destroy_session);
    if (sf_failure_result!=XR_SUCCESS || !destroy_session) return 0;
    sf_failure="xrDestroyInstance dispatch";sf_failure_result=sf_getproc(instance,"xrDestroyInstance",&destroy_instance);
    if (sf_failure_result!=XR_SUCCESS || !destroy_instance) return 0;
    sf_failure="xrSyncActions dispatch";sf_failure_result=sf_getproc(instance,"xrSyncActions",&sync);
    if (sf_failure_result!=XR_SUCCESS || !sync) return 0;
    sf_failure="OpenXR runtime inline hooks";
    /* Protect handle lifetime before enabling frame observation. Partial registration
       is inert: no pose queries occur until all five registrations succeeded. */
    if (!sf_install_owned_hook(destroy_session,(void*)sf_destroy_session,&sf_destroy_session_hook,(void**)&sf_destroy_session_original)
        || !sf_install_owned_hook(destroy_instance,(void*)sf_destroy_instance,&sf_destroy_instance_hook,(void**)&sf_destroy_instance_original)
        || !sf_install_hook(wait,(void*)sf_wait,&sf_wait_hook,(void**)&sf_wait_original)
        || !sf_install_hook(poll,(void*)sf_poll,&sf_poll_hook,(void**)&sf_poll_original)
        || !sf_install_hook(sync,(void*)sf_sync,&sf_sync_hook,(void**)&sf_sync_original)) return 0;
    int ready=sf_hooks_ready();
    if (ready) sf_api->functions->log_info("[BOLT-TRACKING-0.3.3] lifecycle hooks ready; owned shutdown guards: wait=%d poll=%d destroy_session=%d destroy_instance=%d",sf_wait_hook,sf_poll_hook,sf_destroy_session_hook,sf_destroy_instance_hook);
    return ready;
}

#ifdef SIFUVR_SCREEN_EXTENSION
static void sf_pose_json(char* dst,size_t size,XrSpace space,XrSpace stage,XrTime time,int active,int gate,int grip,int* tracked_out) {
#else
static void sf_pose_json(char* dst,size_t size,XrSpace space,XrSpace stage,XrTime time,int active,int gate,int grip) {
#endif
    XrSpaceVelocity velocity={XR_TYPE_SPACE_VELOCITY};
    XrSpaceLocation location={XR_TYPE_SPACE_LOCATION,&velocity};
    location.pose.orientation.w=1;
    XrResult result=sf_locate(space,stage,time,&location);
    float p[3]={location.pose.position.x,location.pose.position.y,location.pose.position.z};
    float q[4]={location.pose.orientation.x,location.pose.orientation.y,location.pose.orientation.z,location.pose.orientation.w};
    int valid=gate && sf_pose_valid(result,active,location.locationFlags,p,q);
#ifdef SIFUVR_SCREEN_EXTENSION
    if (tracked_out) *tracked_out=valid;
#endif
    if (!valid) {memset(p,0,sizeof(p));memset(q,0,sizeof(q));q[3]=1;}
    /* Velocity is measured separately by the core from timed positions; raw validity remains visible. */
    snprintf(dst,size,"{\"tracked\":%s,\"active\":%s,\"flags\":%llu,\"result\":%d,\"grip\":%s,\"position\":{\"x\":%.7g,\"y\":%.7g,\"z\":%.7g},\"rotation\":{\"x\":%.7g,\"y\":%.7g,\"z\":%.7g,\"w\":%.7g}}",valid?"true":"false",active?"true":"false",(unsigned long long)location.locationFlags,(int)result,grip?"true":"false",p[0],p[1],p[2],q[0],q[1],q[2],q[3]);
}
static int sf_invalid_json(char* payload,size_t size,const char* reason) {
#ifdef SIFUVR_MOTION_INPUT_EXTENSION
    sfm_invalidate();
#endif
#ifdef SIFUVR_SCREEN_EXTENSION
    sf_screen_invalidate(reason);
#endif
    if (!sf_invalidated) {++sf_epoch;sf_invalidated=1;}
    sf_last_time=0;
    snprintf(payload,size,"{\"version\":\"0.2\",\"mode\":\"observe_only\",\"combat_enabled\":false,\"sequence\":%llu,\"epoch\":%llu,\"t\":0,\"fresh\":false,\"focused\":false,\"foreground\":false,\"reason\":\"%s\",\"head\":{\"tracked\":false},\"hands\":{\"left\":{\"tracked\":false},\"right\":{\"tracked\":false}},\"aims\":{\"left\":{\"tracked\":false},\"right\":{\"tracked\":false}}}",(unsigned long long)++sf_sequence,(unsigned long long)sf_epoch,reason);
    return 1;
}
static int sf_sample_json(char* payload,size_t size) {
    if (!sf_api->vr->is_openxr() || !sf_api->vr->is_runtime_ready()) return sf_invalid_json(payload,size,"runtime_unavailable");
    /* Use handles proven by calls through this loader, not an unverified API snapshot. */
    if (!sf_hooks_ready()) {
        if (sf_attempts>=3 || GetTickCount64()<sf_retry_at) return sf_invalid_json(payload,size,"hooks_unavailable");
        ++sf_attempts;sf_retry_at=GetTickCount64()+1000;
        if (!sf_hooks()) {sf_api->functions->log_warn("[BOLT-TRACKING-0.3.3] hooks failed stage=%s",sf_failure);return sf_invalid_json(payload,size,"hooks_failed");}
    }
    SfFrame frame;
    AcquireSRWLockShared(&sf_lock);
    frame=sf_frame;
    ReleaseSRWLockShared(&sf_lock);
    XrInstance instance=frame.instance;XrSession session=frame.session;
    if (!instance || !session) return sf_invalid_json(payload,size,"no_observed_session");
    if (instance!=(XrInstance)sf_api->openxr->get_xr_instance() || session!=(XrSession)sf_api->openxr->get_xr_session())
        return sf_invalid_json(payload,size,"session_mismatch");
    if (instance!=sf_instance || session!=sf_session) {
        sf_drop_spaces();sf_instance=instance;sf_session=session;++sf_epoch;sf_attempts=0;sf_retry_at=0;
    }
    XrTime time=frame.time,change=frame.change_session==session?frame.change_time:0;
    int focused=frame.focus_session==session && frame.focus==XR_SESSION_STATE_FOCUSED;
    LARGE_INTEGER now;
    QueryPerformanceCounter(&now);
    DWORD foreground_pid=0;GetWindowThreadProcessId(GetForegroundWindow(),&foreground_pid);
    int foreground=foreground_pid==GetCurrentProcessId();
    int gate=sf_frame_valid(1,now.QuadPart-frame.ticks,sf_frequency.QuadPart,frame.render,focused,foreground) && !sf_api->functions->is_drawing_ui();
    if (!gate || time<=0) return sf_invalid_json(payload,size,"frame_gate");
    /* Publish invalidation too; unchanged or expired frames must never become fresh motion. */
    if (change>0 && change!=sf_applied_change && time>=change) {++sf_epoch;sf_last_time=0;sf_applied_change=change;}
    int fresh=time>0 && time>sf_last_time;
    if (time>0 && time<sf_last_time) {++sf_epoch;sf_last_time=0;}
    if (time==sf_last_time) return 0; /* No duplicate-timestamp motion sample. */
    if (!fresh) return sf_invalid_json(payload,size,"time_discontinuity");
    gate=gate && fresh;
    if (fresh) sf_last_time=time;
    XrSpace stage=(XrSpace)sf_api->openxr->get_stage_space();
    XrSpace view=(XrSpace)sf_api->openxr->get_view_space();
    if (!stage || !view) return sf_invalid_json(payload,size,"spaces_unavailable");
#ifdef SIFUVR_MOTION_INPUT_EXTENSION
    sfm_observe_stage(stage);
#endif
    if (!sf_spaces[0] || !sf_spaces[1] || !sf_spaces[2] || !sf_spaces[3]) {
        if (sf_attempts>=3 || GetTickCount64()<sf_retry_at) return sf_invalid_json(payload,size,"bind_unavailable");
        ++sf_attempts;sf_retry_at=GetTickCount64()+1000;
        if (!sf_bind()) {sf_api->functions->log_warn("[BOLT-TRACKING-0.3.3] bind attempt %d failed stage=%s xr_result=%d",sf_attempts,sf_failure,(int)sf_failure_result);return sf_invalid_json(payload,size,"bind_failed");}
        sf_api->functions->log_info("[BOLT-TRACKING-0.3.3] bound; observed_instance=%p api_instance=%p observed_session=%p api_session=%p; lifetime protected",(void*)sf_instance,(void*)sf_api->openxr->get_xr_instance(),(void*)sf_session,(void*)sf_api->openxr->get_xr_session());
    }
    char head[512]="{\"tracked\":false}",hands[2][512]={"{\"tracked\":false}","{\"tracked\":false}"};
    char aims[2][512]={"{\"tracked\":false}","{\"tracked\":false}"};
#ifdef SIFUVR_SCREEN_EXTENSION
    int screen_head_valid=0;
#ifdef SIFUVR_MOTION_INPUT_EXTENSION
    int motion_hands[2]={0};
#endif
#endif
    if (gate) {
#ifdef SIFUVR_SCREEN_EXTENSION
        sf_pose_json(head,sizeof(head),view,stage,time,1,gate,0,&screen_head_valid);
#else
        sf_pose_json(head,sizeof(head),view,stage,time,1,gate,0);
#endif
        for (int i=0;i<2;++i) {
            XrActionStateGetInfo gi={XR_TYPE_ACTION_STATE_GET_INFO};gi.action=sf_action;gi.subactionPath=sf_paths[i];
            XrActionStatePose ps={XR_TYPE_ACTION_STATE_POSE};
            XrResult res=sf_state(session,&gi,&ps);
            UEVR_InputSourceHandle source=i==0?sf_api->vr->get_left_joystick_source():sf_api->vr->get_right_joystick_source();
            UEVR_ActionHandle grip=sf_api->vr->get_action_handle("/actions/default/in/Grip");
#ifdef SIFUVR_SCREEN_EXTENSION
            #ifdef SIFUVR_MOTION_INPUT_EXTENSION
            sf_pose_json(hands[i],sizeof(hands[i]),sf_spaces[i],stage,time,res==XR_SUCCESS && ps.isActive,gate,grip && sf_api->vr->is_action_active(grip,source),&motion_hands[i]);
#else
            sf_pose_json(hands[i],sizeof(hands[i]),sf_spaces[i],stage,time,res==XR_SUCCESS && ps.isActive,gate,grip && sf_api->vr->is_action_active(grip,source),NULL);
#endif
#else
            sf_pose_json(hands[i],sizeof(hands[i]),sf_spaces[i],stage,time,res==XR_SUCCESS && ps.isActive,gate,grip && sf_api->vr->is_action_active(grip,source));
#endif
            gi.action=sf_aim_action;ps.isActive=0;
            res=sf_state(session,&gi,&ps);
            sf_pose_json(aims[i],sizeof(aims[i]),sf_spaces[i+2],stage,time,res==XR_SUCCESS && ps.isActive,gate,0);
        }
    }
    sf_invalidated=0;
#ifdef SIFUVR_MOTION_INPUT_EXTENSION
    sfm_publish(&frame,screen_head_valid,motion_hands[0],motion_hands[1]);
#endif
#ifdef SIFUVR_SCREEN_EXTENSION
    sf_screen_sample(stage,frame.generation,screen_head_valid);
#endif
    snprintf(payload,size,"{\"version\":\"0.2\",\"mode\":\"observe_only\",\"combat_enabled\":false,\"sequence\":%llu,\"epoch\":%llu,\"t\":%.9f,\"fresh\":%s,\"focused\":%s,\"foreground\":%s,\"head\":%s,\"hands\":{\"left\":%s,\"right\":%s},\"aims\":{\"left\":%s,\"right\":%s}}",(unsigned long long)++sf_sequence,(unsigned long long)sf_epoch,(double)time/1e9,fresh?"true":"false",focused?"true":"false",foreground?"true":"false",head,hands[0],hands[1],aims[0],aims[1]);
    return 1;
}
static char sf_process_nonce[96];
static void sf_identify_process(void) {
    if (sf_process_nonce[0]) return;
    FILETIME created,ended,kernel,user;
    if (!GetProcessTimes(GetCurrentProcess(),&created,&ended,&kernel,&user)) return;
    ULARGE_INTEGER start;start.LowPart=created.dwLowDateTime;start.HighPart=created.dwHighDateTime;
    snprintf(sf_process_nonce,sizeof(sf_process_nonce),"%lu:%llu",(unsigned long)GetCurrentProcessId(),(unsigned long long)start.QuadPart);
}
static void sf_tick(UEVR_UGameEngineHandle engine,float delta) {
    (void)engine;(void)delta;
    if (sf_dll_shutdown && sf_dll_shutdown()) return;
    char payload[4096];
    AcquireSRWLockShared(&sf_runtime_lock);
    int publish=sf_sample_json(payload,sizeof(payload));
    ReleaseSRWLockShared(&sf_runtime_lock);
    /* No engine callback or Lua execution while holding the XR lifetime lock. */
    if (publish) {
        LARGE_INTEGER clock;QueryPerformanceCounter(&clock);sf_identify_process();
        size_t length=strlen(payload);
        if (length>0 && payload[length-1]=='}' && sf_frequency.QuadPart>0) {
            int added=snprintf(payload+length-1,sizeof(payload)-length+1,
                ",\"bridge\":\"boltgun-tracking-v1\",\"clock_qpc\":%.9f,\"observer_revision\":2,\"process_nonce\":\"%s\"}",
                (double)clock.QuadPart/(double)sf_frequency.QuadPart,sf_process_nonce);
            if (added>0 && (size_t)added<sizeof(payload)-length+1)
                sf_api->functions->dispatch_lua_event("boltgun_tracking_v1",payload);
        }
    }
#ifdef SIFUVR_SCREEN_EXTENSION
    sf_screen_status();
#ifdef SIFUVR_FADE_EXTENSION
    sff_status();
#endif
#endif
}
__declspec(dllexport) void uevr_plugin_required_version(UEVR_PluginVersion* version) {
    version->major=UEVR_PLUGIN_VERSION_MAJOR;version->minor=UEVR_PLUGIN_VERSION_MINOR;version->patch=UEVR_PLUGIN_VERSION_PATCH;
}
__declspec(dllexport) bool uevr_plugin_initialize(const UEVR_PluginInitializeParam* api) {
    if (!api || !api->functions || !api->functions->register_inline_hook || !api->functions->dispatch_lua_event || !api->sdk || !api->sdk->callbacks || !api->vr || !api->openxr) return false;
    if (sf_initialized) {
        api->functions->log_warn("[BOLT-TRACKING-0.3.3] plugin reload disabled: restart game to replace pinned native hooks");
        return false;
    }
    HMODULE ntdll=GetModuleHandleW(L"ntdll.dll");
    sf_dll_shutdown=ntdll?(SfDllShutdownInProgress)GetProcAddress(ntdll,"RtlDllShutdownInProgress"):NULL;
    if (!sf_dll_shutdown) return false;
    /* Pinned UEVR unloads plugin DLLs before clearing inline hooks. Keep our tiny
       detours/code alive until process exit; use a process restart for DLL updates.
       Do not call hook teardown, wait or XR functions from DllMain/loader lock. */
    HMODULE self=NULL;
    if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_PIN,(LPCWSTR)(uintptr_t)&uevr_plugin_initialize,&self)) return false;
    sf_api=api;QueryPerformanceFrequency(&sf_frequency);
#ifdef SIFUVR_SCREEN_EXTENSION
    sfs_reset(&sf_screen_policy);
    sf_screen_backend_verified=api->uevr_module && sf_backend_fingerprint(api->uevr_module);
    if (sf_screen_backend_verified && api->callbacks && api->callbacks->on_custom_event && api->vr->get_mod_value)
        sf_screen_callback_ready=api->callbacks->on_custom_event(sf_screen_event);
#ifdef SIFUVR_FADE_EXTENSION
    if(sf_screen_callback_ready)sf_screen_callback_ready=api->callbacks->on_custom_event(sff_event);
    if(sf_screen_callback_ready)api->functions->log_info("[SIFUVR-SCREEN-0.7] loaded; stage anchor plus DX11 full-FOV fade, actual HMD presentation unverified");
#endif
#endif
    if(sf_install_backend_guard())api->functions->log_info("[BOLT-TRACKING-0.3.3] exact-build backend teardown guard ready; SHA256 verified");
    else api->functions->log_warn("[BOLT-TRACKING-0.3.3] backend teardown guard unavailable: binary fingerprint mismatch or hook failure");
    if (!api->sdk->callbacks->on_pre_engine_tick(sf_tick)) return false;
    sf_initialized=1;
    api->functions->log_info("[BOLT-TRACKING-0.3.3] loaded; session destruction serialized; pinned until process exit; schema 0.2; no combat writes");
    return true;
}
