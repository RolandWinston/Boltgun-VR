/* Test-only DLL. Executes the actual candidate guards under Windows process
   detach; shared memory contains only integer test results. No game or XR calls. */
#include "tracking_bridge.c"
static volatile LONG* result;
static __declspec(noinline) XrResult XRAPI_PTR forbidden_session(XrSession s) {(void)s;++result[4];return XR_ERROR_RUNTIME_FAILURE;}
static __declspec(noinline) XrResult XRAPI_PTR forbidden_instance(XrInstance i) {(void)i;++result[5];return XR_ERROR_RUNTIME_FAILURE;}
static __declspec(noinline) void forbidden_backend(void* p) {(void)p;++result[7];}
__declspec(dllexport) int supervisor_prepare_shutdown(volatile LONG* shared) {
 result=shared;
 HMODULE module=GetModuleHandleW(L"ntdll.dll");
 sf_dll_shutdown=(SfDllShutdownInProgress)GetProcAddress(module,"RtlDllShutdownInProgress");
 if (!sf_dll_shutdown || sf_dll_shutdown())return 0;
 int a=-1,b=-1,c=-1;
 if(!sf_install_owned_hook((PFN_xrVoidFunction)forbidden_backend,(void*)sf_backend_destroy,&c,(void**)&sf_backend_destroy_original))return 0;
 if(!sf_install_owned_hook((PFN_xrVoidFunction)forbidden_session,(void*)sf_destroy_session,&a,(void**)&sf_destroy_session_original))return 0;
 if(!sf_install_owned_hook((PFN_xrVoidFunction)forbidden_instance,(void*)sf_destroy_instance,&b,(void**)&sf_destroy_instance_original))return 0;
 /* Before teardown, original calls and return values must be preserved. */
 PFN_xrDestroySession volatile session_call=forbidden_session;
 PFN_xrDestroyInstance volatile instance_call=forbidden_instance;
 if(session_call((XrSession)2)!=XR_ERROR_RUNTIME_FAILURE || instance_call((XrInstance)1)!=XR_ERROR_RUNTIME_FAILURE)return 0;
 if(result[4]!=1 || result[5]!=1)return 0;
 void (*volatile backend_call)(void*)=forbidden_backend;backend_call(NULL);if(result[7]!=1)return 0;
 result[4]=result[5]=result[7]=0;
 /* No UEVR callback table/container survives. Our code and owned guards do. */
 sf_api=NULL;
 /* Simulate a lock left behind by a terminated worker. Detach must not wait. */
 AcquireSRWLockExclusive(&sf_runtime_lock);result[0]=12345;return 1;
}
BOOL WINAPI DllMain(HINSTANCE instance,DWORD reason,LPVOID reserved) {
 (void)instance;
 if(reason==DLL_PROCESS_DETACH && reserved && result) {
  result[1]=sf_dll_shutdown();
  PFN_xrDestroySession volatile session_call=forbidden_session;
  PFN_xrDestroyInstance volatile instance_call=forbidden_instance;
  result[2]=session_call((XrSession)2);
  result[3]=instance_call((XrInstance)1);
  void (*volatile backend_call)(void*)=forbidden_backend;backend_call(NULL);
  result[6]=67890;
 }
 return TRUE;
}
