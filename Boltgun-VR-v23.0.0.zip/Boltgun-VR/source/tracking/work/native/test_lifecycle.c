/* Regression harness: local fake XR runtime only; no game, loader or VR process. */
#define main legacy_bridge_main
#include "test_bridge.c"
#undef main
static int runtime_ready=1,pose_calls=0,state_calls=0;
static uintptr_t api_session=2;
static volatile LONG live_queries;
static HANDLE query_entered,query_release;
static int session_dead;
#ifdef SIFUVR_TRACKING_LIFECYCLE
static HANDLE destruction_entered,destruction_called;
static int destroy_session_calls,destroy_instance_calls,nested_destroy;
#endif
static bool ready(void) {return runtime_ready!=0;}
static UEVR_XrSession current_session(void) {return (UEVR_XrSession)api_session;}
static XrResult XRAPI_PTR lost_poll(XrInstance i,XrEventDataBuffer* e) {(void)i;(void)e;return XR_ERROR_INSTANCE_LOST;}
static XrResult XRAPI_PTR counted_locate(XrSpace s,XrSpace b,XrTime t,XrSpaceLocation* l) {
 assert(!session_dead);InterlockedIncrement(&live_queries);
 if (query_entered) {SetEvent(query_entered);assert(WaitForSingleObject(query_release,3000)==WAIT_OBJECT_0);}
 ++pose_calls;XrResult r=fake_locate(s,b,t,l);InterlockedDecrement(&live_queries);return r;
}
static XrResult XRAPI_PTR counted_state(XrSession s,const XrActionStateGetInfo* i,XrActionStatePose* p) {
 assert(!session_dead);++state_calls;return fake_state(s,i,p);
}
#ifdef SIFUVR_TRACKING_LIFECYCLE
static XrResult XRAPI_PTR counted_destroy_session(XrSession s) {
 (void)s;assert(!live_queries);++destroy_session_calls;session_dead=1;
 if(destruction_called)SetEvent(destruction_called);return XR_SUCCESS;
}
static XrResult XRAPI_PTR counted_destroy_instance(XrInstance i) {
 (void)i;assert(!live_queries);++destroy_instance_calls;
 if(nested_destroy)assert(sf_destroy_session((XrSession)2)==XR_SUCCESS);
 return XR_SUCCESS;
}
static DWORD WINAPI tick_worker(void* unused) {(void)unused;sf_tick(NULL,0);return 0;}
static DWORD WINAPI destroy_worker(void* unused) {(void)unused;SetEvent(destruction_entered);assert(sf_destroy_session((XrSession)2)==XR_SUCCESS);return 0;}
static HANDLE wait_entered,wait_release;
static XrResult XRAPI_PTR late_wait(XrSession s,const XrFrameWaitInfo* i,XrFrameState* fs) {
 SetEvent(wait_entered);assert(WaitForSingleObject(wait_release,3000)==WAIT_OBJECT_0);return fake_wait(s,i,fs);
}
static DWORD WINAPI wait_worker(void* unused) {
 (void)unused;XrFrameState state={XR_TYPE_FRAME_STATE};assert(sf_wait((XrSession)2,NULL,&state)==XR_SUCCESS);return 0;
}
static int failed_registration(void* target,void* dest,void** original) {
 (void)target;(void)dest;*original=(void*)(uintptr_t)0x1234;return -1;
}
static BOOLEAN WINAPI terminating(void) {return TRUE;}
#endif
static void setup(void) {
 static UEVR_VRData vr;
 static UEVR_OpenXRData xr;
 static UEVR_PluginFunctions fn;
 static UEVR_PluginInitializeParam api;
 vr.is_openxr=yes;vr.is_runtime_ready=ready;vr.get_action_handle=action;
 vr.get_left_joystick_source=left;vr.get_right_joystick_source=right;vr.is_action_active=grip;
 xr.get_xr_instance=instance;xr.get_xr_session=current_session;xr.get_stage_space=stage;xr.get_view_space=view;
 fn.log_info=fake_log;fn.log_warn=fake_log;fn.is_drawing_ui=drawing;fn.dispatch_lua_event=dispatch;
 api.vr=&vr;api.openxr=&xr;api.functions=&fn;sf_api=&api;
 sf_instance=(XrInstance)1;sf_session=(XrSession)2;sf_frame.instance=(XrInstance)1;
 sf_frame.focus_session=(XrSession)2;sf_frame.focus=XR_SESSION_STATE_FOCUSED;
 sf_getproc=fake_getproc;sf_wait_original=fake_wait;sf_poll_original=fake_poll;sf_frequency.QuadPart=1000000;
#ifdef SIFUVR_TRACKING_LIFECYCLE
 sf_wait_hook=1;sf_poll_hook=2;sf_destroy_session_hook=3;sf_destroy_instance_hook=4;sf_sync_hook=5;sf_sync_original=fake_sync;
 sf_destroy_session_original=counted_destroy_session;sf_destroy_instance_original=counted_destroy_instance;
#endif
 assert(sf_bind());sf_locate=counted_locate;sf_state=counted_state;
 sample();assert(count("\"tracked\":true")==5);
 pose_calls=state_calls=0;
}
static int fail(const char* text) {fprintf(stderr,"FAIL: %s\n",text);return 42;}
#ifndef SIFU_LIFECYCLE_MAIN
#define SIFU_LIFECYCLE_MAIN main
#endif
int SIFU_LIFECYCLE_MAIN(int argc,char** argv) {
 assert(argc==2);setup();
 if (!strcmp(argv[1],"runtime-unavailable")) {
  int before=dispatches;runtime_ready=0;sf_tick(NULL,0);
  if(dispatches!=before+1 || count("\"tracked\":true")!=0 || !strstr(captured,"\"fresh\":false"))
   return fail("runtime shutdown must immediately revoke last valid sample");
 } else if (!strcmp(argv[1],"api-session-replaced")) {
  api_session=3;sample();
  if(pose_calls || state_calls || count("\"tracked\":true"))
   return fail("must not query cached session after UEVR changed session handle");
 } else if (!strcmp(argv[1],"session-stopping")) {
  sf_frame.focus=XR_SESSION_STATE_STOPPING;sample();
  if(pose_calls || state_calls)
   return fail("STOPPING must issue no additional pose or action calls");
 } else if (!strcmp(argv[1],"poll-instance-lost")) {
  sf_poll_original=lost_poll;XrEventDataBuffer ev={XR_TYPE_EVENT_DATA_BUFFER};assert(sf_poll((XrInstance)1,&ev)==XR_ERROR_INSTANCE_LOST);sample();
  if(pose_calls || state_calls || count("\"tracked\":true"))return fail("instance loss cannot leave cached focused frame valid");
 }
#ifdef SIFUVR_TRACKING_LIFECYCLE
 else if (!strcmp(argv[1],"destroy-session")) {
  uint64_t epoch=sf_epoch;assert(sf_destroy_session((XrSession)2)==XR_SUCCESS);
  sf_tick(NULL,0);
  assert(destroy_session_calls==1 && sf_epoch>epoch && !sf_spaces[0] && !sf_spaces[1]);
  assert(!pose_calls && !state_calls && !count("\"tracked\":true"));
 } else if (!strcmp(argv[1],"nested-destroy-instance")) {
  nested_destroy=1;assert(sf_destroy_instance((XrInstance)1)==XR_SUCCESS);sf_tick(NULL,0);
  assert(destroy_session_calls==1 && destroy_instance_calls==1 && !sf_instance && !sf_session);
  assert(!pose_calls && !state_calls && !count("\"tracked\":true"));
 } else if (!strcmp(argv[1],"late-wait-after-destroy")) {
  wait_entered=CreateEventW(NULL,TRUE,FALSE,NULL);wait_release=CreateEventW(NULL,TRUE,FALSE,NULL);
  sf_wait_original=late_wait;HANDLE thread=CreateThread(NULL,0,wait_worker,NULL,0,NULL);assert(thread);
  assert(WaitForSingleObject(wait_entered,3000)==WAIT_OBJECT_0);
  assert(sf_destroy_session((XrSession)2)==XR_SUCCESS);SetEvent(wait_release);
  assert(WaitForSingleObject(thread,3000)==WAIT_OBJECT_0);sf_tick(NULL,0);
  assert(!sf_frame.session && !sf_frame.time && !pose_calls && !state_calls);
  CloseHandle(thread);CloseHandle(wait_entered);CloseHandle(wait_release);
 } else if (!strcmp(argv[1],"destroy-waits-for-sampling")) {
  query_entered=CreateEventW(NULL,TRUE,FALSE,NULL);query_release=CreateEventW(NULL,TRUE,FALSE,NULL);
  destruction_entered=CreateEventW(NULL,TRUE,FALSE,NULL);destruction_called=CreateEventW(NULL,TRUE,FALSE,NULL);
  XrFrameState state={XR_TYPE_FRAME_STATE};++test_ticks;assert(sf_wait((XrSession)2,NULL,&state)==XR_SUCCESS);
  HANDLE reader=CreateThread(NULL,0,tick_worker,NULL,0,NULL);assert(reader);
  assert(WaitForSingleObject(query_entered,3000)==WAIT_OBJECT_0);
  HANDLE destroyer=CreateThread(NULL,0,destroy_worker,NULL,0,NULL);assert(destroyer);
  assert(WaitForSingleObject(destruction_entered,3000)==WAIT_OBJECT_0);
  assert(WaitForSingleObject(destruction_called,50)==WAIT_TIMEOUT);SetEvent(query_release);
  assert(WaitForSingleObject(reader,3000)==WAIT_OBJECT_0);assert(WaitForSingleObject(destroyer,3000)==WAIT_OBJECT_0);
  assert(destroy_session_calls==1 && live_queries==0);pose_calls=state_calls=0;sf_tick(NULL,0);
  assert(!pose_calls && !state_calls && !count("\"tracked\":true"));
  CloseHandle(reader);CloseHandle(destroyer);CloseHandle(query_entered);CloseHandle(query_release);CloseHandle(destruction_entered);CloseHandle(destruction_called);
 } else if (!strcmp(argv[1],"failed-hook-clears-trampoline")) {
  UEVR_PluginFunctions fn=*sf_api->functions;UEVR_PluginInitializeParam api=*sf_api;
  fn.register_inline_hook=failed_registration;api.functions=&fn;sf_api=&api;
  int id=-1;void* original=NULL;
  assert(!sf_install_hook((PFN_xrVoidFunction)fake_wait,(void*)sf_wait,&id,&original));
  assert(id<0 && original==NULL);
 } else if (!strcmp(argv[1],"same-handle-new-session")) {
  uint64_t epoch=sf_epoch;assert(sf_destroy_session((XrSession)2)==XR_SUCCESS);session_dead=0;
  XrEventDataBuffer ev={XR_TYPE_EVENT_DATA_BUFFER};assert(sf_poll((XrInstance)1,&ev)==XR_SUCCESS);sample();
  assert(sf_epoch>epoch && count("\"tracked\":true")==5);
 } else if (!strcmp(argv[1],"process-exit-no-lock-or-runtime-call")) {
  sf_dll_shutdown=terminating;
  AcquireSRWLockExclusive(&sf_runtime_lock);
  assert(sf_destroy_session((XrSession)2)==XR_SUCCESS);
  assert(sf_destroy_instance((XrInstance)1)==XR_SUCCESS);
  ReleaseSRWLockExclusive(&sf_runtime_lock);
  assert(!destroy_session_calls && !destroy_instance_calls);
 }
#endif
 else return fail("unknown test");
 printf("PASS: %s\n",argv[1]);return 0;
}
