/* Same real observer, local fake runtime; no headset or game calls. */
#define SIFU_LIFECYCLE_MAIN inherited_lifecycle_main
#include "test_lifecycle.c"
static int sync_calls;
static XrResult sync_result;
static const XrActionsSyncInfo* expected_info;
static HANDLE sync_entered,sync_release;
static XrResult XRAPI_PTR counted_sync(XrSession session,const XrActionsSyncInfo* info) {
    (void)session;assert(info==expected_info);++sync_calls;
    if(sync_entered){SetEvent(sync_entered);assert(WaitForSingleObject(sync_release,3000)==WAIT_OBJECT_0);}
    return sync_result;
}
static DWORD WINAPI sync_worker(void* unused) {
    (void)unused;assert(sf_sync((XrSession)2,expected_info)==sync_result);return 0;
}
static XrResult XRAPI_PTR visible_poll(XrInstance instance,XrEventDataBuffer* buffer) {
    XrResult result=fake_poll(instance,buffer);
    ((XrEventDataSessionStateChanged*)buffer)->state=XR_SESSION_STATE_VISIBLE;return result;
}
int main(void) {
    setup();sf_sync_original=counted_sync;
    XrActiveActionSet active={(XrActionSet)77,9};
    XrActionsSyncInfo info={XR_TYPE_ACTIONS_SYNC_INFO,NULL,1,&active};expected_info=&info;
    sf_frame.focus=XR_SESSION_STATE_UNKNOWN;sf_frame.focus_session=XR_NULL_HANDLE;
    sync_result=XR_SUCCESS;assert(sf_sync((XrSession)2,&info)==XR_SUCCESS);
    assert(sync_calls==1 && sf_frame.focus==XR_SESSION_STATE_FOCUSED && sf_frame.focus_session==(XrSession)2);
    assert(info.activeActionSets==&active && active.subactionPath==9);sample();assert(count("\"tracked\":true")==5);
    sync_result=XR_SESSION_NOT_FOCUSED;assert(sf_sync((XrSession)2,&info)==XR_SESSION_NOT_FOCUSED);sample();assert(count("\"tracked\":true")==0);
    sync_result=XR_SUCCESS;assert(sf_sync((XrSession)2,&info)==XR_SUCCESS);sample();assert(count("\"tracked\":true")==5);
    sync_result=XR_ERROR_RUNTIME_FAILURE;assert(sf_sync((XrSession)2,&info)==XR_ERROR_RUNTIME_FAILURE);sample();assert(count("\"tracked\":true")==0);
    sync_result=XR_SESSION_LOSS_PENDING;assert(sf_sync((XrSession)2,&info)==XR_SESSION_LOSS_PENDING);sample();assert(count("\"tracked\":true")==0);
    sync_result=XR_SUCCESS;assert(sf_sync((XrSession)3,&info)==XR_SUCCESS);assert(sf_frame.focus!=XR_SESSION_STATE_FOCUSED);
    sf_frame.focus=XR_SESSION_STATE_STOPPING;assert(sf_sync((XrSession)2,&info)==XR_SUCCESS);assert(sf_frame.focus==XR_SESSION_STATE_STOPPING);
    sf_frame.focus=XR_SESSION_STATE_UNKNOWN;
    sync_entered=CreateEventW(NULL,TRUE,FALSE,NULL);sync_release=CreateEventW(NULL,TRUE,FALSE,NULL);
    HANDLE thread=CreateThread(NULL,0,sync_worker,NULL,0,NULL);assert(thread);
    assert(WaitForSingleObject(sync_entered,3000)==WAIT_OBJECT_0);
    sf_poll_original=visible_poll;XrEventDataBuffer ev={XR_TYPE_EVENT_DATA_BUFFER};assert(sf_poll((XrInstance)1,&ev)==XR_SUCCESS);
    SetEvent(sync_release);assert(WaitForSingleObject(thread,3000)==WAIT_OBJECT_0);assert(sf_frame.focus==XR_SESSION_STATE_VISIBLE);
    CloseHandle(thread);ResetEvent(sync_entered);ResetEvent(sync_release);
    thread=CreateThread(NULL,0,sync_worker,NULL,0,NULL);assert(thread);
    assert(WaitForSingleObject(sync_entered,3000)==WAIT_OBJECT_0);assert(sf_destroy_session((XrSession)2)==XR_SUCCESS);
    SetEvent(sync_release);assert(WaitForSingleObject(thread,3000)==WAIT_OBJECT_0);
    assert(!sf_frame.session && sf_frame.focus!=XR_SESSION_STATE_FOCUSED && sync_calls==9);
    CloseHandle(thread);CloseHandle(sync_entered);CloseHandle(sync_release);
    assert(sf_hooks_ready());sf_sync_hook=-1;assert(!sf_hooks_ready());sf_sync_hook=5;sf_sync_original=NULL;assert(!sf_hooks_ready());
    puts("PASS: initial focus from original sync, exact forwarding, inactive/error/loss gates, stale/stopped session, newer focus loss and destruction beat late sync, hook readiness");
    return 0;
}
