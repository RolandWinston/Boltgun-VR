#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <assert.h>
#include <stdio.h>
#include <uevr/API.h>
static int registrations;
static bool callback(UEVR_Engine_TickCb cb) {assert(cb);++registrations;return true;}
static int hook(void* target,void* destination,void** original) {(void)target;(void)destination;(void)original;assert(0);return -1;}
static void dispatch(const char* name,const char* data) {(void)name;(void)data;assert(0);}
static void log_message(const char* format,...) {(void)format;}
int main(void) {
 HMODULE module=LoadLibraryW(L"sifuvr_tracking.dll");assert(module);
 typedef bool (*Init)(const UEVR_PluginInitializeParam*);
 Init initialize=(Init)GetProcAddress(module,"uevr_plugin_initialize");assert(initialize);
 UEVR_SDKCallbacks callbacks={0};callbacks.on_pre_engine_tick=callback;
 UEVR_SDKData sdk={0};sdk.callbacks=&callbacks;
 UEVR_PluginFunctions functions={0};functions.register_inline_hook=hook;functions.dispatch_lua_event=dispatch;
 functions.log_info=log_message;functions.log_warn=log_message;
 UEVR_VRData vr={0};UEVR_OpenXRData xr={0};UEVR_PluginInitializeParam api={0};
 api.functions=&functions;api.sdk=&sdk;api.vr=&vr;api.openxr=&xr;
 assert(initialize(&api) && registrations==1);assert(FreeLibrary(module));
 HMODULE retained=GetModuleHandleW(L"sifuvr_tracking.dll");assert(retained==module);
 assert(!initialize(&api) && registrations==1);
 puts("PASS: real built DLL remains mapped after FreeLibrary; repeated initialize rejected; no runtime loaded or hook installed");
 return 0;
}
