#define SIFU_LIFECYCLE_MAIN inherited_lifecycle_main
#include "test_lifecycle.c"
int main(void) {
 setup();
 assert(sf_spaces[0]==(XrSpace)11 && sf_spaces[1]==(XrSpace)12 && sf_spaces[2]==(XrSpace)13 && sf_spaces[3]==(XrSpace)14);
 assert(strstr(captured,"\"aims\":") && strstr(captured,"0.258819") && strstr(captured,"0.9659258"));
 assert(strstr(captured,"\"observer_revision\":2") && sf_process_nonce[0] && strstr(captured,sf_process_nonce));
 char nonce[96];strcpy(nonce,sf_process_nonce);
 hand_flags[3]=3;sample();assert(count("\"tracked\":true")==4);hand_flags[3]=15;
 hand_flags[4]=0;sample();assert(count("\"tracked\":true")==4);hand_flags[4]=15;
 sample();assert(count("\"tracked\":true")==5 && !strcmp(nonce,sf_process_nonce));
 for(int failure=2;failure<=4;++failure){
  sf_drop_spaces();creates=destroys=0;fail_create=failure;
  assert(!sf_bind());assert(destroys==failure-1);
  for(int i=0;i<4;++i)assert(!sf_spaces[i]);
 }
 creates=0;fail_create=0;assert(sf_bind());assert(creates==4);
 assert(sf_destroy_session((XrSession)2)==XR_SUCCESS);
 for(int i=0;i<4;++i)assert(!sf_spaces[i]);
 puts("PASS: simultaneous grip/aim spaces, measured orientation distinction, independent aim flags, process identity, partial allocation cleanup, session cleanup");
 return 0;
}
