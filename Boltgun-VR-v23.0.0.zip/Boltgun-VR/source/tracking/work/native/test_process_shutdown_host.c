#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>
int main(int argc,char** argv) {
 if(argc==3 && !strcmp(argv[1],"--child")) {
  HANDLE map=OpenFileMappingA(FILE_MAP_ALL_ACCESS,FALSE,argv[2]);assert(map);
  volatile LONG* shared=(volatile LONG*)MapViewOfFile(map,FILE_MAP_ALL_ACCESS,0,0,0);assert(shared);
  HMODULE dll=LoadLibraryW(L"test_process_shutdown.dll");assert(dll);
  typedef int (*Prepare)(volatile LONG*);Prepare prepare=(Prepare)GetProcAddress(dll,"supervisor_prepare_shutdown");
  assert(prepare && prepare(shared));
  /* Normal CRT exit invokes the test DLL during genuine process teardown. */
  return 0;
 }
 assert(argc==1);
 char name[100];snprintf(name,sizeof(name),"Local\\SifuSupervisorShutdown_%lu",(unsigned long)GetCurrentProcessId());
 HANDLE map=CreateFileMappingA(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,4096,name);assert(map);
 volatile LONG* shared=(volatile LONG*)MapViewOfFile(map,FILE_MAP_ALL_ACCESS,0,0,0);assert(shared);
 for(int i=0;i<8;++i)shared[i]=-1;shared[4]=shared[5]=shared[7]=0;
 char exe[MAX_PATH];assert(GetModuleFileNameA(NULL,exe,MAX_PATH)>0);
 char command[2*MAX_PATH];snprintf(command,sizeof(command),"\"%s\" --child %s",exe,name);
 STARTUPINFOA si={sizeof(si)};PROCESS_INFORMATION pi={0};
 assert(CreateProcessA(NULL,command,NULL,NULL,FALSE,CREATE_NO_WINDOW,NULL,NULL,&si,&pi));
 assert(WaitForSingleObject(pi.hProcess,5000)==WAIT_OBJECT_0);
 DWORD code=99;assert(GetExitCodeProcess(pi.hProcess,&code) && code==0);
 assert(shared[0]==12345 && shared[1]==1 && shared[2]==0 && shared[3]==0 && shared[4]==0 && shared[5]==0 && shared[6]==67890 && shared[7]==0);
 puts("PASS: real Windows process detach observes shutdown=true, avoids held lock, forwards zero XR/backend calls through actual owned hooks, child exits 0");
 CloseHandle(pi.hThread);CloseHandle(pi.hProcess);UnmapViewOfFile((void*)shared);CloseHandle(map);return 0;
}
