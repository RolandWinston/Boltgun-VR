#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <assert.h>
#include <string.h>
#include <stdio.h>
static LONGLONG test_ticks=10000;
static BOOL test_qpc(LARGE_INTEGER* q) {q->QuadPart=test_ticks;return TRUE;}
static BOOL test_frequency(LARGE_INTEGER* q) {q->QuadPart=1000000;return TRUE;}
static HWND test_foreground(void) {return (HWND)1;}
static int test_foreground_enabled=1;
static DWORD test_window_pid(HWND w,DWORD* pid) {(void)w;*pid=test_foreground_enabled?GetCurrentProcessId():0;return 0;}
#define QueryPerformanceCounter test_qpc
#define QueryPerformanceFrequency test_frequency
#define GetForegroundWindow test_foreground
#define GetWindowThreadProcessId test_window_pid
#include "tracking_bridge.c"
static char captured[4096];static int dispatches=0,wait_calls=0,poll_calls=0,overlay=0,destroys=0,creates=0;
static uint64_t hand_flags[5]={15,15,15,15,15};static int active_hands[2]={1,1};static int fail_create=0;
static XrResult XRAPI_PTR fake_sync(XrSession s,const XrActionsSyncInfo* i) {(void)s;(void)i;return XR_SUCCESS;}
static XrResult XRAPI_PTR fake_wait(XrSession s,const XrFrameWaitInfo* wi,XrFrameState* fs) {(void)s;(void)wi;++wait_calls;fs->predictedDisplayTime=test_ticks*1000;fs->shouldRender=1;return XR_SUCCESS;}
static XrResult XRAPI_PTR fake_poll(XrInstance i,XrEventDataBuffer* b) {(void)i;++poll_calls;XrEventDataSessionStateChanged* e=(void*)b;e->type=XR_TYPE_EVENT_DATA_SESSION_STATE_CHANGED;e->session=(XrSession)2;e->state=XR_SESSION_STATE_FOCUSED;return XR_SUCCESS;}
static XrResult XRAPI_PTR fake_locate(XrSpace s,XrSpace base,XrTime t,XrSpaceLocation* l) {(void)base;(void)t;int n=(int)(uintptr_t)s-10;assert(n>=0 && n<5);l->locationFlags=hand_flags[n];l->pose.position.y=1.5f;l->pose.orientation.w=n>=3?.965925826f:1.f;l->pose.orientation.x=n>=3?.258819045f:0.f;return XR_SUCCESS;}
static XrResult XRAPI_PTR fake_state(XrSession s,const XrActionStateGetInfo* gi,XrActionStatePose* ps) {(void)s;ps->isActive=active_hands[gi->subactionPath-1];return XR_SUCCESS;}
static XrResult XRAPI_PTR fake_create(XrSession s,const XrActionSpaceCreateInfo* ci,XrSpace* space) {(void)s;++creates;if (fail_create && creates==fail_create) return XR_ERROR_RUNTIME_FAILURE;*space=(XrSpace)(uintptr_t)(10+ci->subactionPath+(ci->action==(XrAction)5?2:0));return XR_SUCCESS;}
static XrResult XRAPI_PTR fake_destroy(XrSpace s) {(void)s;++destroys;return XR_SUCCESS;}
static XrResult XRAPI_PTR fake_destroy_session(XrSession s) {(void)s;return XR_SUCCESS;}
static XrResult XRAPI_PTR fake_destroy_instance(XrInstance i) {(void)i;return XR_SUCCESS;}
static XrResult XRAPI_PTR fake_path(XrInstance i,const char* s,XrPath* p) {(void)i;*p=strstr(s,"left")?1:2;return XR_SUCCESS;}
static XrResult XRAPI_PTR fake_getproc(XrInstance i,const char* n,PFN_xrVoidFunction* fn) {(void)i;
 if (!strcmp(n,"xrCreateActionSpace"))*fn=(PFN_xrVoidFunction)fake_create;
 else if (!strcmp(n,"xrDestroySpace"))*fn=(PFN_xrVoidFunction)fake_destroy;
 else if (!strcmp(n,"xrStringToPath"))*fn=(PFN_xrVoidFunction)fake_path;
 else if (!strcmp(n,"xrLocateSpace"))*fn=(PFN_xrVoidFunction)fake_locate;
 else if (!strcmp(n,"xrGetActionStatePose"))*fn=(PFN_xrVoidFunction)fake_state;
 else return XR_ERROR_FUNCTION_UNSUPPORTED;
 return XR_SUCCESS;
}
static void fake_log(const char* format,...) {(void)format;}
static bool yes(void) {return true;}
static bool drawing(void) {return overlay;}
static UEVR_XrInstance instance(void){return (UEVR_XrInstance)1;}
static UEVR_XrSession session(void){return (UEVR_XrSession)2;}
static UEVR_XrSpace stage(void){return (UEVR_XrSpace)3;}
static UEVR_XrSpace view(void){return (UEVR_XrSpace)10;}
static UEVR_ActionHandle action(const char* p){return (UEVR_ActionHandle)(uintptr_t)(!strcmp(p,"/actions/default/in/Pose")?5:4);}
static UEVR_InputSourceHandle left(void){return (UEVR_InputSourceHandle)1;}
static UEVR_InputSourceHandle right(void){return (UEVR_InputSourceHandle)2;}
static bool grip(UEVR_ActionHandle a,UEVR_InputSourceHandle s){(void)a;(void)s;return true;}
static void dispatch(const char* name,const char* json){assert(!strcmp(name,"boltgun_tracking_v1"));strncpy(captured,json,sizeof(captured)-1);++dispatches;}
static void sample(void){XrFrameState state={XR_TYPE_FRAME_STATE};++test_ticks;int before=wait_calls;assert(sf_wait((XrSession)2,NULL,&state)==XR_SUCCESS);assert(wait_calls==before+1);sf_tick(NULL,0);}
static int count(const char* needle){int n=0;const char* s=captured;while ((s=strstr(s,needle))) {++n;s+=strlen(needle);}return n;}
int main(void){
 UEVR_VRData vr={0};vr.is_openxr=yes;vr.is_runtime_ready=yes;vr.get_action_handle=action;vr.get_left_joystick_source=left;vr.get_right_joystick_source=right;vr.is_action_active=grip;
 UEVR_OpenXRData xr={instance,session,stage,view};UEVR_PluginFunctions fn={0};fn.log_info=fake_log;fn.log_warn=fake_log;fn.is_drawing_ui=drawing;fn.dispatch_lua_event=dispatch;
 UEVR_PluginInitializeParam api={0};api.vr=&vr;api.openxr=&xr;api.functions=&fn;sf_api=&api;
 sf_instance=(XrInstance)1;sf_session=(XrSession)2;sf_frame.instance=(XrInstance)1;sf_getproc=fake_getproc;sf_wait_original=fake_wait;sf_poll_original=fake_poll;sf_frequency.QuadPart=1000000;
 sf_wait_hook=1;sf_poll_hook=2;sf_destroy_session_hook=3;sf_destroy_instance_hook=4;sf_sync_hook=5;sf_sync_original=fake_sync;
 sf_destroy_session_original=fake_destroy_session;sf_destroy_instance_original=fake_destroy_instance;
 fail_create=2;assert(!sf_bind());assert(destroys==1 && !sf_spaces[0] && !sf_spaces[1]);
 fail_create=0;creates=0;assert(sf_bind());
 sample();assert(count("\"tracked\":true")==0); /* focus unknown */
 XrEventDataBuffer ev={XR_TYPE_EVENT_DATA_BUFFER};assert(sf_poll((XrInstance)1,&ev)==XR_SUCCESS);assert(poll_calls==1 && ev.type==XR_TYPE_EVENT_DATA_SESSION_STATE_CHANGED);
 sample();assert(count("\"tracked\":true")==5);assert(strstr(captured,"\"combat_enabled\":false"));assert(strstr(captured,"\"bridge\":\"boltgun-tracking-v1\""));assert(strstr(captured,"\"clock_qpc\":0.010002000"));
 int before=dispatches;sf_tick(NULL,0);assert(dispatches==before); /* same XR frame skipped */
 hand_flags[1]=3;sample();assert(count("\"tracked\":true")==4);hand_flags[1]=15;
 active_hands[1]=0;sample();assert(count("\"tracked\":true")==3);active_hands[1]=1;
 overlay=1;sample();assert(count("\"tracked\":true")==0);overlay=0;
 test_foreground_enabled=0;sample();assert(count("\"tracked\":true")==0);test_foreground_enabled=1;
 test_ticks+=76000;sf_tick(NULL,0);assert(count("\"tracked\":true")==0);
 sf_frame.focus=XR_SESSION_STATE_VISIBLE;sample();assert(count("\"tracked\":true")==0);
 sf_frame.focus=XR_SESSION_STATE_FOCUSED;sample();assert(count("\"tracked\":true")==5);
 sf_frame.change_session=(XrSession)2;sf_frame.change_time=(test_ticks+1)*1000;uint64_t old_epoch=sf_epoch;sample();assert(sf_epoch==old_epoch+1);sample();assert(sf_epoch==old_epoch+1);puts("bridge mocks passed: frame/event passthrough, partial bind cleanup, unknown/lost focus, stale/duplicate frames, per-hand flags, inactive action, overlay and foreground");
 return 0;
}
