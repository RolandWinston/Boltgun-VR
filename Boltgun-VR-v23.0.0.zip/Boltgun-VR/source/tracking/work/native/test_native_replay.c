#define SIFU_LIFECYCLE_MAIN inherited_lifecycle_main
#include "test_lifecycle.c"
int main(void) {
    setup();
    for(int i=0;i<55;++i) {
        test_ticks+=10000;
        sf_frame.focus=i>=40 && i<45 ? XR_SESSION_STATE_VISIBLE : XR_SESSION_STATE_FOCUSED;
        sample();puts(captured);
    }
    return 0;
}
