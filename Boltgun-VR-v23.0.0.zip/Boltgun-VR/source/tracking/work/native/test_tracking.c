#include <assert.h>
#include <stdio.h>
#include "tracking_policy.h"
int main(void) {
 float p[3]={0,1.5f,-.2f},q[4]={0,0,0,1};
 assert(sf_pose_valid(0,1,15,p,q));
 for (int bit=0;bit<4;++bit) assert(!sf_pose_valid(0,1,15^(1<<bit),p,q));
 assert(!sf_pose_valid(0,0,15,p,q));assert(!sf_pose_valid(-1,1,15,p,q));
 p[0]=NAN;assert(!sf_pose_valid(0,1,15,p,q));p[0]=0;q[3]=0;assert(!sf_pose_valid(0,1,15,p,q));
 assert(sf_frame_valid(1,10,1000,1,1,1));
 assert(!sf_frame_valid(0,10,1000,1,1,1));assert(!sf_frame_valid(1,76,1000,1,1,1));
 assert(!sf_frame_valid(1,-1,1000,1,1,1));assert(!sf_frame_valid(1,10,0,1,1,1));
 assert(!sf_frame_valid(1,10,1000,0,1,1));assert(!sf_frame_valid(1,10,1000,1,0,1));assert(!sf_frame_valid(1,10,1000,1,1,0));
 puts("tracking policy: 17 assertions passed (no live OpenXR)");return 0;
}
