/* Fixed nightly API.h forward-declares lua_State without its C typedef. */
typedef struct lua_State lua_State;
