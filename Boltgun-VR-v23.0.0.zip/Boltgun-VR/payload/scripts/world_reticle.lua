-- A native depth-tested marker driven by the same rendered gun pose as free aim.
local Geometry=require('world_aim_geometry')
local NativeQuery=require('native_gun_query')
local M={}
local function coordinate(v,upper,lower)
 local ok,n=pcall(function()return v[upper]end)
 if not ok or type(n)~='number'then ok,n=pcall(function()return v[lower]end)end
 if ok and type(n)=='number'and n==n and math.abs(n)<1e12 then return n end
end
function M.new(e)
 local marker=require('lab_visual_component').new(e,'Reticle')
 local api,hook=e.uevr.api,e.uevr.types.UObjectHook
 local query;local pawn,nonce;local allowed=false
 local s={frames=0,hidden=0,stopped=false,source='post-stereo-owned-gun-native-line-trace'}
 local function valid(o)return o and hook.exists(o)end
 local function hide(reason)
  allowed=false;s.hidden=s.hidden+1;s.reason=reason;s.visible=false
  marker:step(pawn,nil,nonce,false,true)
 end
 function s:prepare(owner,token,enabled)
  pawn,nonce=owner,token
  if self.stopped or not enabled then hide('inactive');return end
  marker:step(pawn,nil,nonce,true,true)
  allowed=marker:component()~=nil
  if marker.stopped then self.stopped=true;self.error=marker.last_error end
 end
 function s:capture(sample,component,enabled,index,eye)
  if self.stopped or type(index)~='number'or(index+1)%2~=0 then return end
  local ok,err=pcall(function()
   local hand=sample and sample.hands and sample.hands.right
   if not allowed or not enabled or not sample or not sample.fresh or not sample.focused or not sample.foreground
    or not sample.head or not sample.head.tracked or not hand or not hand.tracked or not hand.active
    or not valid(pawn)or api:get_local_pawn(0)~=pawn or not valid(component)or component:get_outer()~=pawn then hide('tracking-or-owner');return end
   query=query or NativeQuery.new(e.uevr)
   local weapon,owner=query:weapon();if not weapon or owner~=pawn then hide('weapon-changed');return end
   local t=component:K2_GetComponentToWorld();local p,q,z=t.Translation,t.Rotation,t.Scale3D
   local world={position={x=p.X,y=p.Y,z=p.Z},rotation={x=q.X,y=q.Y,z=q.Z,w=q.W},scale={x=z.X,y=z.Y,z=z.Z}}
   local ray=Geometry.ray(world);if not ray then hide('invalid-rendered-pose');return end
   local result=query:cast(ray.origin,ray.finish)
   local view={x=coordinate(eye,"X","x"),y=coordinate(eye,"Y","y"),z=coordinate(eye,"Z","z")};local placement=Geometry.marker(ray,result,view)
   if not placement then hide('invalid-hit');return end
   if not marker:place_world(placement.position,placement.rotation,placement.scale)then hide('marker-unavailable');return end
   self.frames=self.frames+1;self.visible=true;self.reason='placed';self.sequence=sample.sequence;self.epoch=sample.epoch
   self.muzzle=ray.origin;self.direction=ray.direction;self.world=placement;self.mesh_name=component:get_full_name()
  end)
  if not ok then self.stopped=true;self.error=tostring(err);pcall(hide,'api-error');e.uevr.params.functions.log_info('[Boltgun world reticle] stopped: '..self.error)end
 end
 function s:inspect()return{frames=self.frames,visible=self.visible,reason=self.reason,stopped=self.stopped,error=self.error,sequence=self.sequence,
  epoch=self.epoch,muzzle=self.muzzle,direction=self.direction,world=self.world,marker=marker:inspect(),mesh=self.mesh_name,source=self.source}end
 function s:stop()self.stopped=true;marker:stop()end
 return s
end
return M
