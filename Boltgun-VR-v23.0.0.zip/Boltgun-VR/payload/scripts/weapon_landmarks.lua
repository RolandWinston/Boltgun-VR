-- Generated from actual Lab export. Units: UE centimetres. Preserve initial-load require.
return {muzzle={x=49.7999954,y=-0.359999955,z=12.8000021},blade_base={x=10.4399986,y=-1.7999984,z=23.1999969},blade_tip={x=10.4399986,y=-1.79998875,z=73.5999985},blade_radius=8.8}
