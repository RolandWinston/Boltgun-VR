-- Velocity-only 50ms history and 0.8m/s / 200deg/s thresholds from GTFO VR (MIT).
-- Physical tracking-space hand coordinates exclude stick locomotion. Visual poses stay direct.
local B=require('blade_sweep');local M={}
function M.new()
 local s={id=0,active=false,armed=false,speed=0,angular=0};local previous,history,quiet=nil,{},0
 function s:reset()previous=nil;history={};quiet=0;self.active=false;self.armed=false;self.speed=0;self.angular=0 end
 function s:step(p,dt,valid)
  if not valid or not B.valid(p)or type(dt)~='number'or dt~=dt or dt<=0 or dt>.1 then self:reset();return 'invalid' end
  if not previous then previous=p;return 'priming' end
  local distance=B.length(B.sub(p.position,previous.position));local angle=B.angle(p.rotation,previous.rotation);previous=p
  if distance>.5 or distance/dt>15 or angle>100 then self:reset();return 'discontinuity' end
  history[#history+1]={dt=dt,v=distance/dt,w=angle/dt};local span=0;for _,h in ipairs(history)do span=span+h.dt end
  while span>.05 and #history>1 do span=span-history[1].dt;table.remove(history,1)end
  local v,w=0,0;for _,h in ipairs(history)do v=v+h.v;w=w+h.w end;self.speed=v/#history;self.angular=w/#history
  local moving=self.speed>.8 or self.angular>200
  if moving then
   quiet=0
   if self.armed then self.armed=false;self.active=true;self.id=self.id+1;return 'begin',self.id end
   return self.active and 'active'or 'unarmed',self.id
  end
  quiet=quiet+dt
  -- A full velocity-history window below threshold re-arms. Prevents jitter duplicate attacks.
  if quiet>=.05 then local was=self.active;self.active=false;self.armed=true;return was and 'end'or 'ready',self.id end
  return self.active and 'active'or 'settling',self.id
 end
 return s
end
return M
