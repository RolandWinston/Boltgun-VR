-- GPL-3.0-or-later. Geometry-derived near-eye protection; never moves the mesh.
-- Bounds are UE centimetres from the pinned BGCHAIN1 payload. See bounds.json.
local Grip=require('grip_anchor')
local M={}
local bounds={
 LeftArm={{-22,-8.5,-8.5},{13.938,8.5,9.112}},
 RightArm={{-22,-8.5,-8.501},{13.938,8.5,9.112}},
 Bolter={{6.199998856,-7.360000134,-5.999998569},{49.199996948,6.639999866,24.080003738}},
 Chainsword={{-0.200004429,-7.399999142,-9.399998665},{19.588560104,3.800004005,74.799995422}},
}
bounds.Shotgun={{6.5,-5.924999713897705,-6.0},{49.724998474121094,5.324999809265137,22.0}}
bounds.Plasmagun={{6.5,-6.360000133514404,-6.0},{49.724998474121094,5.639999866485596,22.600000381469727}}
bounds.HeavyBolter={{6.5,-8.859999656677246,-9.0},{49.724998474121094,8.899999618530273,26.0}}
bounds.Meltagun={{6.5,-12.199999809265137,-6.0},{49.724998474121094,6.139999866485596,22.0}}
bounds.VolkiteCaliver={{6.5,-5.924999713897705,-6.0},{49.724998474121094,5.324999809265137,22.0}}
bounds.VengeanceLauncher={{6.5,-7.800000190734863,-6.0},{49.724998474121094,6.140000343322754,22.0}}
bounds.Gravgun={{6.5,-7.860000133514404,-6.0},{49.0,7.139999866485596,22.0}}
bounds.MultiMelta={{6.5,-12.199999809265137,-6.0},{49.64999771118164,9.800000190734863,22.0}}
bounds.MissileLauncher={{3.499999523162842,-10.600000381469727,-6.0},{49.0,7.639999866485596,22.0}}
local function finite(v)return type(v)=='number'and v==v and math.abs(v)<1e8 end
local function quat(q)
 if type(q)~='table'then return nil end
 for _,k in ipairs({'x','y','z','w'})do if not finite(q[k])then return nil end end
 local n=math.sqrt(q.x*q.x+q.y*q.y+q.z*q.z+q.w*q.w)
 if math.abs(n-1)>.01 then return nil end
 return{x=q.x/n,y=q.y/n,z=q.z/n,w=q.w/n}
end
local function mul(a,b)return{x=a.w*b.x+a.x*b.w+a.y*b.z-a.z*b.y,y=a.w*b.y-a.x*b.z+a.y*b.w+a.z*b.x,z=a.w*b.z+a.x*b.y-a.y*b.x+a.z*b.w,w=a.w*b.w-a.x*b.x-a.y*b.y-a.z*b.z}end
local function position(p)
 return type(p)=='table'and finite(p.x)and finite(p.y)and finite(p.z)
end
local function distance(id,head,pose,q)
 if not position(head)or not position(pose)then return nil end
 local v={x=head.x-pose.x,y=head.y-pose.y,z=head.z-pose.z,w=0}
 local p=mul(mul({x=-q.x,y=-q.y,z=-q.z,w=q.w},v),q)
 -- XR metres -> UE cm, with the actual native26 grip anchor convention.
 local a=Grip.anchor(id);local c={-p.z*100+a.x,p.x*100+a.y,p.y*100+a.z};local b=bounds[id];local d=0
 for i=1,3 do local gap=math.max(b[1][i]-c[i],0,c[i]-b[2][i]);d=d+gap*gap end
 return math.sqrt(d)
end
function M.new()
 local s={states={},source='tracked-head-to-owned-mesh-bounds',hide_cm=12,restore_cm=18}
 function s:allow(id,sample)
  assert(bounds[id],'Unknown owned mesh')
  local old=self.states[id];local head=sample and sample.head;local side=(id=='LeftArm'or id=='Chainsword')and'left'or'right'
  local g=sample and sample.hands and sample.hands[side];local a=sample and sample.aims and sample.aims[side]
  local q
  q=g and quat(g.rotation)
  if q then q=mul(q,{x=-math.sqrt(.5),y=0,z=0,w=math.sqrt(.5)})end
  local valid=sample and sample.fresh and head and head.active and head.tracked and g and g.active and g.tracked and a and a.active and a.tracked and q
  local d=valid and distance(id,head.position,g.position,q)
  local da=valid and distance(id,head.position,a.position,q)
  if d and da then d=math.min(d,da)else d=nil end
  local previous=sample and old and old.process_nonce==sample.process_nonce and old.epoch==sample.epoch and old.blocked
  local blocked=not d or d<(previous and self.restore_cm or self.hide_cm)
  self.states[id]={blocked=blocked==true,distance_cm=d,reason=not d and'invalid-head-or-hand'or blocked and'near-eye-volume'or'clear',process_nonce=sample and sample.process_nonce,epoch=sample and sample.epoch,sequence=sample and sample.sequence}
  return not blocked
 end
 function s:inspect()return{source=self.source,hide_cm=self.hide_cm,restore_cm=self.restore_cm,models=self.states}end
 return s
end
return M
