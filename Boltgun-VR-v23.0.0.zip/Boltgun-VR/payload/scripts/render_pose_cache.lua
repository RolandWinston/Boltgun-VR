-- Read the owned mesh after UEVR's first-eye attachment update. Never apply damage here.
local M={}
local function clone(v)
 if type(v)~='table'then return v end
 local t={};for k,x in pairs(v)do t[k]=clone(x)end;return t
end
local function finite(n)return type(n)=='number'and n==n and math.abs(n)<1e12 end
function M.new(e)
 local item;local s={captured=0,rejected=0,stopped=false,phase='post-stereo-first-eye'}
 local function clear(reason)item=nil;s.rejected=s.rejected+1;s.rejection=reason end
 local function usable(sample,component,enabled)
  local h=sample and sample.hands and sample.hands.left
  return enabled and component and sample and sample.fresh and sample.focused and sample.foreground
   and h and h.active and h.tracked and finite(sample.sequence)and finite(sample.clock_qpc)
   and sample.process_nonce~=nil and sample.epoch~=nil
 end
 function s:capture(sample,component,enabled,now,view_index)
  if self.stopped then return end
  -- Matches fixed UEVR UObjectHook first-eye branch. Boltgun observations use views 1/2.
  if type(view_index)~='number'or(view_index+1)%2~=0 then return end
  if not usable(sample,component,enabled)or not finite(now)then clear('capture-inactive');return end
  local ok,err=pcall(function()
   assert(e.uevr.types.UObjectHook.exists(component),'Owned component expired')
   local t=component:K2_GetComponentToWorld();local p,q=t.Translation,t.Rotation
   local world={position={x=p.X,y=p.Y,z=p.Z},rotation={x=q.X,y=q.Y,z=q.Z,w=q.W}}
   for _,v in pairs(world.position)do assert(finite(v),'Nonfinite translation')end
   for _,v in pairs(world.rotation)do assert(finite(v),'Nonfinite rotation')end
   local r=world.rotation;local norm=r.x*r.x+r.y*r.y+r.z*r.z+r.w*r.w
   assert(math.abs(norm-1)<.01,'Nonunit component quaternion')
   item={sample=clone(sample),component=component,address=component:get_address(),at=now,world=world}
   self.captured=self.captured+1;self.last_sequence=sample.sequence;self.last_world=clone(world)
  end)
  if not ok then self.stopped=true;self.error=tostring(err);clear('capture-error')end
 end
 function s:take(sample,component,enabled,now)
  if self.stopped or not usable(sample,component,enabled)or not finite(now)then clear('consume-inactive');return nil end
  if not item then return nil end
  if component~=item.component or component:get_address()~=item.address then clear('component-changed');return nil end
  if sample.process_nonce~=item.sample.process_nonce or sample.epoch~=item.sample.epoch then clear('tracking-origin-changed');return nil end
  if now<item.at or now-item.at>.075 or sample.sequence<item.sample.sequence then clear('stale-render-pose');return nil end
  -- Immutable copies prevent later source or consumer mutation changing the next read.
  return clone(item.sample),clone(item.world)
 end
 function s:stop()self.stopped=true;item=nil end
 function s:inspect()return {phase=self.phase,captured=self.captured,rejected=self.rejected,rejection=self.rejection,stopped=self.stopped,error=self.error,last_sequence=self.last_sequence,last_world=self.last_world}end
 return s
end
return M
