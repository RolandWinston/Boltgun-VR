-- Controller actions are the only input source. Engine operations run on engine tick.
local Policy=require('controller_policy');local Ray=require('menu_ray');local M={}
function M.start(e,menu)
 local api,vr,hook,cb=e.uevr.api,e.uevr.params.vr,e.uevr.types.UObjectHook,e.uevr.sdk.callbacks
 local fn=e.uevr.params.functions;local policy=Policy.new();local bindings=require('controller_bindings').new(e);local comfort=require('controller_comfort').new(e);local modal=require('controller_modal').new(e);local interaction=require('controller_interaction').new(e);local reload_until=0;local latest,turn,click,at,previous_tick=nil,0,false,-1,nil
 local status={version='controller-campaign-01',inputs=0,cycles=0,grenades=0,reloads=0,stopped=false}
 local gs,last_weapon,next_reload
 local original_aim=vr.is_aim_allowed();local applied_aim
 local function restore_aim()if applied_aim~=nil and vr.is_aim_allowed()==applied_aim then vr.set_aim_allowed(original_aim)end end
 local function valid(o)return o and hook.exists(o)end
 local function prop(o,k)if valid(o)and o:get_class():find_property(k)then return o:get_property(k)end end
 local function guard(now)
  local state=menu.inspect();local t=state.tracking
  if status.stopped or menu.stopped then return false,'stopped' end
  if not menu.clock_verified then return false,'clock' end
  if not t then return false,'no-tracking' end
  if not t.good then return false,'tracking-flags' end
  if now<t.at or now-t.at>.075 then return false,'tracking-age' end
  if not vr.is_runtime_ready()then return false,'runtime' end
  if fn.is_drawing_ui()then return false,'overlay' end
  return true,'valid'
 end
 local function brief_frame_gap(now,reason)
  if reason~='tracking-age'and reason~='engine-snapshot'then return false end
  local t=menu.inspect().tracking
  return latest and latest.menu==false and latest.bindings_ready==true and t and t.good==true
   and now>=t.at and now-t.at<=.25 and now>=latest.at and now-latest.at<=.25
   and vr.is_runtime_ready()and not fn.is_drawing_ui()
 end
 local audit={};status.input_audit=audit;local last_signature
 cb.on_xinput_get_state(function(retval,user,packet)
  if user~=vr.get_lowest_xinput_index()or not packet or not packet.Gamepad then return end
  if tonumber(tostring(retval))~=0 then return end
  local g=packet.Gamepad;local now=os.clock();local good,reason=guard(now);if good and(not latest or not latest.bindings_ready or now<latest.at or now-latest.at>.075)then good=false;reason='engine-snapshot' end
  local transient=not good and brief_frame_gap(now,reason)==true;if transient then status.transient_blocks=(status.transient_blocks or 0)+1 end
  local sig=tostring(g.wButtons)..':'..tostring(g.bRightTrigger)..':'..tostring(g.sThumbLY)..':'..tostring(g.sThumbRX)..':'..reason..':'..tostring(policy.armed)
  if sig~=last_signature then last_signature=sig;local t=menu.inspect().tracking;local v=t and t.sample or {};audit[#audit+1]={at=now,reason=reason,transient=transient,armed=policy.armed,buttons=g.wButtons,rt=g.bRightTrigger,ly=g.sThumbLY,rx=g.sThumbRX,age=t and now-t.at,engine_age=latest and now-latest.at,fresh=v.fresh,focused=v.focused,foreground=v.foreground,epoch=v.epoch};if #audit>64 then table.remove(audit,1)end end
  local out=policy:step{valid=good==true,transient=transient,menu=latest and latest.menu,native_confirm=latest and latest.native_confirm,buttons=g.wButtons,lt=g.bLeftTrigger,rt=g.bRightTrigger,lx=g.sThumbLX/32767,ly=g.sThumbLY/32767,rx=g.sThumbRX/32767,ry=g.sThumbRY/32767}
  if good and latest and not latest.menu and now<reload_until then out.buttons=out.buttons+0x10 end
  g.wButtons=out.buttons;g.bLeftTrigger=out.lt;g.bRightTrigger=out.rt
  g.sThumbLX=math.floor(out.lx*32767);g.sThumbLY=math.floor(out.ly*32767);g.sThumbRX=0;g.sThumbRY=0
  turn,click,at=out.turn,out.click,now
  status.inputs=status.inputs+1;if out.cycle then status.cycles=status.cycles+1 end;if out.grenade then status.grenades=status.grenades+1 end
  status.last_output={buttons=out.buttons,lt=out.lt,rt=out.rt,turn=out.turn,click=out.click}
 end)
 cb.on_pre_engine_tick(function()
  if status.stopped then return end
  local ok,why=pcall(function()
   local now=os.clock();interaction:step(now);status.interaction=interaction:inspect();comfort:step(now);status.comfort=comfort:inspect();bindings:step(now);status.bindings=bindings:inspect();local dt=previous_tick and now-previous_tick or 0;previous_tick=now
   local state=menu.inspect();local pc=api:get_player_controller(0);local pawn=api:get_local_pawn(0)
   if not gs then gs=assert(api:find_uobject('Class /Script/Engine.GameplayStatics')):get_class_default_object()end
   local paused=valid(pc)and gs:IsGamePaused(pc)==true
   local health=prop(pawn,'CurrentHealth');local dead=type(health)=='number'and health<=0
   local modal_active=modal:step(now);local native_confirm=state.context and state.context.mode=='loading'
   local is_menu=not state.context or state.context.mode~='gameplay' or state.context.loading_confirm or paused or dead or modal_active;status.modal=modal:inspect();status.dead=dead
   latest={at=now,menu=is_menu,native_confirm=native_confirm,bindings_ready=(is_menu and not native_confirm)or bindings.ready==true};status.menu=is_menu;status.paused=paused
   applied_aim=not is_menu;vr.set_aim_allowed(applied_aim);status.native_aim_allowed=vr.is_aim_allowed()
   local good=guard(now)and valid(pc)
   if valid(pc)and pc:get_class():find_property('bShowMouseCursor')then pc.bShowMouseCursor=is_menu end
   if good and not is_menu and now>=at and now-at<=.075 and dt>0 and dt<=.1 and turn~=0 then
    local scale=prop(pc,'InputYawScale');assert(type(scale)=='number' and math.abs(scale)>0.0001,'InputYawScale unavailable');pc:AddYawInput(turn*210*dt/scale);status.turn_rate=turn*210
   else status.turn_rate=0 end
   local sample=state.tracking and state.tracking.sample
   local point
   if good and is_menu then
    local panel=Ray.panel(vr);point=panel and Ray.intersect(sample.aims.right,panel);status.panel=panel
    
   end
   if point and now>=at and now-at<=.075 then
    fn.dispatch_custom_event('boltgun.controller.pointer.v1',string.format('%.8f|%.8f|%d',point.x,point.y,click and 1 or 0))
   else fn.dispatch_custom_event('boltgun.controller.pointer.v1','off')end
   status.pointer=point
   -- Empty magazine emits the native Reload action; ammo stays engine-owned.
   local weapon=prop(prop(pawn,'WeaponHandlerComponent'),'EquippedWeapon')
   if weapon~=last_weapon then last_weapon=weapon;next_reload=0 end
   if good and not is_menu and valid(weapon)and now>=(next_reload or 0)then
    local c=weapon:get_class()
    if c:find_function('GetMagazineAmmo')and c:find_function('GetAmmoRemainingInPool')then
     local ammo,pool=weapon:GetMagazineAmmo(),weapon:GetAmmoRemainingInPool();status.ammo=ammo;status.pool=pool
     if ammo==0 and pool>0 then
      reload_until=now+.1;status.reloads=status.reloads+1;status.reload_method='native-reload-action';next_reload=now+1
     end
    end
   end
  end)
  if not ok then pcall(restore_aim);status.stopped=true;status.error=tostring(why);policy:reset();pcall(fn.dispatch_custom_event,'boltgun.controller.pointer.v1','off')end
 end)
 cb.on_script_reset(function()pcall(function()interaction:restore()end);pcall(function()bindings:restore()end);pcall(function()comfort:restore()end);restore_aim();status.stopped=true;policy:reset();pcall(fn.dispatch_custom_event,'boltgun.controller.pointer.v1','off')end)
 function status:inspect()local out={};for k,v in pairs(self)do if type(v)~='function'then out[k]=v end end;return out end
 return status
end
return M
