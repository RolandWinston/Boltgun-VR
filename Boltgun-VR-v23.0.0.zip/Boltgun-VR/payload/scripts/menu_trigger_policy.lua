-- Local menu-only input policy. No engine calls. All physical gameplay bindings remain untouched.
local M={}
local A=4096
local function has(v,b)return math.floor(v/b)%2==1 end
function M.new()return {armed=false,previous_menu=false,drain=false,output_down=false,elapsed=0}end
function M.step(s,c,rt,buttons)
 local output={rt=rt,buttons=buttons,accepted=false}
 -- Foreign XInput sources never consume or change the selected source's state.
 if not c.right_source then return output end
 if not c.ready or c.focused~=true or c.overlay or c.stale then
  s.armed=false;s.output_down=false;s.elapsed=0
  -- An owned menu pull must drain even while the scene snapshot is unavailable.
  -- Otherwise held Confirm can become Fire during loading or focus loss.
  if s.previous_menu or s.drain then output.rt=0;s.drain=rt>32 end
  s.previous_menu=false;return output
 end
 local menu=c.frontend==true
 if menu~=s.previous_menu then s.armed=false;s.output_down=false;s.elapsed=0;if s.previous_menu then s.drain=rt>32 end end
 s.previous_menu=menu
 if not menu then
  if s.drain then output.rt=0;if rt<=32 then s.drain=false end end
  return output
 end
 -- Consume RT while the confirmed frontend owns it. Preserve every existing button.
 output.rt=0
 if rt<=32 then s.armed=true;s.output_down=false;s.elapsed=0;s.drain=false;return output end
 if rt>=166 and c.raw_trigger and s.armed then
  s.armed=false;s.output_down=true;s.elapsed=0;output.accepted=true
 end
 if s.output_down then
  s.elapsed=s.elapsed+math.max(0,math.min(c.dt or 0,.1))
  if s.elapsed<=.12 and not has(buttons,A) then output.buttons=buttons+A end
  if s.elapsed>.12 then s.output_down=false end
 end
 return output
end
function M.frontend(controller,pawn)
 return pawn==nil and type(controller)=='string' and
  controller:match('^BGPlayerController /Game/Maps/3DFrontend/MainMenu_InteriorScene%.MainMenu_InteriorScene%.PersistentLevel%.BGPlayerController_%d+$')~=nil
end
-- Exact loading widget observed in the current game, not all viewport widgets.
function M.loading(pawn,loaded,widget)
 return loaded==false and type(pawn)=='string' and
  pawn:match('^BP_PlayerCharacter_Sternguard_C /Game/Maps/[^ ]+%.PersistentLevel%.BP_PlayerCharacter_Sternguard_C_%d+$')~=nil and
  type(widget)=='string' and widget:match('^W_UI_20_Level_Loading_C /Engine/Transient%.GameEngine_%d+%.BP_GameInstance_C_%d+%.W_UI_20_Level_Loading_C_%d+$')~=nil
end
return M
