-- Only visible top-level native menu widgets switch input to the ray.
local M={}
function M.new(e)
 local api,hook=e.uevr.api,e.uevr.types.UObjectHook;local state={active=false,errors=0};local next_check=0;local cls
 function state:step(now)
  if self.stopped or now<next_check then return self.active end;next_check=now+.3
  local ok,result=pcall(function()
   if not cls then cls=assert(api:find_uobject('Class /Script/UMG.UserWidget'))end
   for _,o in ipairs(cls:get_objects_matching(false)or{})do
    if hook.exists(o)then
     local n=o:get_full_name()
     if(n:match('^W_UI_%d+_')or n:match('^W_UI_Pop_Up'))and not n:find('Default__',1,true)then
      local sampled,visible=pcall(function()return o:IsInViewport()and o:IsVisible()end)
      if sampled and visible then return n end
      if not sampled then self.unavailable_widgets=(self.unavailable_widgets or 0)+1 end
     end
    end
   end
   return false
  end)
  if ok then self.active=result~=false;self.widget=result or nil;self.confirm=type(result)=='string'and result:match('^W_UI_17_Level_Complete_C ')~=nil
  else self.confirm=false;self.errors=self.errors+1;self.error=tostring(result);self.active=true;if self.errors>=3 then self.stopped=true end end
  return self.active
 end
 function state:inspect()return{active=self.active,confirm=self.confirm,widget=self.widget,errors=self.errors,error=self.error,stopped=self.stopped}end
 return state
end
return M
