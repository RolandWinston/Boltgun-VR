-- Uses UE SphereTraceSingle with ActorsToIgnore; UEVR's fixed build cannot marshal HitResult arrays.
local M={}
function M.new(uevr)
 local api=uevr.api;local hook=uevr.types.UObjectHook
 local vd=api:find_uobject('ScriptStruct /Script/CoreUObject.Vector'):as_struct()
 local gs=api:find_uobject('Class /Script/Engine.GameplayStatics'):get_class_default_object()
 local fn=assert(gs:get_class():find_function('BreakHitResult'))
 local system=api:find_uobject('Class /Script/Engine.KismetSystemLibrary'):get_class_default_object()
 local trace=assert(system:get_class():find_function('SphereTraceSingle'))
 local trace_names={};local field=trace:get_child_properties()
 while field do local n=field:get_fname():to_string();local p=trace:find_property(n)
  if p and p:is_param()and not p:is_return_param()then trace_names[#trace_names+1]=n end;field=field:get_next()end
 local enemyClass=api:find_uobject('Class /Script/Boltgun.BGNonPlayableCharacterBase')
 local names={};local f=fn:get_child_properties()
 while f do local k=f:get_fname():to_string();local p=fn:find_property(k)
  if p and p:is_param()and not p:is_return_param()then assert(k=='Hit'or p:is_out_param());names[#names+1]=k end;f=f:get_next()end
 local function vec(p)local v=StructObject.new(vd);v.X=p.x;v.Y=p.y;v.Z=p.z;return v end
 local function unpack(hit)
  local args,outs={},{};for _,n in ipairs(names)do if n=='Hit'then args[#args+1]=hit else local t={};args[#args+1]=t;outs[n]=t end end
  fn(gs,table.unpack(args));local d={};for k,o in pairs(outs)do d[k]=o.result end;return d
 end
 local s={queries=0,decoded=0}
 function s:weapon()
  local p=api:get_local_pawn(0);if not p or not hook.exists(p)then return nil end
  local h=p:get_property('WeaponHandlerComponent');if not h or not hook.exists(h)or h:get_outer()~=p then return nil end
  local w=h:get_property('EquippedMeleeWeapon')
  if not w or not hook.exists(w)or not w:get_full_name():find('BP_Chainsword_C ',1,true)then return nil end
  return w,p
 end
 function s:cast(a,b,radius)
  local w,p=self:weapon();assert(w,'Native chainsword unavailable')
  local dx,dy,dz=b.x-a.x,b.y-a.y,b.z-a.z;local len=math.sqrt(dx*dx+dy*dy+dz*dz)
  -- UE zero-length sweep has version-specific behaviour. A 0.01cm epsilon keeps overlap queries explicit.
  if len<.01 then dx,dy,dz,len=.01,0,0,.01 end
  local result={};local ignore={p,w};local endp={x=a.x+dx,y=a.y+dy,z=a.z+dz}
  for pass=1,16 do
   local out={};local values={WorldContextObject=p,Start=vec(a),End=vec(endp),Radius=radius,TraceChannel=0,bTraceComplex=false,
    ActorsToIgnore=ignore,DrawDebugType=0,OutHit=out,bIgnoreSelf=true,TraceColor={R=0,G=0,B=0,A=0},TraceHitColor={R=0,G=0,B=0,A=0},DrawTime=0}
   local args={};for _,n in ipairs(trace_names)do assert(values[n]~=nil,'Unknown native trace argument '..n);args[#args+1]=values[n]end
   self.queries=self.queries+1
   local found=trace(system,table.unpack(args));if not found then break end
   local hit=assert(out.result,'Native trace did not return HitResult')
   local d=unpack(hit);local target=d.HitActor;local component=d.HitComponent
   if target and hook.exists(target)and target~=p and target~=w then
    local channel=component and hook.exists(component)and component:GetCollisionObjectType()
    local enemy=target:is_a(enemyClass)
    if enemy or d.bBlockingHit==true then
     local q=d.ImpactPoint or d.Location;assert(q and type(d.Time)=='number','Native hit decoding failed')
     result[#result+1]={key=target:get_full_name()..':'..tostring(target:get_address()),wall=not enemy,
      point={x=q.X,y=q.Y,z=q.Z},time=math.max(0,math.min(1,d.Time)),hit=hit,actor=target,channel=channel,initial=d.bInitialOverlap==true}
     self.decoded=self.decoded+1
    end
    if not enemy then break end
    ignore[#ignore+1]=target
   else
    error('Native collision missing a valid actor')
   end
  end
  return result
 end
 function s:component_pose(component)
  assert(component and hook.exists(component),'Component unavailable')
  local t=component:K2_GetComponentToWorld();local p,q=t.Translation,t.Rotation
  return {position={x=p.X,y=p.Y,z=p.Z},rotation={x=q.X,y=q.Y,z=q.Z,w=q.W}}
 end
 return s
end
return M
