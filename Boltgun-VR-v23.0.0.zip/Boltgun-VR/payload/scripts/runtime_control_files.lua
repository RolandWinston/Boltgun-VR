-- Only small launcher controls are shared for at most 50 ms. Tracking is never cached here.
local M={}
local controls={['labvisuals.mode']=true,['labcombat.mode']=true,['labvisuals.session_nonce']=true}
function M.new(raw,clock)
 clock=clock or os.clock
 local cache={};local out={}
 function out.read(path)
  if not controls[path]then return raw.read(path)end
  local now=clock();local c=cache[path]
  local finite=type(now)=='number'and now==now and math.abs(now)<1e12
  if finite and c and now>=c.at and now-c.at<.05 then return c.value end
  cache[path]=nil -- A failed refresh must not retain an earlier enabled value.
  local value=raw.read(path)
  if finite then cache[path]={at=now,value=value}end
  return value
 end
 function out.write(path,...)
  cache[path]=nil
  return raw.write(path,...)
 end
 return out
end
return M
