-- The observer publishes raw Windows FILETIME; the launcher/native plugins use .NET UTC ticks.
-- Compare their exact decimal strings without rounding 100ns timestamps through floating point.
local M={}
local OFFSET='504911232000000000'
local function parse(s)
 if type(s)~='string'then return nil end
 local pid,stamp=s:match('^([1-9]%d*):([1-9]%d*)$')
 if not pid or #pid>10 or tonumber(pid)>4294967295 or #stamp>19 then return nil end
 return pid,stamp
end
local function add(a,b)
 local out,carry={},0;local i,j=#a,#b
 while i>0 or j>0 or carry>0 do
  local n=carry+(i>0 and a:byte(i)-48 or 0)+(j>0 and b:byte(j)-48 or 0)
  out[#out+1]=string.char(48+n%10);carry=math.floor(n/10);i=i-1;j=j-1
 end
 local s={};for k=#out,1,-1 do s[#s+1]=out[k]end;return table.concat(s)
end
function M.matches(observer_filetime,launcher_ticks)
 local p,t=parse(observer_filetime);local q,u=parse(launcher_ticks)
 return p~=nil and p==q and add(t,OFFSET)==u
end
return M
