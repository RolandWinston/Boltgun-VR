-- Player grenade placement uses the actual rendered right palm, independent of equipped gun.
local Identity=require('session_identity');local M={}
function M.new(e)
 local api,hook,fn=e.uevr.api,e.uevr.types.UObjectHook,e.uevr.params.functions
 local s={sent=0,revoked=0,stopped=false};local previous,stamp,epoch,identity
 local function valid(o)return o and hook.exists(o)end
 local function off()fn.dispatch_custom_event('boltgun.grenade.hand.v1','off');previous,stamp,epoch,identity=nil,nil,nil,nil;s.revoked=s.revoked+1 end
 function s:step(sample,part,enabled)
  if self.stopped then return end
  local ok,err=pcall(function()
   local pawn=api:get_local_pawn(0);local h=sample and sample.hands and sample.hands.right
   if not enabled or not sample or not sample.fresh or not sample.focused or not sample.foreground or not sample.head or not sample.head.tracked or not h or not h.tracked or not h.active or not Identity.matches(sample.process_nonce,e.fs.read('labvisuals.session_nonce'))or not valid(pawn)or not valid(part)or part:get_outer()~=pawn then off();return end
   if pawn:get_property('bPlayerFinishedLevelLoad')~=true then off();return end
   local key=tostring(pawn:get_address())..':'..tostring(part:get_address())..':'..part:get_full_name()
   if identity~=key or epoch~=sample.epoch then off();identity=key;epoch=sample.epoch end
   if previous and(sample.sequence<previous or sample.clock_qpc<stamp)then off();return end
   if previous==sample.sequence then return end
   previous,stamp=sample.sequence,sample.clock_qpc
   fn.dispatch_custom_event('boltgun.grenade.hand.v1',tostring(pawn:get_address())..'|'..tostring(part:get_address()));self.sent=self.sent+1
  end)
  if not ok then self.stopped=true;self.error=tostring(err);pcall(off)end
 end
 function s:stop()self.stopped=true;pcall(off)end
 function s:inspect()return{sent=self.sent,revoked=self.revoked,stopped=self.stopped,error=self.error,source='actual-rendered-right-palm'}end
 return s
end
return M
