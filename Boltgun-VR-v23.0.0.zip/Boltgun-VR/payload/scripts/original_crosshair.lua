-- Exact HUD child from agent-hud-crosshair-01. Preserve the other HUD widgets.
local M={}
function M.new(e)
 local api,hook=e.uevr.api,e.uevr.types.UObjectHook
 local held;local s={changes=0,hidden=false,stopped=false}
 local function valid(o)return o and hook.exists(o)end
 local function named(o,prefix)return valid(o)and o:get_full_name():sub(1,#prefix)==prefix end
 local function restore()
  if held and valid(held.image)and held.image:get_full_name()==held.name and held.image:GetRenderOpacity()==0 then held.image:SetRenderOpacity(held.opacity)end
  held=nil;s.hidden=false;s.object=nil
 end
 function s:step(pc,active)
  if self.stopped then return end
  local ok,err=pcall(function()
   if not active or not valid(pc)then restore();return end
   local hud=pc:GetHUD()
   if not named(hud,'Gameplay_HUD_C ')or hud:get_property('PlayerOwner')~=pc then restore();return end
   local root=hud:get_property('Player HUD Widget')
   if not named(root,'Gameplay_HUD_UI_C ')then restore();return end
   local cross=root:get_property('W_PlayerHUD_Crosshair')
   if not named(cross,'W_PlayerHUD_Crosshair_C ')then restore();return end
   local image=cross:get_property('Crosshair')
   if not valid(image)or image:get_class():get_full_name()~='Class /Script/UMG.Image' then restore();return end
   local name=image:get_full_name()
   if name~='Image '..cross:get_full_name():match('^[^ ]+ (.+)$')..'.WidgetTree.Crosshair'then restore();return end
   if held and held.image~=image then restore()end
   if not held then
    local opacity=image:GetRenderOpacity();assert(type(opacity)=='number'and opacity>=0 and opacity<=1)
    held={image=image,name=name,opacity=opacity}
   end
   if image:GetRenderOpacity()~=0 then image:SetRenderOpacity(0);self.changes=self.changes+1 end
   self.hidden=image:GetRenderOpacity()==0;self.object=name;assert(self.hidden,'Crosshair opacity readback failed')
  end)
  if not ok then self.stopped=true;self.error=tostring(err);pcall(restore)end
 end
 function s:inspect()return{hidden=self.hidden,object=self.object,changes=self.changes,stopped=self.stopped,error=self.error}end
 function s:stop()pcall(restore);self.stopped=true end
 return s
end
return M
