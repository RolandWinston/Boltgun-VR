-- Reuses local SifuVR defense_pose quaternion validation and Hamilton product.
-- OpenXR grip -Z is little-finger -> thumb; authored mesh +Y is thumb/up.
-- Align model to grip with Rx(-90deg); UEVR applies aim * inverse(offset).
-- Source: Khronos OpenXR semantic grip pose; exact UEVR 4ee5c6b6 UObjectHook.cpp.
local M={}
local function finite(x)return type(x)=='number' and x==x and math.abs(x)<math.huge end
local function quat(q)
 if type(q)~="table" then return nil end
 for _,k in ipairs({"x","y","z","w"}) do if not finite(q[k]) then return nil end end
 local n=math.sqrt(q.x*q.x+q.y*q.y+q.z*q.z+q.w*q.w)
 if not finite(n) or math.abs(n-1)>.01 then return nil end
 return {x=q.x/n,y=q.y/n,z=q.z/n,w=q.w/n}
end
local function mul(a,b)
 return {x=a.w*b.x+a.x*b.w+a.y*b.z-a.z*b.y,
 y=a.w*b.y-a.x*b.z+a.y*b.w+a.z*b.x,
 z=a.w*b.z+a.x*b.y-a.y*b.x+a.z*b.w,
 w=a.w*b.w-a.x*b.x-a.y*b.y-a.z*b.z}
end

function M.offset(grip,aim,use_grip)
 if type(grip)~='table' or type(aim)~='table' or not grip.tracked or not aim.tracked or not grip.active or not aim.active then return nil end
 local g,a=quat(grip.rotation),quat(aim.rotation);if not g or not a then return nil end
 if not use_grip then return {x=0,y=0,z=0,w=1}end
 local basis_inverse={x=math.sqrt(.5),y=0,z=0,w=math.sqrt(.5)}
 return mul(basis_inverse,mul({x=-g.x,y=-g.y,z=-g.z,w=g.w},a))
end
return M
