local Sweep=require('blade_sweep');local Gesture=require('swing_gesture');local M={}
function M.new(query,damage,opt)
 local g=Gesture.new();local b=Sweep.new(query,function(id,h)return damage:apply(id,h.hit or h)end,opt)
 local previous;local s={gesture=g,blade=b,events={},samples=0}
 function s:reset()g:reset();b:finish();damage:finish();previous=nil end
 function s:step(hand,world,dt,valid)
  if not valid or not Sweep.valid(world)then self:reset();return {} end
  self.samples=self.samples+1;local action,id=g:step(hand,dt,valid)
  if action=='invalid'or action=='discontinuity'then b:finish();damage:finish();previous=nil;return {}end
  if action=='begin'and previous then assert(damage:begin(id),'Native swing identity rejected');assert(b:begin(id,previous),'Blade swing identity rejected')end
  if action=='end'then b:finish();damage:finish()end
  local hits=b:step(world,dt,valid);previous=world
  if b.rejection then self:reset()end
  for _,h in ipairs(hits)do self.events[#self.events+1]=h;if #self.events>16 then table.remove(self.events,1)end end
  return hits
 end
 return s
end
return M
