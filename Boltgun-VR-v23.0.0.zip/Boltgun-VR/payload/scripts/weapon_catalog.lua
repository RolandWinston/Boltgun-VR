-- Owned player weapons use native class ancestry, including machine-spirit subclasses.
local M={}
M.ids={'Bolter','Shotgun','Plasmagun','HeavyBolter','Meltagun','VolkiteCaliver','VengeanceLauncher','Gravgun','MultiMelta','MissileLauncher'}
M.by_class={
 ['Class /Script/Boltgun.BGBoltgun']='Bolter',
 ['Class /Script/Boltgun.BGShotgun']='Shotgun',
 ['Class /Script/Boltgun.BGPlasmagun']='Plasmagun',
 ['Class /Script/Boltgun.BGHeavyBolter']='HeavyBolter',
 ['Class /Script/Boltgun.BGMeltagun']='Meltagun',
 ['Class /Script/Boltgun.BGVolkiteCaliver']='VolkiteCaliver',
 ['Class /Script/Boltgun.BGVengeanceLauncher']='VengeanceLauncher',
 ['Class /Script/Boltgun.BGGravgun']='Gravgun',
 ['Class /Script/Boltgun.BGMultiMelta']='MultiMelta',
 ['Class /Script/Boltgun.BGMissileLauncher']='MissileLauncher',
}
function M.id(weapon)
 if not weapon then return nil end
 local c=weapon:get_class()
 for i=1,16 do
  if not c then return nil end
  local id=M.by_class[c:get_full_name()];if id then return id end
  c=c:get_super_struct()
 end
end
function M.is_gun(id)for _,v in ipairs(M.ids)do if v==id then return true end end;return false end
return M
