-- Use the real game settings singleton, preserve values for script reset.
local M={}
function M.new(e)
 local api=e.uevr.api;local state={ready=false,errors=0};local object,initial;local next_check=0
 local options={'ScreenShake','HeadBobbing','ForceFeedback'}
 function state:step(now)
  if self.stopped or now<next_check then return end;next_check=now+1
  local ok,err=pcall(function()
   if not object then
    local c=assert(api:find_uobject('Class /Script/Boltgun.BGGameUserSettings'));object=assert(c:get_class_default_object():GetBGGameUserSettings());initial={}
    assert(object:get_class():find_function('IsToggleRunEnabled')and object:get_class():find_function('SetToggleRun'),'Native hold-run settings unavailable');initial.ToggleRun=object:IsToggleRunEnabled()
    for _,k in ipairs(options)do initial[k]=object['Is'..k..'Enabled'](object)end
   end
   local observed={}
   if object:IsToggleRunEnabled()then object:SetToggleRun(false)end
   observed.ToggleRun=object:IsToggleRunEnabled();assert(observed.ToggleRun==false,'Hold-run setting readback')
   for _,k in ipairs(options)do
    if object['Is'..k..'Enabled'](object)then object['Set'..k..'Enabled'](object,false)end
    observed[k]=object['Is'..k..'Enabled'](object);assert(observed[k]==false,k..' setting readback')
   end
   self.values=observed;self.ready=true
  end)
  if not ok then self.ready=false;self.error=tostring(err);self.errors=self.errors+1;if self.errors>=3 then self.stopped=true end end
 end
 function state:restore()
  if object and initial then if object:IsToggleRunEnabled()==false then object:SetToggleRun(initial.ToggleRun)end;for _,k in ipairs(options)do if object['Is'..k..'Enabled'](object)==false then object['Set'..k..'Enabled'](object,initial[k])end end end;self.stopped=true
 end
 function state:inspect()return{ready=self.ready,errors=self.errors,error=self.error,values=self.values,stopped=self.stopped}end
 return state
end
return M
