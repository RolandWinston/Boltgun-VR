-- Derived from Boltgun VR's verified sprite identity/restore checks (GPL-3.0-or-later).
-- Single owner for the two first-person planes; called after the game's animation tick.
local M={}
function M.new(e)
 local api,hook,fs=e.uevr.api,e.uevr.types.UObjectHook,e.fs
 local journal='labvisuals.original-planes.owned'
 local owner,renderer,planes,nonce,owner_id,renderer_id
 local recovered=false
 local state={active=false,errors=0,stopped=false}
 local function valid(o)return o~=nil and hook.exists(o)end
 local function id(o)return {name=o:get_full_name(),address=tostring(o:get_address()),class=o:get_class():get_full_name()}end
 local function same(o,i)return valid(o)and i and o:get_full_name()==i.name and tostring(o:get_address())==i.address and o:get_class():get_full_name()==i.class end
 local function prop(o,k)
  if not valid(o)then return nil end
  local c=o:get_class();if not valid(c)or not c:find_property(k)then return nil end
  return o:get_property(k)
 end
 local function write(s)fs.write(journal,s);assert(fs.read(journal)==s,'Plane journal unavailable')end
 local function current()
  if not same(owner,owner_id)or not same(renderer,renderer_id)or prop(owner,'WeaponRenderer')~=renderer or renderer:get_outer()~=owner then return false end
  for _,p in ipairs(planes or {})do
   if not same(p.o,p.identity)or p.o:get_outer()~=renderer or prop(renderer,p.key)~=p.o then return false end
  end
  return true
 end
 local function restore()
  if current()then
   for _,p in ipairs(planes)do
    if prop(p.o,'bHiddenInGame')==true and prop(p.o,'bVisible')==false then
     p.o:SetHiddenInGame(p.hidden,false);p.o:SetVisibility(p.visible,false)
    end
   end
  end
  owner,renderer,planes=nil,nil,nil;owner_id,renderer_id=nil,nil;state.active=false;write('')
 end
 local function snapshot(pawn)
  local r=prop(pawn,'WeaponRenderer');assert(valid(r)and r:get_outer()==pawn,'Original renderer owner unavailable')
  local ps={}
  for _,key in ipairs({'PrimaryRenderPlane','SecondaryRenderPlane'})do
   local p=prop(r,key)
   assert(valid(p)and p:get_outer()==r and p:get_class():get_full_name()=='Class /Script/Engine.StaticMeshComponent','Original plane identity unavailable')
   assert(p:get_short_name()==(key=='PrimaryRenderPlane'and 'Primary Render Plane'or 'Secondary Render Plane'),'Original plane name mismatch')
   local h,v=prop(p,'bHiddenInGame'),prop(p,'bVisible')
   assert(type(h)=='boolean'and type(v)=='boolean','Original visibility unavailable')
   ps[#ps+1]={o=p,key=key,identity=id(p),hidden=h,visible=v}
  end
  owner,renderer,planes=pawn,r,ps;owner_id,renderer_id=id(pawn),id(r)
 end
 local function remember()
  local a={'v1',nonce,owner_id.name,owner_id.address,owner_id.class,renderer_id.name,renderer_id.address,renderer_id.class}
  for _,p in ipairs(planes)do for _,v in ipairs({p.identity.name,p.identity.address,p.identity.class,tostring(p.hidden),tostring(p.visible)})do a[#a+1]=v end end
  write(table.concat(a,'\n'))
 end
 local function recover(n)
  local s=fs.read(journal);if s==''then recovered=true;return end
  local a={};for v in s:gmatch('[^\r\n]+')do a[#a+1]=v end
  assert(#a==18 and a[1]=='v1','Original plane recovery record invalid')
  if a[2]~=n then write('');recovered=true;return end
  local p=api:find_uobject(a[3]);if not valid(p)then write('');recovered=true;return end
  assert(same(p,{name=a[3],address=a[4],class=a[5]}),'Original owner identity changed')
  snapshot(p)
  assert(same(renderer,{name=a[6],address=a[7],class=a[8]}),'Original renderer identity changed')
  for i,plane in ipairs(planes)do
   local j=9+(i-1)*5
   assert(same(plane.o,{name=a[j],address=a[j+1],class=a[j+2]}),'Original plane identity changed')
   assert((a[j+3]=='true'or a[j+3]=='false')and(a[j+4]=='true'or a[j+4]=='false'),'Original flags invalid')
   plane.hidden,plane.visible=a[j+3]=='true',a[j+4]=='true'
  end
  restore();recovered=true
 end
 function state:step(pawn,n,enabled)
  if self.stopped or type(n)~='string'or not n:match('^%d+:%d+$')then return end
  local ok,err=pcall(function()
   if not recovered then recover(n)end
   if owner and (not enabled or pawn~=owner or not current())then restore()end
   if not enabled or not valid(pawn)then return end
   if not owner then nonce=n;snapshot(pawn);remember()end
   assert(current(),'Original planes changed')
   for _,p in ipairs(planes)do
    p.o:SetHiddenInGame(true,false);p.o:SetVisibility(false,false)
    assert(prop(p.o,'bHiddenInGame')==true and prop(p.o,'bVisible')==false,'Plane hide readback failed')
   end
   self.active=true
  end)
  if not ok then
   self.errors=self.errors+1;self.error=tostring(err)
   if recovered then pcall(restore)end
   self.stopped=true
  end
 end
 function state:stop()self.stopped=true end -- Recovery happens only on the engine thread.
 return state
end
return M
