-- Port of Lab BladeContact: subdivided rigid blade sweeps, wall priority, base occlusion.
-- UE world units are centimetres. No damage or tracking-state fabrication in this module.
local M={}
local function finite(x)return type(x)=='number'and x==x and math.abs(x)<math.huge end
local function v(x,y,z)return{x=x,y=y,z=z}end
local function add(a,b)return v(a.x+b.x,a.y+b.y,a.z+b.z)end
local function sub(a,b)return v(a.x-b.x,a.y-b.y,a.z-b.z)end
local function scale(a,t)return v(a.x*t,a.y*t,a.z*t)end
local function length(a)return math.sqrt(a.x*a.x+a.y*a.y+a.z*a.z)end
local function lerp(a,b,t)return add(a,scale(sub(b,a),t))end
local function dot(a,b)return a.x*b.x+a.y*b.y+a.z*b.z+a.w*b.w end
local function angle(a,b)return math.deg(2*math.acos(math.min(1,math.abs(dot(a,b)))))end
local function valid(p)
 if type(p)~='table'or type(p.position)~='table'or type(p.rotation)~='table'then return false end
 for _,k in ipairs({'x','y','z'})do if not finite(p.position[k])or not finite(p.rotation[k])then return false end end
 return finite(p.rotation.w)and math.abs(dot(p.rotation,p.rotation)-1)<.002
end
local function slerp(a,b,t)
 local d=dot(a,b);local sign=d<0 and -1 or 1;d=math.abs(d)
 local x,y=1-t,t
 if d<.9995 then local theta=math.acos(math.min(1,d));local den=math.sin(theta);x=math.sin((1-t)*theta)/den;y=math.sin(t*theta)/den end
 local q={};for _,k in ipairs({'x','y','z','w'})do q[k]=a[k]*x+b[k]*y*sign end
 local n=math.sqrt(dot(q,q));for k in pairs(q)do q[k]=q[k]/n end;return q
end
local function point(p,b)
 local q=p.rotation;local t=v(2*(q.y*b.z-q.z*b.y),2*(q.z*b.x-q.x*b.z),2*(q.x*b.y-q.y*b.x))
 return add(p.position,add(b,add(scale(t,q.w),v(q.y*t.z-q.z*t.y,q.z*t.x-q.x*t.z,q.x*t.y-q.y*t.x))))
end
M.point=point;M.angle=angle;M.valid=valid;M.length=length;M.sub=sub
function M.new(query,apply,opt)
 opt=opt or {};local base=opt.base or v(9,0,29);local tip=opt.tip or v(9,0,92);local radius=opt.radius or 3
 assert(radius>=1 and radius<=11)
 local s={active=false,blocked=false,last_id=0,queries=0,contacts=0,damage=0};local previous,seen
 function s:finish()self.active=false;previous=nil end
 function s:begin(id,p)
  if type(id)~='number'or id%1~=0 or id<=self.last_id or not valid(p)then return false end
  self.last_id=id;self.active=true;self.blocked=false;self.rejection=nil;previous=p;seen={};return true
 end
 local function cast(a,b)
  s.queries=s.queries+1;local hits=query(a,b,radius)or{};assert(#hits<=128,'Too many query results')
  for _,h in ipairs(hits)do assert(type(h)=='table'and finite(h.time)and h.time>=0 and h.time<=1 and type(h.wall)=='boolean','Malformed collision result')end
  return hits
 end
 function s:step(p,dt,tracked)
  local out={};if not self.active then return out end
  if not tracked or not valid(p)or not finite(dt)or dt<=0 or dt>.1 then self:finish();self.rejection='tracking-or-time';return out end
  local distance=length(sub(p.position,previous.position));local degrees=angle(p.rotation,previous.rotation)
  if distance>50 or distance/dt>1500 or degrees>100 then self:finish();self.rejection='discontinuity';return out end
  -- Native swept spheres cover the entire translation continuously. Subdivide rotation only
  -- to bound the curved path; repeating linear subsegments adds cost without extra coverage.
  local steps=math.max(1,math.ceil(degrees/5))
  local along=math.ceil(length(sub(tip,base))/(radius*.8));local from=previous
  -- Bound work before applying any contacts; retain prior pose only for an accepted frame.
  if steps*(along+2)>1200 then self:finish();self.rejection='query-budget';return out end
  for k=1,steps do
   local t=k/steps;local current={position=lerp(previous.position,p.position,t),rotation=slerp(previous.rotation,p.rotation,t)}
   local candidates={}
   for i=0,along do
    local localpoint=lerp(base,tip,i/along)
    for _,h in ipairs(cast(point(from,localpoint),point(current,localpoint)))do candidates[#candidates+1]=h end
   end
   local cb,ct=point(current,base),point(current,tip)
   -- A sphere swept along the current blade also covers initial overlaps.
   for _,h in ipairs(cast(cb,ct))do local c={};for key,value in pairs(h)do c[key]=value end;c.time=1;candidates[#candidates+1]=c end
   table.sort(candidates,function(a,b)if a.time==b.time then return a.wall and not b.wall end;return a.time<b.time end)
   for _,h in ipairs(candidates)do
    if h.wall then self.blocked=true;self:finish();return out end
    if h.key and not seen[h.key]then
     for _,w in ipairs(cast(cb,h.point))do if w.wall then self.blocked=true;self:finish();return out end end
     seen[h.key]=true;self.contacts=self.contacts+1
     local ok,result=apply(self.last_id,h);if ok then self.damage=self.damage+1 end
     out[#out+1]={ok=ok,result=result,key=h.key}
    end
   end
   from=current
  end
  previous=p;return out
 end
 return s
end
return M
