-- Same rigid muzzle landmark as native muzzle_math.hpp; inputs are the actual rendered mesh.
local Landmarks=require('weapon_landmarks')
local M={range_cm=10000}
local function finite(v)return type(v)=='number'and v==v and math.abs(v)<1e12 end
local function vec(v)return type(v)=='table'and finite(v.x)and finite(v.y)and finite(v.z)end
local function mul(a,b)return{x=a.w*b.x+a.x*b.w+a.y*b.z-a.z*b.y,y=a.w*b.y-a.x*b.z+a.y*b.w+a.z*b.x,z=a.w*b.z+a.x*b.y-a.y*b.x+a.z*b.w,w=a.w*b.w-a.x*b.x-a.y*b.y-a.z*b.z}end
local function rotate(q,p)local r=mul(mul(q,{x=p.x,y=p.y,z=p.z,w=0}),{x=-q.x,y=-q.y,z=-q.z,w=q.w});return{x=r.x,y=r.y,z=r.z}end
local function add(a,b,f)return{x=a.x+b.x*f,y=a.y+b.y*f,z=a.z+b.z*f}end
function M.ray(world)
 if type(world)~='table'or not vec(world.position)or not vec(world.scale)then return nil end
 local q=world.rotation;if type(q)~='table'or not vec(q)or not finite(q.w)then return nil end
 local norm=q.x*q.x+q.y*q.y+q.z*q.z+q.w*q.w;if math.abs(norm-1)>.01 then return nil end
 local n=math.sqrt(norm);q={x=q.x/n,y=q.y/n,z=q.z/n,w=q.w/n}
 for _,v in pairs(world.scale)do if not finite(v)or v<.01 or v>10 then return nil end end
 local offset=rotate(q,{x=Landmarks.muzzle.x*world.scale.x,y=Landmarks.muzzle.y*world.scale.y,z=Landmarks.muzzle.z*world.scale.z})
 local origin=add(world.position,offset,1);local direction=rotate(q,{x=1,y=0,z=0})
 return {origin=origin,direction=direction,finish=add(origin,direction,M.range_cm)}
end
function M.marker(ray,hit,eye)
 if not ray or not vec(eye)then return nil end
 local point=hit and hit.point or ray.finish;if not vec(point)then return nil end
 if hit and (hit.initial or not finite(hit.time)or hit.time<0 or hit.time>1)then return nil end
 local dx,dy,dz=point.x-ray.origin.x,point.y-ray.origin.y,point.z-ray.origin.z
 local distance=math.sqrt(dx*dx+dy*dy+dz*dz)
 if distance<2 or distance>M.range_cm+1 then return nil end
 -- The visual surface sits slightly towards the muzzle to avoid coplanar flicker.
 local position=add(point,ray.direction,-.4)
 local ex,ey,ez=eye.x-position.x,eye.y-position.y,eye.z-position.z
 local eye_distance=math.sqrt(ex*ex+ey*ey+ez*ez);if eye_distance<10 then return nil end
 return {point=point,position=position,distance_cm=distance,eye_distance_cm=eye_distance,
  scale=math.max(.1,math.min(20,eye_distance*.0015)),
  rotation={pitch=math.deg(math.atan(ez,math.sqrt(ex*ex+ey*ey))),yaw=math.deg(math.atan(ey,ex))},
  hit=hit~=nil,actor=hit and hit.actor,component=hit and hit.component}
end
return M
