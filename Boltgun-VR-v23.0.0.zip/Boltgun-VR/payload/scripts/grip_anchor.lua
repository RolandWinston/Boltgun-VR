-- GPL-3.0-or-later adapter; actual UEVR offset basis measured in agent-native-26.
local M={}
local anchors={
 LeftArm={x=9.308925073,y=2.013539551,z=0.000000000},
 RightArm={x=9.308925073,y=-2.013539551,z=0.000000000},
 Bolter={x=9.000000000,y=-1.800000000,z=0.000000000},
 Chainsword={x=9.000000000,y=-1.800000000,z=0.000000000},
}
function M.anchor(id)local p=assert(anchors[id]or(require('weapon_catalog').is_gun(id)and anchors.Bolter),'Unknown grip asset');return{x=p.x,y=p.y,z=p.z}end
function M.offset(id)local p=M.anchor(id);return{x=p.y,y=p.z,z=-p.x}end
return M
