-- Windows/UEVR candidate. Reuses menu_trigger_policy and the local tracking observer.
-- Engine reads and view changes run on engine tick. Input callback only reads snapshots.
local Policy=require('menu_trigger_policy')
local M={}
local function finite(v)return type(v)=='number' and v==v and math.abs(v)<1e12 end
local function eq(a,b)return a==b or (tonumber(a)~=nil and tonumber(a)==tonumber(b))end
function M.start(e)
 local vr,api,cb=e.uevr.params.vr,e.uevr.api,e.uevr.sdk.callbacks
 local hook=e.uevr.types.UObjectHook;local reading='initialization'
 local function valid(o)return o~=nil and hook.exists(o)end
 local fn=e.uevr.params.functions
 local clock=e.clock or os.clock
 local state=Policy.new()
 local status={version='BOLT-MENU-RUNTIME-02',accepted=0,errors=0,stopped=false,mode='unknown',clock_verified=false,game_verified=false}
 local lease={}
 local selected_user
 local context,tracking,last_input,clock_base,last_clock,epoch,sequence,pending_epoch=nil,nil,nil,nil,nil,nil,0,false
 local function persist_lease()
  e.json.dump_file('boltgun-menu-lease-v1.json',{version=1,values=lease},-1)
 end
 local function restore()
  local remaining={}
  for key,item in pairs(lease)do
   local ok=pcall(function()
    if eq(vr:get_mod_value(key),item.applied)then
     vr.set_mod_value(key,item.original)
     if not eq(vr:get_mod_value(key),item.original)then error('restore readback '..key)end
    end
   end)
   if not ok then remaining[key]=item end
  end
  lease=remaining;pcall(persist_lease)
 end
 local function stop(reason)
  status.stopped=true;status.reason=reason;status.clock_verified=false;tracking=nil;context=nil
  restore()
 end
 local function error_bound(err)
  status.errors=status.errors+1;status.last_error=reading..': '..tostring(err);fn.log_info('[Boltgun menu bounded error] '..tostring(err));tracking=nil;context=nil
  if status.errors>=3 then stop('error_bound')end
 end
 local function guarded(f)
  return function(...)local ok,err=pcall(f,...);if not ok then error_bound(err)end end
 end
 local function time()
  local n=clock()
  if not finite(n) or n<0 or (last_clock and n<last_clock)then stop('clock_discontinuity');return nil end
  last_clock=n;return n
 end
 local function tracked(now)
  return tracking and now>=tracking.at and now-tracking.at<=.075 and tracking.good
 end
 local function name(o)if not valid(o)then return nil end;return o:get_full_name()end
 local function is_game(pawn)
  return type(pawn)=='string' and pawn:match('^BP_PlayerCharacter_Sternguard_C /Game/Maps/[^ ]+%.PersistentLevel%.BP_PlayerCharacter_Sternguard_C_%d+$')~=nil
 end
 local function loading_confirm(pawn,pawn_name)
  if not valid(pawn)or not is_game(pawn_name) or pawn:get_property('bPlayerFinishedLevelLoad')~=false then return false end
  local cls=api:find_uobject('WidgetBlueprintGeneratedClass /Game/Blueprints/UI/19_Level_Loading/W_UI_20_Level_Loading.W_UI_20_Level_Loading_C');if not valid(cls) then return false end
  -- Query the observed exact generated class; the generic widget order is unstable.
  -- Runs only before gameplay finishes loading, on the engine thread.
  for _,o in ipairs(cls:get_objects_matching(false))do
   if valid(o)and Policy.loading(pawn_name,false,name(o)) and o:IsInViewport() and o:IsVisible()then return true end
  end
  return false
 end
 local function apply_view(mode)
  -- Size is plane height: Lab width / (16/9). Values are candidates, not L4D2 exports.
  local desired={UI_FollowView='false',UI_Distance=mode=='frontend' and '3' or '1.35',UI_Size=mode=='frontend' and '0.84375' or '0.95625',UI_OverlayType='0',VR_DecoupledPitchUIAdjust='false',VR_SnapTurn='false'}
  local changed=false
  for _,key in ipairs({'UI_FollowView','UI_Distance','UI_Size','UI_OverlayType','VR_DecoupledPitchUIAdjust','VR_SnapTurn'})do
   local current=vr:get_mod_value(key);if type(current)~='string' then error('missing setting '..key)end
   local item=lease[key]
   if item and not eq(current,item.applied)then stop('view_changed_externally');return false end
   if not item then
    item={original=current,applied=current};lease[key]=item;persist_lease()
   end
   if not eq(current,desired[key])then
    item.applied=desired[key]
    persist_lease() -- Recovery record precedes mutation.
    vr.set_mod_value(key,desired[key]);changed=true
    if not eq(vr:get_mod_value(key),desired[key])then error('view readback '..key)end
   end
  end
  if changed then status.view_changes=(status.view_changes or 0)+1 end
  return true
 end
 -- Recover only our recorded values; preserve independently edited settings.
 local ok,old=pcall(e.json.load_file,'boltgun-menu-lease-v1.json')
 if not ok then stop('recovery_read_failed')end
 if ok and type(old)=='table' and old.version==1 and type(old.values)=='table'then
  for _,key in ipairs({'UI_FollowView','UI_Distance','UI_Size','UI_OverlayType','VR_DecoupledPitchUIAdjust','VR_SnapTurn'})do
   local item=old.values[key]
   if type(item)=='table' and type(item.original)=='string' and type(item.applied)=='string'then lease[key]=item end
  end
  restore()
  if next(lease)then stop('recovery_pending')end
 end
 cb.on_lua_event(guarded(function(event,data)
  if event~='boltgun_tracking_v1' or status.stopped then return end
  local now=time();if not now then return end
  local v=e.json.load_string(data)
  if type(v)~='table' or v.bridge~='boltgun-tracking-v1' or not finite(v.clock_qpc) or v.clock_qpc<0
    or not finite(v.epoch) or v.epoch<0 or v.epoch%1~=0 or not finite(v.sequence) or v.sequence%1~=0 then
   tracking=nil;status.clock_verified=false;clock_base=nil;return
  end
  if epoch~=v.epoch then epoch=v.epoch;sequence=0;pending_epoch=true end
  if v.sequence<=sequence then tracking=nil;return end
  sequence=v.sequence
  if not clock_base then clock_base={local_time=now,qpc=v.clock_qpc};status.clock_verified=false
  else
   local dt,dq=now-clock_base.local_time,v.clock_qpc-clock_base.qpc
   if dt<0 or dq<0 or math.abs(dt-dq)>.025 then
    status.clock_verified=false;clock_base={local_time=now,qpc=v.clock_qpc};pending_epoch=true
   elseif dq>=.25 then status.clock_verified=true end
  end
  local h=v.hands and v.hands.right
  tracking={at=now,sample=v,good=v.fresh==true and v.focused==true and v.foreground==true
   and type(v.head)=='table' and v.head.tracked==true and type(h)=='table' and h.tracked==true and h.active==true}
 end))
 cb.on_pre_engine_tick(guarded(function()
  if status.stopped then return end
  local now=time();if not now then return end
  reading='get local pawn';local pawn_object=api:get_local_pawn(0);if not valid(pawn_object)then pawn_object=nil end
  reading='get current object names';local controller,pawn=name(api:get_player_controller(0)),name(pawn_object)
  reading='read level loaded';local mode=Policy.frontend(controller,pawn) and 'frontend' or is_game(pawn) and (pawn_object:get_property('bPlayerFinishedLevelLoad')==true and 'gameplay' or 'loading') or 'unknown'
  -- A widget can be registered before its native Slate surface exists, or survive world teardown.
  -- An unavailable optional visibility sample is not a loss of controller tracking.
  reading='read loading widgets';local observed,loading=pcall(loading_confirm,pawn_object,pawn)
  if not observed then status.loading_probe_failures=(status.loading_probe_failures or 0)+1;status.loading_probe_error=tostring(loading);loading=false end
  context={at=now,mode=mode,loading_confirm=loading};status.mode=mode;status.loading_confirm=loading
  reading='apply menu view';if mode~='unknown' and vr.is_runtime_ready()then apply_view(mode)end;reading='idle'
 end))
 cb.on_script_reset(function()stop('script_reset')end)
 status.inspect=function()return {status=status,lease=lease,context=context,tracking=tracking}end
 return status
end
return M
