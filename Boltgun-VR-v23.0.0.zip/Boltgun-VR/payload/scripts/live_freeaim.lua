-- Production gate consumes the observer. External scripted XR diagnostics are labeled in their run evidence; this module has no diagnostic bypass.
local Identity=require("session_identity");local M={}
local function finite(x)return type(x)=='number'and x==x and math.abs(x)<1e12 end
function M.new(e)
 local api,hook,fn=e.uevr.api,e.uevr.types.UObjectHook,e.uevr.params.functions
 local s={stopped=false,sent=0,revoked=0,source='actual-tracking-owned-player-weapon'}
 local sequence,stamp,epoch,nonce,identity
 local function off()
  fn.dispatch_custom_event('boltgun.freeaim.v1','off');s.revoked=s.revoked+1
  sequence,stamp,epoch,nonce,identity=nil,nil,nil,nil,nil
 end
 local function valid(o)return o and hook.exists(o)end
 local function prop(o,k)
  if not valid(o)or not o:get_class():find_property(k)then return nil end
  return o:get_property(k)
 end
 local function pose(h)return type(h)=='table'and h.active==true and h.tracked==true end
 local function step(sample,component,enabled)
  if not enabled or type(sample)~='table'or not sample.fresh or not sample.focused or not sample.foreground
   or not sample.head or not sample.head.tracked or not pose(sample.hands and sample.hands.right)
   or not pose(sample.aims and sample.aims.right)or not finite(sample.clock_qpc)or not finite(sample.sequence)
   or sample.sequence%1~=0 or not finite(sample.epoch)or not Identity.matches(sample.process_nonce,e.fs.read('labvisuals.session_nonce'))
   or not valid(component)then off();return end
  local pawn=api:get_local_pawn(0);local handler=prop(pawn,'WeaponHandlerComponent');local weapon=prop(handler,'EquippedWeapon')
  if not valid(pawn)or prop(pawn,'bPlayerFinishedLevelLoad')~=true or not valid(handler)or handler:get_outer()~=pawn
   or not valid(weapon)or component:get_outer()~=pawn
   or component:get_class():get_full_name()~='Class /Script/ProceduralMeshComponent.ProceduralMeshComponent'then off();return end
  if not require('weapon_catalog').id(weapon)then off();return end
  local key=pawn:get_full_name()..':'..tostring(pawn:get_address())..':'..tostring(weapon:get_address())..':'..component:get_full_name()..':'..tostring(component:get_address())
  if epoch~=sample.epoch or nonce~=sample.process_nonce or identity~=key then off();epoch=sample.epoch;nonce=sample.process_nonce;identity=key end
  if sequence and(sample.sequence<sequence or sample.clock_qpc<stamp)then off();return end
  if sequence==sample.sequence then return end -- Repeated/stale observer data never renews the native lease.
  sequence=sample.sequence;stamp=sample.clock_qpc
  fn.dispatch_custom_event('boltgun.freeaim.v1',tostring(pawn:get_address())..'|'..tostring(weapon:get_address())..'|'..tostring(component:get_address()))
  s.sent=s.sent+1;s.sequence=sequence
 end
 function s:step(sample,component,enabled)
  if self.stopped then return end
  local ok,why=pcall(step,sample,component,enabled)
  if not ok then self.stopped=true;self.error=tostring(why);pcall(off);fn.log_info('[Boltgun free aim] stopped: '..self.error)end
 end
 function s:stop()self.stopped=true;pcall(off)end
 function s:inspect()return{stopped=self.stopped,error=self.error,sent=self.sent,revoked=self.revoked,sequence=self.sequence,source=self.source}end
 return s
end
return M
