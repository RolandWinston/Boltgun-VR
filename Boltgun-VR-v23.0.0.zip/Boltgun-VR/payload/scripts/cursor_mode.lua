-- UE 4.27 native input mode; preserves game/UI routing while removing viewport lock.
local M={}
function M.new(e)
 local api,hook=e.uevr.api,e.uevr.types.UObjectHook
 local last,lib,fn,gs,next_intro_refresh
 local state={changes=0,stopped=false}
 local function valid(o)return o and hook.exists(o)end
 local function prop(o,k)
  if not valid(o)or not o:get_class():find_property(k)then return nil end
  return o:get_property(k)
 end
 local function identity(o)return valid(o)and(o:get_full_name()..':'..tostring(o:get_address()))or'none'end
 function state:step(enabled)
  if self.stopped or not enabled then return end
  local ok,err=pcall(function()
   local pc=api:get_player_controller(0);if not valid(pc)then return end
   local name=pc:get_full_name();if not name:find('/Game/Maps/',1,true)then return end
   if not fn then
    local c=assert(api:find_uobject('Class /Script/UMG.WidgetBlueprintLibrary'))
    lib=c:get_class_default_object();fn=assert(c:find_function('SetInputMode_GameAndUIEx'))
    local expected={'PlayerController','InWidgetToFocus','InMouseLockMode','bHideCursorDuringCapture'}
    local f=fn:get_child_properties();local names={}
    while f do
     local key=f:get_fname():to_string();local p=fn:find_property(key)
     if p and p:is_param()then names[#names+1]=key end
     f=f:get_next()
    end
    assert(#names==4,'Unsupported input mode ABI')
    for i,n in ipairs(expected)do assert(names[i]==n,'Input mode signature changed')end
    gs=api:find_uobject('Class /Script/Engine.GameplayStatics'):get_class_default_object()
   end
   local pawn=api:get_local_pawn(0);local hud=prop(pc,'MyHUD');local menu=prop(hud,'CurrentMenu')
   if not valid(menu)then menu=nil end
   local paused=gs:IsGamePaused(pc)
   local loaded=prop(pawn,'bPlayerFinishedLevelLoad')
   local intro=valid(pawn) and loaded==false
   local now=os.clock()
   -- Cinematic viewport focus can recapture the mouse without changing PC/Pawn/menu.
   -- Refresh only during the observed pre-load phase, at most five times a second.
   local refresh=intro and (not next_intro_refresh or now>=next_intro_refresh)
   local key=table.concat({identity(pc),identity(pawn),identity(menu),tostring(prop(menu,'Visibility')),tostring(loaded),tostring(paused)},'|')
   if key~=last or refresh then
    fn(lib,pc,menu,0,false)
    last=key;self.changes=self.changes+1;self.paused=paused;self.menu=identity(menu)
    next_intro_refresh=intro and now+.2 or nil
   end
  end)
  if not ok then self.stopped=true;self.error=tostring(err)end
 end
 function state:stop()self.stopped=true end
 return state
end
return M
