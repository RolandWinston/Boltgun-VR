-- GPL-3.0-or-later. Uses the pinned UObjectHook HMD attachment when UEVR's button-activity timer expires.
-- Raw tracking freshness/ownership remain enforced by the caller. No synthetic input or timestamp renewal.
-- Algebra from UObjectHook.cpp tick_attachments; native26 offset basis and native27 HMD-relative placement.
local Grip=require('grip_anchor')
local M={}
local function finite(v)return type(v)=='number'and v==v and math.abs(v)<1e8 end
local function vector(p)
 if type(p)~='table'then return nil end
 for _,k in ipairs({'x','y','z'})do if not finite(p[k])then return nil end end
 return p
end
local function quat(q)
 if type(q)~='table'then return nil end
 for _,k in ipairs({'x','y','z','w'})do if not finite(q[k])then return nil end end
 local n=math.sqrt(q.x*q.x+q.y*q.y+q.z*q.z+q.w*q.w)
 if math.abs(n-1)>.01 then return nil end
 return{x=q.x/n,y=q.y/n,z=q.z/n,w=q.w/n}
end
local function mul(a,b)return{x=a.w*b.x+a.x*b.w+a.y*b.z-a.z*b.y,y=a.w*b.y-a.x*b.z+a.y*b.w+a.z*b.x,z=a.w*b.z+a.x*b.y-a.y*b.x+a.z*b.w,w=a.w*b.w-a.x*b.x-a.y*b.y-a.z*b.z}end
local function inv(q)return{x=-q.x,y=-q.y,z=-q.z,w=q.w}end
local function active(p)return type(p)=='table'and p.active==true and p.tracked==true end
function M.offset(id,pose,use_grip,scale,decoupled)
 if not pose or not active(pose.head)or not active(pose.grip)or not active(pose.aim)or decoupled~=true or not finite(scale)or scale<=0 or scale>100 then return nil end
 local head,grip,aim=quat(pose.head.rotation),quat(pose.grip.rotation),quat(pose.aim.rotation)
 local hp,gp=vector(pose.head.position),vector(pose.grip.position)
 if not head or not grip or not aim or not hp or not gp then return nil end
 local desired=use_grip and mul(grip,{x=-math.sqrt(.5),y=0,z=0,w=math.sqrt(.5)})or aim
 local d={x=(gp.x-hp.x)*100*scale,y=(gp.y-hp.y)*100*scale,z=(gp.z-hp.z)*100*scale,w=0}
 local local_delta=mul(mul(inv(desired),d),desired)
 local p=Grip.offset(id)
 return {hand=2,position={x=p.x-local_delta.x,y=p.y-local_delta.y,z=p.z-local_delta.z},rotation=mul(inv(desired),head)}
end
return M
