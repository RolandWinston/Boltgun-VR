-- Reuses the tested reflected HitResult decoder. One native gun line trace; no damage or target mutation.
local M={}
function M.new(uevr)
 local api=uevr.api;local hook=uevr.types.UObjectHook
 local vd=api:find_uobject('ScriptStruct /Script/CoreUObject.Vector'):as_struct()
 local gs=api:find_uobject('Class /Script/Engine.GameplayStatics'):get_class_default_object()
 local fn=assert(gs:get_class():find_function('BreakHitResult'))
 local system=api:find_uobject('Class /Script/Engine.KismetSystemLibrary'):get_class_default_object()
 local trace=assert(system:get_class():find_function('LineTraceSingle'))
 local trace_names={};local field=trace:get_child_properties()
 while field do local n=field:get_fname():to_string();local p=trace:find_property(n)
  if p and p:is_param()and not p:is_return_param()then trace_names[#trace_names+1]=n end;field=field:get_next()end
 local names={};local f=fn:get_child_properties()
 while f do local k=f:get_fname():to_string();local p=fn:find_property(k)
  if p and p:is_param()and not p:is_return_param()then assert(k=='Hit'or p:is_out_param());names[#names+1]=k end;f=f:get_next()end
 local function vec(p)local v=StructObject.new(vd);v.X=p.x;v.Y=p.y;v.Z=p.z;return v end
 local function unpack(hit)
  local args,outs={},{};for _,n in ipairs(names)do if n=='Hit'then args[#args+1]=hit else local t={};args[#args+1]=t;outs[n]=t end end
  fn(gs,table.unpack(args));local d={};for k,o in pairs(outs)do d[k]=o.result end;return d
 end
 local s={queries=0,decoded=0}
 function s:weapon()
  local p=api:get_local_pawn(0);if not p or not hook.exists(p)then return nil end
  local h=p:get_property('WeaponHandlerComponent');if not h or not hook.exists(h)or h:get_outer()~=p then return nil end
  local w=h:get_property('EquippedWeapon')
  if not w or not hook.exists(w)then return nil end
  if not require('weapon_catalog').id(w)then return nil end
  return w,p
 end
 function s:cast(a,b)
  local w,p=self:weapon();assert(w,'Native equipped supported gun unavailable')
  local out={};local values={WorldContextObject=p,Start=vec(a),End=vec(b),TraceChannel=0,bTraceComplex=false,
   ActorsToIgnore={p,w},DrawDebugType=0,OutHit=out,bIgnoreSelf=true,
   TraceColor={R=0,G=0,B=0,A=0},TraceHitColor={R=0,G=0,B=0,A=0},DrawTime=0}
  local args={};for _,n in ipairs(trace_names)do assert(values[n]~=nil,'Unknown native line trace argument '..n);args[#args+1]=values[n]end
  self.queries=self.queries+1
  local found=trace(system,table.unpack(args));if not found then return nil end
  local hit=assert(out.result,'Native line trace did not return HitResult');local d=unpack(hit)
  assert(d.bBlockingHit==true,'Nonblocking line trace result')
  local actor=d.HitActor;local component=d.HitComponent;local point=d.ImpactPoint or d.Location
  assert(point and type(d.Time)=='number','Native line hit decoding failed');self.decoded=self.decoded+1
  return {point={x=point.X,y=point.Y,z=point.Z},time=d.Time,initial=d.bInitialOverlap==true,
   actor=actor and hook.exists(actor) and actor:get_full_name() or nil,
   component=component and hook.exists(component) and component:get_full_name() or nil}
 end
 function s:component_pose(component)
  assert(component and hook.exists(component),'Component unavailable')
  local t=component:K2_GetComponentToWorld();local p,q=t.Translation,t.Rotation
  return {position={x=p.X,y=p.Y,z=p.Z},rotation={x=q.X,y=q.Y,z=q.Z,w=q.W}}
 end
 return s
end
return M
