-- Runtime InputSettings are authoritative: Boltgun reapplies its gamepad preset on load.
local M={}
local wanted={Fire='Gamepad_RightTrigger',Jump='Gamepad_FaceButton_Bottom',Melee=false,NavigationGuide='Gamepad_LeftTrigger',Pause='Gamepad_FaceButton_Left',Quicksave='Gamepad_FaceButton_Top',Quickload=false,Reload='Gamepad_Special_Right',Use='Gamepad_FaceButton_Right',SkillMobility='Gamepad_RightThumbstick',SkillUlt='Gamepad_RightShoulder',SwitchTech='Gamepad_LeftShoulder',SelectNextWeapon='Gamepad_Special_Left',SelectPrevWeapon=false,SelectLastHeldWeapon=false,Walk='Gamepad_LeftThumbstick',Taunt=false,UI_Accept='Gamepad_FaceButton_Bottom',UI_Back=false}
for _,name in ipairs{'SelectWeaponSlotUp','SelectWeaponSlotDown','SelectWeaponSlotLeft','SelectWeaponSlotRight','SwitchAccounts','UI_AltAction','UI_QuickSave','UI_QuickLoad'}do wanted[name]=false end
for i=1,10 do wanted['SelectWeaponSlot'..i]=false end
function M.new(e)
 local api=e.uevr.api;local state={applied=0,errors=0};local settings,strings,desc;local initial;local next_check=0;local sequence=-1
 local function make(action,k,row)
  local a=StructObject.new(desc);a.ActionName=strings:Conv_StringToName(action);a.Key.KeyName=strings:Conv_StringToName(k)
  for _,f in ipairs{'bShift','bCtrl','bAlt','bCmd'}do a:set_property(f,row and row[f]==true or false)end
  return a
 end
 local function setup()
  settings=assert(api:find_uobject('Class /Script/Engine.InputSettings')):get_class_default_object();strings=assert(api:find_uobject('Class /Script/Engine.KismetStringLibrary')):get_class_default_object();desc=assert(api:find_uobject('ScriptStruct /Script/Engine.InputActionKeyMapping')):as_struct()
  for _,f in ipairs{'ActionName','Key','bShift','bCtrl','bAlt','bCmd'}do assert(desc:find_property(f),'Input mapping ABI '..f)end
 end
 local function getrows()
  local s=e.json.load_file('boltgun-input-bindings.json');if not s then return nil end
  assert(s.version==1 and s.ready==true,'Native binding snapshot unavailable: '..tostring(s.error));assert(type(s.rows)=='table','Native mapping rows missing');return s
 end
 function state:step(now)
  if self.stopped or now<next_check then return end;next_check=now+.6
  local ok,err=pcall(function()
   if not settings then setup()end;local snapshot=getrows();if not snapshot or snapshot.sequence==sequence then return end;sequence=snapshot.sequence
   if not initial then initial=snapshot.rows end;local changed=false;local observed={}
   for action,k in pairs(wanted)do
    local pad={};for _,row in ipairs(snapshot.rows)do if row.action==action then pad[#pad+1]=row end end
    local match=(k and #pad==1 and pad[1].key==k)or(not k and #pad==0)
    if not match then for _,row in ipairs(pad)do settings:RemoveActionMapping(make(action,row.key,row),false)end;if k then settings:AddActionMapping(make(action,k),false)end;changed=true end
    observed[action]=match and(k or 'disabled')or'pending-readback'
   end
   if changed then settings:ForceRebuildKeymaps();self.applied=self.applied+1 end;self.bindings=observed;self.ready=not changed;self.sequence=sequence
  end)
  if not ok then self.errors=self.errors+1;self.error=tostring(err);self.ready=false;if self.errors>=3 then self.stopped=true end end
 end
 function state:restore()
  if not settings or not self.ready or not initial then return end;local snapshot=getrows();if not snapshot then return end
  for _,row in ipairs(snapshot.rows)do if wanted[row.action]~=nil then settings:RemoveActionMapping(make(row.action,row.key,row),false)end end
  for _,row in ipairs(initial)do if wanted[row.action]~=nil then settings:AddActionMapping(make(row.action,row.key,row),false)end end;settings:ForceRebuildKeymaps();self.stopped=true
 end
 function state:inspect()return{applied=self.applied,errors=self.errors,error=self.error,ready=self.ready,stopped=self.stopped,sequence=self.sequence,bindings=self.bindings}end
 return state
end
return M
