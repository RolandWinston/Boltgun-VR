-- Integrates the tested menu adapter and upstream-derived model lifecycle.
local Menu=require('menu_runtime_adapter')
local Component=require('lab_visual_component')
local Pose=require('controller_pose')
local control_files=require('runtime_control_files').new(fs)
local e={uevr=uevr,json=json,fs=control_files}
local menu=Menu.start(e)
local controls=require('controller_runtime').start(e,menu)
local api,vr,hook=uevr.api,uevr.params.vr,uevr.types.UObjectHook
local Catalog=require('weapon_catalog')
local ids={'LeftArm','RightArm','Chainsword'};for _,id in ipairs(Catalog.ids)do ids[#ids+1]=id end
local selected_gun
local function gun_component(models)return selected_gun and models[selected_gun]:component()end
local Visibility=require('viewmodel_visibility')
local planes=Visibility.new(e)
local Cursor=require('cursor_mode')
local cursor=Cursor.new(e)
local melee=require('live_melee').new(e)
local freeaim=require('live_freeaim').new(e)
local grenade=require('live_grenade').new(e)
local hand_allowed=false
local rendered=require('render_pose_cache').new(e)
local near=require('near_face_guard').new()
local reticle=require('world_reticle').new(e)
local crosshair=require('original_crosshair').new(e)
local melee_allowed,melee_sample=false,nil
local aim_allowed=false
local visibility_pawn,visibility_nonce,desired_visibility=nil,nil,false
local models={};for _,id in ipairs(ids)do models[id]=Component.new(e,id)end
local frames,last_report=0,-1
local stopped=false
local lease
local function valid(o)return o~=nil and hook.exists(o)end
local function prop(o,key)
 if not valid(o)then return nil end
 local c=o:get_class();if not valid(c) or not c:find_property(key)then return nil end
 return o:get_property(key)
end
local function restore_lerp()
 if lease then
  if vr:get_mod_value('UObjectHook_AttachLerpEnabled')==lease.applied then
   vr.set_mod_value('UObjectHook_AttachLerpEnabled',lease.original)
   assert(vr:get_mod_value('UObjectHook_AttachLerpEnabled')==lease.original,'Attach restore failed')
  end
  lease=nil;json.dump_file('boltgun-model-lease-v1.json',{},-1)
 end
end
local old=json.load_file('boltgun-model-lease-v1.json')
if type(old)=='table' and type(old.original)=='string' and old.applied=='false'then lease=old;restore_lerp()end
local function direct_tracking()
 local value=vr:get_mod_value('UObjectHook_AttachLerpEnabled')
 if lease then assert(value==lease.applied,'Attachment changed externally');return end
 assert(value=='true' or value=='false','Attach parameter unavailable')
 lease={original=value,applied='false'}
 json.dump_file('boltgun-model-lease-v1.json',lease,-1)
 vr.set_mod_value('UObjectHook_AttachLerpEnabled','false')
 assert(vr:get_mod_value('UObjectHook_AttachLerpEnabled')=='false','Attach readback failed')
end
local function equipped_gun(pawn)
 local handler=prop(pawn,'WeaponHandlerComponent');local weapon=prop(handler,'EquippedWeapon')
 return valid(handler)and handler:get_outer()==pawn and valid(weapon)and Catalog.id(weapon)or nil
end
local function sword_visible(pawn)
 local handler=prop(pawn,'WeaponHandlerComponent');local weapon=prop(handler,'EquippedMeleeWeapon')
 return valid(handler) and handler:get_outer()==pawn and valid(weapon)
  and weapon:get_full_name():find('BP_Chainsword_C ',1,true)~=nil
end
local function disable(pawn,sample,retain)
 for _,id in ipairs(ids)do models[id]:step(pawn,nil,sample and sample.process_nonce,false,retain)end
 restore_lerp()
end
local function tick()
 melee_allowed=false;melee_sample=nil;aim_allowed=false;selected_gun=nil;hand_allowed=false
 desired_visibility=false
 local now=os.clock();local state=menu.inspect();local track=state.tracking;local sample=track and track.sample
 local pawn=api:get_local_pawn(0)
 visibility_pawn=pawn;visibility_nonce=sample and sample.process_nonce or visibility_nonce or control_files.read('labvisuals.session_nonce')
 local enabled=not stopped and control_files.read('labvisuals.mode')=='preview' and menu.clock_verified and not menu.stopped
  and state.context and state.context.mode=='gameplay' and track and track.good and now>=track.at and now-track.at<=.075
  and sample and sample.observer_revision==2 and sample.aims and vr.is_hmd_active()
  and not uevr.params.functions.is_drawing_ui()
 frames=frames+1
 if enabled and frames>2 then
  direct_tracking()
  local left={grip=sample.hands.left,aim=sample.aims.left,head=sample.head}
  local right={grip=sample.hands.right,aim=sample.aims.right,head=sample.head}
  local lg=Pose.offset(left.grip,left.aim,true)~=nil;local rg=Pose.offset(right.grip,right.aim,true)~=nil
  local clear={};for _,id in ipairs(ids)do clear[id]=near:allow(id,sample)end
  models.LeftArm:step(pawn,left,sample.process_nonce,lg and clear.LeftArm,true)
  models.RightArm:step(pawn,right,sample.process_nonce,rg and clear.RightArm,true)
  selected_gun=equipped_gun(pawn)
  for _,id in ipairs(Catalog.ids)do models[id]:step(pawn,right,sample.process_nonce,rg and clear[id] and selected_gun==id,true)end
  models.Chainsword:step(pawn,left,sample.process_nonce,lg and clear.Chainsword and sword_visible(pawn),true)
  hand_allowed=rg and clear.RightArm and not controls.menu
  melee_allowed=lg and clear.Chainsword and not controls.menu;melee_sample=sample;aim_allowed=rg and selected_gun~=nil and clear[selected_gun] and not controls.menu
 else disable(pawn,sample,not stopped and control_files.read('labvisuals.mode')=='preview' and state.context and state.context.mode=='gameplay')end
 reticle:prepare(pawn,visibility_nonce,aim_allowed and equipped_gun(pawn)~=nil and not cursor.paused and not stopped)
 -- Renew from the current validated tracking sequence before native weapon Fire.
 -- The post-tick call remains for revocation; duplicate sequences never renew.
 freeaim:step(melee_sample,gun_component(models),aim_allowed and not cursor.paused and not stopped)
 if now-last_report>=1 then
  last_report=now
  local result={version='BOLT-CONTROLLER-CAMPAIGN-01',at=now,mode=menu.mode,clock_verified=menu.clock_verified,menu_errors=menu.errors,
   menu_accepted=menu.accepted,menu_loading_confirm=menu.loading_confirm,stopped=stopped,enabled=enabled==true,tracking=sample,models={},manual_ui_accepted=false,agent_visual_preview=control_files.read('labvisuals.inspect_all')=='agent-only'}
  for _,id in ipairs(ids)do
   local m=models[id];result.models[id]=m:inspect()
  end
  local weapon=prop(prop(pawn,'WeaponHandlerComponent'),'EquippedWeapon')
  result.menu_diagnostics={stopped=menu.stopped,reason=menu.reason,last_error=menu.last_error,clock_verified=menu.clock_verified,tracking=state.tracking};result.controls=controls:inspect();result.original_planes={hidden=planes.active,errors=planes.errors,stopped=planes.stopped,error=planes.error}
  result.cursor={changes=cursor.changes,stopped=cursor.stopped,error=cursor.error,paused=cursor.paused}
  result.original_crosshair=crosshair:inspect();result.reticle=reticle:inspect();result.near_face=near:inspect();result.freeaim=freeaim:inspect();result.grenade=grenade:inspect();result.melee=melee:inspect();result.render_pose=rendered:inspect()
  result.weapon=valid(weapon) and weapon:get_full_name() or nil
  result.view={follow=vr:get_mod_value('UI_FollowView'),distance=vr:get_mod_value('UI_Distance'),size=vr:get_mod_value('UI_Size'),lerp=vr:get_mod_value('UObjectHook_AttachLerpEnabled')}
  json.dump_file('boltgun-combined-status.json',result,-1)
 end
end
uevr.sdk.callbacks.on_pre_engine_tick(function()
 local ok,err=pcall(tick)
 if not ok then
  stopped=true;pcall(restore_lerp)
  uevr.params.functions.log_info('[Boltgun combined] stopped: '..tostring(err))
 end
end)
uevr.sdk.callbacks.on_post_engine_tick(function()
 -- Independently evaluate visual ownership even when tracking/model callbacks fail.
 local pawn=api:get_local_pawn(0)
 local owned=control_files.read('labvisuals.mode')=='preview' and valid(pawn)
  and pawn:get_full_name():match('^BP_PlayerCharacter_Sternguard_C /Game/Maps/[^ ]+%.PersistentLevel%.BP_PlayerCharacter_Sternguard_C_%d+$')~=nil
 planes:step(pawn,visibility_nonce or control_files.read('labvisuals.session_nonce'),owned)
 cursor:step(control_files.read('labvisuals.mode')=='preview')
 crosshair:step(api:get_player_controller(0),owned and equipped_gun(pawn)~=nil)
 freeaim:step(melee_sample,gun_component(models),aim_allowed and not cursor.paused and not stopped)
 grenade:step(melee_sample,models.RightArm:component(),hand_allowed and not cursor.paused and not stopped)
 local component=models.Chainsword:component()
 local allowed=melee_allowed and not cursor.paused and control_files.read('labcombat.mode')=='live'
 local sample,world=rendered:take(melee_sample,component,allowed,os.clock())
 melee:step(sample,component,allowed and sample~=nil,world)
end)
uevr.sdk.callbacks.on_post_calculate_stereo_view_offset(function(device,index,world_to_meters,view_location)
 reticle:capture(melee_sample,gun_component(models),aim_allowed and not cursor.paused and not stopped,index,view_location)
 -- Only snapshot here; native damage stays on the engine callback.
 rendered:capture(melee_sample,models.Chainsword:component(),melee_allowed and not stopped,os.clock(),index)
end)
uevr.sdk.callbacks.on_script_reset(function()
 stopped=true;crosshair:stop();reticle:stop();planes:stop();cursor:stop();melee:stop();freeaim:stop();grenade:stop();rendered:stop();for _,m in pairs(models)do m:stop()end;pcall(restore_lerp)
end)
uevr.params.functions.log_info('[BOLT-CONTROLLER-CAMPAIGN-01] loaded; waiting for verified tracking')
