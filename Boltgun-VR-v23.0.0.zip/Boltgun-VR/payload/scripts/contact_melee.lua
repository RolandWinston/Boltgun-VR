-- Actual displayed blade sweeps with per-target contact cooldown requested by the user.
-- Reuses the production UE collision and native damage adapters. No speed trigger.
local Sweep=require('blade_sweep');local M={}
function M.new(query,damage,opt)
 local s={id=0,active=false,events={},samples=0,cooldown=.5};local previous,now,last_clock;local last_hit={}
 local b=Sweep.new(query,function(id,h)
  local last=last_hit[h.key]
  if last and now-last<.5 then return false,'contact-cooldown' end
  local ok,result=damage:apply(id,h.hit or h)
  if ok then last_hit[h.key]=now end
  return ok,result
 end,opt);s.blade=b
 function s:reset()previous=nil;self.active=false;b:finish();damage:finish()end
 function s:step(world,dt,clock,valid)
  if not valid or not Sweep.valid(world)or type(clock)~='number'or clock~=clock or(last_clock and clock<last_clock)then self:reset();return{}end
  last_clock=clock;now=clock
  if type(dt)~='number'or dt<=0 or dt>.1 then self:reset();return{}end
  self.id=self.id+1;self.samples=self.samples+1;self.active=true
  assert(damage:begin(self.id),'Native contact identity rejected')
  assert(b:begin(self.id,previous or world),'Blade contact identity rejected')
  local hits=b:step(world,dt,true)
  previous=b.rejection and nil or world
  for _,h in ipairs(hits)do
   if h.ok then h.at=clock;self.events[#self.events+1]=h;if #self.events>32 then table.remove(self.events,1)end end
  end
  b:finish();damage:finish()
  -- Bounded retention for long levels; removed actors naturally age out.
  for key,t in pairs(last_hit)do if clock-t>10 then last_hit[key]=nil end end
  return hits
 end
 return s
end
return M
