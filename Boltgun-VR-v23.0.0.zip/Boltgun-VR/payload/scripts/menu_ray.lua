-- Ray vs the same world-space quad defined by pinned UEVR OverlayComponent.
local M={}
local function mul(a,b)return{x=a.w*b.x+a.x*b.w+a.y*b.z-a.z*b.y,y=a.w*b.y-a.x*b.z+a.y*b.w+a.z*b.x,z=a.w*b.z+a.x*b.y-a.y*b.x+a.z*b.w,w=a.w*b.w-a.x*b.x-a.y*b.y-a.z*b.z}end
local function inv(q)return{x=-q.x,y=-q.y,z=-q.z,w=q.w}end
local function rotate(q,p)local r=mul(mul(q,{x=p.x,y=p.y,z=p.z,w=0}),inv(q));return{x=r.x,y=r.y,z=r.z}end
function M.intersect(ray,panel)
 if not ray or not ray.active or not ray.tracked or not panel or panel.width<=0 or panel.height<=0 then return nil end
 local o=rotate(inv(panel.rotation),{x=ray.position.x-panel.center.x,y=ray.position.y-panel.center.y,z=ray.position.z-panel.center.z})
 local d=rotate(inv(panel.rotation),rotate(ray.rotation,{x=0,y=0,z=-1}))
 if math.abs(d.z)<1e-6 then return nil end
 local t=-o.z/d.z;if t<=0 or t>20 then return nil end
 local x,y=o.x+d.x*t,o.y+d.y*t
 local u,v=.5+x/panel.width,.5-y/panel.height
 if u<0 or u>1 or v<0 or v>1 then return nil end
 return {x=u,y=v,distance=t}
end
function M.panel(vr)
 local p=UEVR_Vector3f.new();local q=UEVR_Quaternionf.new();vr.get_standing_origin(p);vr.get_rotation_offset(q)
 local r={x=-q.x,y=-q.y,z=-q.z,w=q.w};local size=tonumber(vr:get_mod_value('UI_Size'));local distance=tonumber(vr:get_mod_value('UI_Distance'))
 local v=rotate(r,{x=tonumber(vr:get_mod_value('UI_X_Offset')),y=tonumber(vr:get_mod_value('UI_Y_Offset')),z=-distance})
 local width,height=vr.get_ui_width(),vr.get_ui_height();if width<=0 or height<=0 then return nil end
 return {center={x=p.x+v.x,y=p.y+v.y,z=p.z+v.z},rotation=r,width=size*width/height,height=size}
end
return M
