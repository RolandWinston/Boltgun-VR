-- Derived from rubocopter/boltgun-vr c74df9a97f45, GPL-3.0-or-later.
-- Generalized existing procedural-mesh ownership/material/rollback path for Lab assets.
local Pose=require('controller_pose')
local Grip=require('grip_anchor')
local IdleGrip=require('tracked_grip_attachment')
local M={}
local CLASS='Class /Script/ProceduralMeshComponent.ProceduralMeshComponent'
local PLANE_CLASS='Class /Script/Engine.StaticMeshComponent'
local MATERIAL='MaterialInstanceConstant /Game/Art/Pickups/Powerups/Materials/MI_Pickups_Boltgun.MI_Pickups_Boltgun'
local specs={LeftArm={hand=0,grip=true},RightArm={hand=1,grip=true},Bolter={hand=1,grip=true},Chainsword={hand=0,grip=true},Reticle={world=true}}
function M.new(e,id)
 local opt=assert(specs[id]or(require('weapon_catalog').is_gun(id)and{hand=1,grip=true}),'Unknown Lab asset')
 local api,hook=e.uevr.api,e.uevr.types.UObjectHook
 local fs=e.fs
 local owner,part,owner_id,part_id,sprite,process,engine_id
 local journal='labvisuals.'..id..'.owned'
 local ctrl={asset=id,errors=0,stopped=false,ready=false,restored=false}
 local recovered=false
 local function report(s)e.uevr.params.functions.log_info('[Boltgun Lab '..id..'] '..s)end
 local function valid(o)return o~=nil and hook.exists(o)end
 local function identity(o)
  assert(valid(o),'Object unavailable')
  return {name=o:get_full_name(),address=tostring(o:get_address()),class=o:get_class():get_full_name()}
 end
 local function same(o,i)return valid(o) and i and o:get_full_name()==i.name and tostring(o:get_address())==i.address and o:get_class():get_full_name()==i.class end
 local function reference(o,key)
  if not valid(o)then return nil end
  local c=o:get_class();if not valid(c) or not c:find_property(key)then return nil end
  return o:get_property(key)
 end
 local function write(text)
  fs.write(journal,text);assert(fs.read(journal)==text,'Ownership journal unavailable')
 end
 local function snapshot(pawn)
  if not opt.sprite then return nil end
  local renderer=reference(pawn,'WeaponRenderer')
  assert(valid(renderer) and renderer:get_outer()==pawn,'Renderer owner unavailable')
  local plane=reference(renderer,opt.sprite)
  assert(valid(plane) and plane:get_outer()==renderer and plane:get_class():get_full_name()==PLANE_CLASS and plane:get_short_name()==opt.short,'Sprite identity unavailable')
  local hidden,visible=reference(plane,'bHiddenInGame'),reference(plane,'bVisible')
  assert(type(hidden)=='boolean' and type(visible)=='boolean','Sprite visibility unavailable')
  return {plane=plane,renderer=renderer,plane_id=identity(plane),renderer_id=identity(renderer),hidden=hidden,visible=visible}
 end
 local function sprite_current()
  return sprite and same(owner,owner_id) and same(sprite.plane,sprite.plane_id) and same(sprite.renderer,sprite.renderer_id)
   and reference(owner,'WeaponRenderer')==sprite.renderer and reference(sprite.renderer,opt.sprite)==sprite.plane
   and sprite.renderer:get_outer()==owner and sprite.plane:get_outer()==sprite.renderer
 end
 local function restore_sprite()
  if sprite_current() and reference(sprite.plane,'bHiddenInGame')==true and reference(sprite.plane,'bVisible')==false then
   sprite.plane:SetHiddenInGame(sprite.hidden,false);sprite.plane:SetVisibility(sprite.visible,false)
  end
 end
 local function remember()
  local fields={'v1',process,engine_id,owner_id.address,owner_id.name,owner_id.class,part_id.address,part_id.name,part_id.class}
  if sprite then
   for _,v in ipairs({sprite.plane_id.address,sprite.plane_id.name,sprite.renderer_id.address,sprite.renderer_id.name,tostring(sprite.hidden),tostring(sprite.visible)})do fields[#fields+1]=v end
  end
  for _,v in ipairs(fields)do assert(type(v)=='string' and not v:find('[\r\n]'),'Invalid journal value')end
  write(table.concat(fields,'\n'))
 end
 local function cleanup()
  -- Compare both actor and component identities before touching stored wrappers.
  local replaced=valid(owner) and not same(owner,owner_id)
  local foreign=false
  if not replaced and same(part,part_id)then
   local outer=part:get_outer()
   if outer==owner or not valid(outer)then
    part:SetHiddenInGame(true,false);part:SetVisibility(false,false);hook.remove_motion_controller_state(part)
   else foreign=true end
  end
  if not replaced then restore_sprite()end
  if not replaced and same(owner,owner_id) and same(part,part_id) and part:get_outer()==owner then part:K2_DestroyComponent(owner)end
  if replaced or foreign then
   local text=fs.read(journal);fs.write(journal..'.retired',text);assert(fs.read(journal..'.retired')==text,'Retired ownership unavailable')
   report('Previous ownership retained for inspection; foreign objects left intact')
  end
  owner,part,owner_id,part_id,sprite=nil,nil,nil,nil,nil
  ctrl.ready=false;ctrl.restored=true;write('')
 end
 local function recover(nonce)
  local text=fs.read(journal)
  if text=='' then recovered=true;return end
  local f={};for v in text:gmatch('[^\r\n]+')do f[#f+1]=v end
  assert((#f==9 or #f==15) and f[1]=='v1','Invalid ownership record')
  if f[2]~=nonce then write('');recovered=true;return end
  local engine=api:get_engine();if not valid(engine)then return end
  if tostring(engine:get_address())~=f[3]then write('');recovered=true;return end
  owner=api:find_uobject(f[5]);owner_id={address=f[4],name=f[5],class=f[6]}
  if not valid(owner)then write('');owner=nil;recovered=true;return end
  assert(same(owner,owner_id),'Recovery actor identity changed')
  part=api:find_uobject(f[8]);part_id={address=f[7],name=f[8],class=f[9]}
  assert(f[9]==CLASS,'Unexpected recovery component class')
  if valid(part)then assert(same(part,part_id) and part:get_outer()==owner,'Recovery component identity changed')end
  if #f==15 then
   assert(opt.sprite and (f[14]=='true' or f[14]=='false') and (f[15]=='true' or f[15]=='false'),'Invalid recovery sprite')
   sprite=snapshot(owner)
   assert(sprite.plane_id.address==f[10] and sprite.plane_id.name==f[11] and sprite.renderer_id.address==f[12] and sprite.renderer_id.name==f[13],'Recovery sprite identity changed')
   sprite.hidden,sprite.visible=f[14]=='true',f[15]=='true'
  end
  cleanup();recovered=true
 end
local function load_material()
    local profile = {id="chainsword material",mesh=MATERIAL}
    local ok, result, reason = pcall(function()
        local class = api:find_uobject('Class /Script/AssetRegistry.AssetRegistryHelpers')
        local strings_class = api:find_uobject('Class /Script/Engine.KismetStringLibrary')
        local descriptor = api:find_uobject('ScriptStruct /Script/CoreUObject.AssetData')
        if not valid(class) or not valid(strings_class) or not valid(descriptor) then
            return nil, 'AssetRegistryHelpers, KismetStringLibrary or AssetData unavailable'
        end
        -- find_uobject auto-casts UClass only. ScriptStruct descriptors arrive
        -- as generic UObjects, which do not expose find_property in Lua.
        local desc = descriptor:as_struct()
        if not valid(desc) then return nil, 'AssetData descriptor could not be cast to UStruct' end
        if class:find_function('GetAsset') == nil or class:find_function('IsValid') == nil or
            strings_class:find_function('Conv_StringToName') == nil then
            return nil, 'AssetRegistry/FName functions unavailable'
        end
        -- Restrict this loader to the reflected UE4 AssetData layout. Do not
        -- guess offsets or synthesize UE5 AssetClassPath fields.
        local fields = {'ObjectPath','PackageName','PackagePath','AssetName','AssetClass'}
        for _, field in ipairs(fields) do
            if desc:find_property(field) == nil then
                return nil, 'UE4 AssetData field unavailable: ' .. field
            end
        end
        if StructObject == nil then return nil, 'StructObject API unavailable' end
        local helpers = class:get_class_default_object()
        local strings = strings_class:get_class_default_object()
        if not valid(helpers) or not valid(strings) then return nil, 'AssetRegistry/FName default object unavailable' end
        local path = profile.mesh:match('^MaterialInstanceConstant (.+)$')
        local package, name = path:match('^(.+)%.([^%.]+)$')
        assert(package ~= nil and name ~= nil, 'Invalid fixed mesh path')
        local data = StructObject.new(desc)
        assert(data ~= nil, 'AssetData allocation unavailable')
        local values = {ObjectPath=path,PackageName=package,
            PackagePath=package:match('^(.+)/[^/]+$'),AssetName=name,AssetClass='MaterialInstanceConstant'}
        -- Only FNames are populated. No dynamic strings, tags or asset arrays
        -- are shallow-copied between Lua and Unreal allocators.
        for _, field in ipairs(fields) do
            local fname = strings:Conv_StringToName(values[field])
            assert(fname ~= nil, 'FName conversion failed: ' .. field)
            data:set_property(field, fname)
        end
        if not helpers:IsValid(data) then return nil, 'AssetRegistry rejected AssetData' end
        report('AssetRegistry GetAsset requested: ' .. profile.id)
        local loaded = helpers:GetAsset(data)
        if not valid(loaded) then return nil, 'AssetRegistry GetAsset returned no mesh' end
        if loaded:get_full_name() ~= profile.mesh then
            return nil, 'Loader returned an unexpected object'
        end
        return loaded
    end)
    if not ok then
        report('Original mesh load raised a Lua/API error: ' .. tostring(result))
        return nil
    end
    if not valid(result) then
        report('Original mesh load unavailable: ' .. tostring(reason))
        return nil
    end
    report('Original mesh loaded via AssetRegistry GetAsset: ' .. profile.id)
    return result
end


 local function fname(value)
  local c=api:find_uobject('Class /Script/Engine.KismetStringLibrary')
  assert(valid(c) and c:find_function('Conv_StringToName'),'FName library unavailable')
  return assert(c:get_class_default_object():Conv_StringToName(value),'FName conversion unavailable')
 end
 local function texture_path()
  local p=fs.read('labvisuals.texture_path');assert(type(p)=='string','Native atlas hint unavailable')
  p=p:gsub('\\','/')
  assert(p:match('^%a:/') and p:sub(-#'/data/labvisuals/lab-visual-atlas.png')=='/data/labvisuals/lab-visual-atlas.png' and not p:find('[\r\n]'),'Native atlas path mismatch')
  return p
 end
 local function attach(pose)
  if opt.world then return end
  local q=assert(Pose.offset(pose.grip,pose.aim,opt.grip),'Grip/aim pose unavailable')
  local state=assert(hook.get_or_add_motion_controller_state(part),'Controller attachment unavailable')
  local p=Grip.offset(id);local offset=UEVR_Vector3f.new();offset.x,offset.y,offset.z=p.x,p.y,p.z
  local rotation=UEVR_Quaternionf.new();rotation.x,rotation.y,rotation.z,rotation.w=q.x,q.y,q.z,q.w
  local hand=opt.hand
  if not e.uevr.params.vr.is_using_controllers()then
   local idle=assert(IdleGrip.offset(id,pose,opt.grip,tonumber(e.uevr.params.vr:get_mod_value('VR_WorldScale')),e.uevr.params.vr:get_mod_value('VR_DecoupledPitch')=='true'),'Tracked idle grip unavailable')
   hand=idle.hand;offset.x,offset.y,offset.z=idle.position.x,idle.position.y,idle.position.z
   rotation.x,rotation.y,rotation.z,rotation.w=idle.rotation.x,idle.rotation.y,idle.rotation.z,idle.rotation.w
  end
  state:set_hand(hand);state:set_permanent(false);state:set_location_offset(offset);state:set_rotation_offset(rotation)
 end
 local function create(pawn,pose,nonce)
  local class=api:find_uobject(CLASS);assert(valid(class),'Procedural mesh class unavailable')
  for _,n in ipairs({'SetHiddenInGame','SetVisibility','SetCollisionEnabled','SetGenerateOverlapEvents','SetMobility','SetCastShadow','SetOwnerNoSee','SetOnlyOwnerSee','CreateDynamicMaterialInstance','SetRelativeScale3D','K2_DestroyComponent','GetNumSections','GetMaterial'})do assert(class:find_function(n),'Required function unavailable: '..n)end
  owner=pawn;owner_id=identity(pawn);process=nonce;engine_id=tostring(api:get_engine():get_address());sprite=snapshot(pawn)
  part=api:add_component_by_class(pawn,class,false)
  assert(valid(part) and part:get_outer()==pawn and part:get_class():get_full_name()==CLASS,'New component ownership failed')
  part_id=identity(part)
  part:SetHiddenInGame(true,false);part:SetVisibility(false,false)
  part:SetCollisionEnabled(0);part:SetGenerateOverlapEvents(false);part:SetMobility(2);part:SetCastShadow(false)
  part:SetOwnerNoSee(false);part:SetOnlyOwnerSee(false);part:SetRelativeScale3D({X=1,Y=1,Z=1})
  remember();assert(part:GetNumSections()==0,'New component has geometry already')
  local dispatch=assert(e.uevr.params.functions.dispatch_custom_event,'Geometry event API unavailable')
  dispatch('boltgun.labvisual.v1',id..'|'..tostring(pawn:get_address())..'|'..tostring(part:get_address()))
  assert(part:GetNumSections()==1,'Geometry bridge unavailable')
  local material=api:find_uobject(MATERIAL);if not valid(material)then material=load_material()end
  assert(valid(material) and material:get_full_name()==MATERIAL,'Original unlit material unavailable')
  local rc=api:find_uobject('Class /Script/Engine.KismetRenderingLibrary')
  assert(valid(rc) and rc:find_function('ImportFileAsTexture2D'),'Texture import unavailable')
  local texture=rc:get_class_default_object():ImportFileAsTexture2D(pawn,texture_path());assert(valid(texture),'Atlas import failed')
  local dmi=part:CreateDynamicMaterialInstance(0,material,fname('BoltgunLab'..id));assert(valid(dmi),'Dynamic material unavailable')
  dmi:SetTextureParameterValue(fname('BC'),texture)
  assert(dmi:K2_GetTextureParameterValue(fname('BC'))==texture and part:GetMaterial(0)==dmi,'Atlas material readback failed')
  attach(pose);ctrl.ready=true;ctrl.restored=false
 end
 local function step(pawn,pose,nonce,enabled,retain)
  if type(nonce)~='string' or not nonce:match('^%d+:%d+$')then if not enabled and process then nonce=process else return end end
  if not recovered then recover(nonce);if not recovered then return end end
  if part and (not valid(pawn) or pawn~=owner or process~=nonce or not same(owner,owner_id) or not same(part,part_id) or part:get_outer()~=owner or (opt.sprite and not sprite_current()))then cleanup()end
  if not enabled then
   if part then
    if retain and same(part,part_id) and same(owner,owner_id) and part:get_outer()==owner then
     -- Tracking gaps disable rendering and attachment immediately, retaining expensive geometry/materials.
     if ctrl.ready then part:SetHiddenInGame(true,false);part:SetVisibility(false,false);hook.remove_motion_controller_state(part)end
     ctrl.ready=false;ctrl.suspended=true
    else cleanup();ctrl.suspended=false end
   end
   return
  end
  if not valid(pawn)then return end
  if not opt.world then assert(Pose.offset(pose and pose.grip,pose and pose.aim,opt.grip),'Tracked pose required')end
  if not part then create(pawn,pose,nonce)end
  attach(pose)
  if sprite then
   assert(sprite_current(),'Sprite changed during update')
   sprite.plane:SetHiddenInGame(true,false);sprite.plane:SetVisibility(false,false)
  end
  part:SetHiddenInGame(false,false);part:SetVisibility(true,false);ctrl.ready=true;ctrl.suspended=false
 end
 function ctrl:step(pawn,pose,nonce,enabled,retain)
  if self.stopped then return end
  local ok,err=pcall(step,pawn,pose,nonce,enabled,retain)
  if not ok then
   self.errors=self.errors+1;self.last_error=tostring(err)
   if recovered then
    local cleaned,why=pcall(cleanup);if not cleaned then self.cleanup_error=tostring(why)end
   end
   report('Candidate stopped after API error: '..self.last_error)
   self.stopped=true
  end
 end
 function ctrl:component()
  if self.ready and not self.stopped and same(part,part_id) and same(owner,owner_id) and part:get_outer()==owner then return part end
 end
 function ctrl:place_world(point,rotation,scale)
  assert(opt.world,'World placement is restricted to the reticle')
  local c=self:component();if not c then return false end
  assert(type(scale)=='number'and scale==scale and scale>=.1 and scale<=20,'Reticle scale outside bounds')
  c:K2_SetWorldLocation({X=point.x,Y=point.y,Z=point.z},false,{},false)
  c:K2_SetWorldRotation({Pitch=rotation.pitch,Yaw=rotation.yaw,Roll=0},false,{},false)
  c:SetWorldScale3D({X=scale,Y=scale,Z=scale})
  return true
 end
 function ctrl:inspect()
  local r={ready=self.ready,suspended=self.suspended,errors=self.errors,stopped=self.stopped,error=self.last_error,cleanup_error=self.cleanup_error}
  if same(part,part_id)then
   local p=part:K2_GetComponentLocation();local q=part:K2_GetComponentRotation()
   r.object=part_id.name;r.location={x=p.X,y=p.Y,z=p.Z};r.rotation={pitch=q.Pitch,yaw=q.Yaw,roll=q.Roll}
   r.hidden=reference(part,'bHiddenInGame');r.visible=reference(part,'bVisible')
  end
  return r
 end
 function ctrl:stop()self.stopped=true end -- Reset thread never calls Unreal; next instance recovers on tick.
 return ctrl
end
return M
