-- Native Boltgun contact -> original chainsword damage. Call only on engine thread.
-- Uses reflected functions from the pinned game; never writes enemy health/death.
local M={}
function M.new(uevr)
 local api=uevr.api
 local gs=api:find_uobject('Class /Script/Engine.GameplayStatics'):get_class_default_object()
 local unpackHit=gs:get_class():find_function('BreakHitResult')
 local enemyClass=api:find_uobject('Class /Script/Boltgun.BGNonPlayableCharacterBase')
 local swing,last_id,seen=0,0,{}
 local state={calls=0,hits=0}
 function state:begin(id)
  if type(id)~='number'or id<=last_id or id%1~=0 then return false end
  swing=id;last_id=id;seen={};return true
 end
 function state:apply(id,hit)
  if id~=swing or swing==0 then return false,'inactive-swing'end
  if not hit or hit.bBlockingHit~=true then return false,'no-contact'end
  local args,outputs={},{};local f=unpackHit:get_child_properties()
  while f do
   local key=f:get_fname():to_string();local p=unpackHit:find_property(key)
   if p and p:is_param()and not p:is_return_param()then
    if key=='Hit'then args[#args+1]=hit else assert(p:is_out_param(),'Unexpected BreakHitResult input');local t={};args[#args+1]=t;outputs[key]=t end
   end
   f=f:get_next()
  end
  unpackHit(gs,table.unpack(args))
  local target=outputs.HitActor and outputs.HitActor.result
  if not target or not uevr.types.UObjectHook.exists(target)or not target:is_a(enemyClass)then return false,'not-enemy'end
  local identity=target:get_full_name()..':'..tostring(target:get_address())
  if seen[identity]then return false,'duplicate'end
  if target:IsDead()then return false,'dead'end
  local pawn=api:get_local_pawn(0);local wh=pawn and pawn:get_property('WeaponHandlerComponent')
  local weapon=wh and wh:get_property('EquippedMeleeWeapon')
  if not weapon or not weapon:get_full_name():find('BP_Chainsword_C ',1,true)or wh:get_outer()~=pawn or not uevr.types.UObjectHook.exists(weapon) then return false,'weapon-not-ready'end
  local tp=weapon:get_class():find_property('ChainswordCuttingTarget')
  assert(tp and tp:get_class():get_name()=='ObjectProperty','Unsupported target property')
  local oldTarget=weapon:get_property('ChainswordCuttingTarget');local oldHit=weapon:get_property('ChainswordHit')
  local size=oldHit:get_struct():get_properties_size();assert(size>0 and size<=256,'Unsupported hit structure')
  local saved=StructObject.new(oldHit:get_struct());for i=0,size-1 do saved:write_byte(i,oldHit:read_byte(i))end
  local original=weapon:get_property('CuttingDamage');local strike=weapon:get_property('StrikeDamage')
  assert(type(strike)=='number'and strike>0 and strike<=original,'Unsupported native strike damage')
  local before=target:get_property('CurrentHealth')
  seen[identity]=true;self.calls=self.calls+1
  local ok,err=pcall(function()
   weapon.ChainswordHit=hit;weapon.ChainswordCuttingTarget=target;weapon.CuttingDamage=strike
   assert(weapon:get_property('ChainswordCuttingTarget')==target,'Target assignment failed')
   weapon:DealCuttingDamage()
  end)
  weapon.CuttingDamage=original;weapon.ChainswordCuttingTarget=oldTarget;weapon.ChainswordHit=saved
  if not ok then return false,tostring(err)end
  local after=target:get_property('CurrentHealth');local changed=type(after)=='number'and after<before
  if changed then self.hits=self.hits+1 end
  return changed,{target=target:get_full_name(),before=before,after=after,dead=target:IsDead(),native_strike_damage=strike,swing=swing}
 end
 function state:finish()seen={};swing=0 end
 return state
end
return M
