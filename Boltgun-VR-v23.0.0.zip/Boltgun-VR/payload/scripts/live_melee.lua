-- Production tracking and owned display-pose gate. External XR replay is labeled separately; no internal damage-test bypass.
local Query=require('native_blade_query');local Damage=require('native_melee_damage');local Pipeline=require('contact_melee')
local Landmarks=require('weapon_landmarks')
local M={}
function M.new(e)
 local api=e.uevr.api;local q,damage,pipe;local seq,stamp,epoch,nonce,owner
 local s={stopped=false,frames=0,invalidations=0,source='actual-tracking-and-owned-component'}
 local function reset()
  if pipe then pipe:reset()end;seq=nil;stamp=nil;epoch=nil;nonce=nil;owner=nil
  s.invalidations=s.invalidations+1
 end
 local function step(sample,component,enabled,rendered_world)
  if not enabled or type(sample)~='table'or not component or not sample.fresh or not sample.focused or not sample.foreground then reset();return end
  local hand=sample.hands and sample.hands.left
  if not hand or not hand.tracked or not hand.active or type(sample.clock_qpc)~='number'or type(sample.sequence)~='number'then reset();return end
  if not q then q=Query.new(e.uevr);damage=Damage.new(e.uevr);pipe=Pipeline.new(function(a,b,r)return q:cast(a,b,r)end,damage,{base=Landmarks.blade_base,tip=Landmarks.blade_tip,radius=Landmarks.blade_radius})end
  local weapon,pawn=q:weapon();if not weapon or pawn:get_property('bPlayerFinishedLevelLoad')~=true then reset();return end
  local busy=weapon:get_property('ChainswordCuttingTarget');if busy then reset();return end
  local identity=pawn:get_full_name()..':'..tostring(pawn:get_address())..':'..tostring(weapon:get_address())..':'..tostring(component:get_address())
  if nonce~=sample.process_nonce or epoch~=sample.epoch or owner~=identity then reset();nonce=sample.process_nonce;epoch=sample.epoch;owner=identity end
  if seq==sample.sequence then return end
  if seq and sample.sequence<seq then reset();return end
  local dt=stamp and sample.clock_qpc-stamp or 0;seq=sample.sequence;stamp=sample.clock_qpc
  if type(rendered_world)~='table'then reset();s.rejection='missing-rendered-world';return end
  local world=rendered_world;local player=pawn:K2_GetActorLocation()
  local dx,dy,dz=world.position.x-player.X,world.position.y-player.Y,world.position.z-player.Z
  if dx*dx+dy*dy+dz*dz>250*250 then reset();s.rejection='component-out-of-reach';return end
  if dt<=0 or dt>.1 then pipe:reset();return end
  pipe:step(world,dt,sample.clock_qpc,true)
  s.frames=s.frames+1;s.attack=pipe.id;s.active=pipe.active;s.blocked=pipe.blade.blocked
  s.contact_interval=.5;s.native_calls=damage.calls;s.native_hits=damage.hits
  s.queries=q.queries;s.events=pipe.events;s.world=world;s.sample_sequence=seq;s.sample_dt=dt
 end
 function s:step(sample,component,enabled,rendered_world)
  if self.stopped then return end
  local ok,err=pcall(step,sample,component,enabled,rendered_world)
  if not ok then self.stopped=true;self.error=tostring(err);pcall(reset);e.uevr.params.functions.log_info('[Boltgun live melee] stopped: '..self.error)end
 end
 function s:stop()self.stopped=true end
 function s:inspect()
  local r={};for _,k in ipairs({'stopped','error','frames','invalidations','source','rejection','attack','active','blocked','contact_interval','native_calls','native_hits','queries','events','world','sample_sequence','sample_dt'})do r[k]=self[k]end;return r
 end
 return s
end
return M
