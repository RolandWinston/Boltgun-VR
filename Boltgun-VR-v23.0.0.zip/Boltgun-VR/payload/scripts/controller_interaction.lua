-- Enlarge only native interaction search dimensions. Native hover, blockers, keys and B action remain authoritative.
local M={}
function M.new(e)
 local api,hook=e.uevr.api,e.uevr.types.UObjectHook
 local state={ready=false,errors=0};local pawn,initial,applied;local next_check=0
 local wanted={InteractRange=350,InteractRadius=150}
 local function valid(o)return o and hook.exists(o)end
 local function release()
  if valid(pawn)and initial then
   for k,v in pairs(initial)do if pawn:get_property(k)==applied[k]then pawn:set_property(k,v)end end
  end
  pawn,initial,applied=nil,nil,nil;state.ready=false
 end
 function state:step(now)
  if self.stopped or now<next_check then return end;next_check=now+.5
  local ok,why=pcall(function()
   local current=api:get_local_pawn(0)
   if current~=pawn then release()end
   if not valid(current)then return end
   local class=current:get_class()
   if not class:find_property('InteractRange')or not class:find_property('InteractRadius')then return end
   if not pawn then
    pawn=current;initial={};applied={}
    for k,v in pairs(wanted)do local old=pawn:get_property(k);assert(type(old)=='number'and old>0 and old<=2000,'Invalid native '..k);initial[k]=old;applied[k]=math.max(old,v)end
   end
   for k,v in pairs(applied)do if pawn:get_property(k)~=v then pawn:set_property(k,v)end;assert(pawn:get_property(k)==v,'Interaction readback '..k)end
   self.ready=true;self.range=applied.InteractRange;self.radius=applied.InteractRadius
  end)
  if not ok then self.error=tostring(why);self.errors=self.errors+1;self.ready=false;if self.errors>=3 then self.stopped=true end end
 end
 function state:restore()release();self.stopped=true end
 function state:inspect()return{ready=self.ready,errors=self.errors,error=self.error,range=self.range,radius=self.radius,stopped=self.stopped}end
 return state
end
return M
