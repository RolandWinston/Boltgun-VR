-- User-approved Quest controls. Pure policy consumed by the production runtime.
local M={}
local A,B,X,Y,LS,RS,LG,RG,BACK=0x1000,0x2000,0x4000,0x8000,0x40,0x80,0x100,0x200,0x20
local function has(bits,flag)return bits//flag%2==1 end
function M.new()
 local s={armed=true,previous=0,previous_rt=false,grip_used=false,block_fire=false,grenade_latched=false}
 function s:reset()self.armed=false;self.previous=0;self.previous_rt=false;self.grip_used=false;self.block_fire=false;self.grenade_latched=false end
 function s:step(i)
  local o={buttons=0,lt=0,rt=0,lx=0,ly=0,rx=0,ry=0,click=false,turn=0,cycle=false,grenade=false}
  if not i.valid then
   -- Brief game-frame staleness neutralizes output while retaining held-action state.
   -- Explicit loss, long gaps, and every menu gap still require release.
   if not(i.transient==true and i.menu==false)then self:reset()end
   return o
  end
  local menu=i.menu==true;local buttons=i.buttons or 0;local rt=(i.rt or 0)>127;local grip=has(buttons,RG)
  if not self.armed then
   if buttons==0 and not rt and(i.lt or 0)==0 and math.abs(i.lx or 0)<.15 and math.abs(i.ly or 0)<.15 and math.abs(i.rx or 0)<.15 then self.armed=true end
   return o
  end
  local confirm=menu and i.native_confirm==true
  local old=self.previous;local changed_context=self.context~=nil and(self.context~=menu or(self.confirm_context==true)~=confirm)
  if changed_context then self:reset();self.context=menu;self.confirm_context=confirm;return o end
  self.context=menu;self.confirm_context=confirm
  if menu then
   o.click=rt and not confirm
   if confirm and rt then o.buttons=A end
   if has(buttons,X)then o.buttons=X end
   -- The ray chooses the actual hovered widget; no abstract A/Enter shortcut.
  else
   for _,flag in ipairs({A,B,X,Y,RS,LG})do if has(buttons,flag)then o.buttons=o.buttons+flag end end
   o.lt=i.lt or 0;o.lx=i.lx or 0;o.ly=i.ly or 0
   -- Native Walk requests sprint. Ordinary movement leaves it released; L3 halves analog movement.
   if has(buttons,LS)then o.lx=o.lx*.5;o.ly=o.ly*.5 end
   local axis=i.rx or 0;o.turn=math.abs(axis)>.2 and ((math.abs(axis)-.2)/.8)*(axis<0 and -1 or 1) or 0
   if grip and rt then
    if not self.grenade_latched then o.buttons=o.buttons+RG;o.grenade=true end
    self.grenade_latched=true;self.grip_used=true;self.block_fire=true
   end
   if not rt then self.grenade_latched=false;self.block_fire=false end
   if has(old,RG)and not grip then
    if not self.grip_used and not rt then o.buttons=o.buttons+BACK;o.cycle=true end
    self.grip_used=false
   end
   if rt and not grip and not self.block_fire then o.rt=i.rt end
   -- All direct weapon slot/D-pad and unused look axes remain clear.
  end
  self.previous=buttons;self.previous_rt=rt
  return o
 end
 return s
end
return M
