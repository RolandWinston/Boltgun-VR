import importlib.util, json, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('launcher',ROOT/'launch.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
class SessionTests(unittest.TestCase):
 def exercise(self, existing):
  with tempfile.TemporaryDirectory() as tmp:
   r=Path(tmp);pkg=r/'pkg';(pkg/'payload/data').mkdir(parents=True);(pkg/'payload/data/new').write_bytes(b'new');(pkg/'game-config').mkdir();(pkg/'game-config/Input.ini').write_bytes(b'new-input')
   live=r/'profiles/game';inp=r/'saved/Input.ini'
   if existing:
    (live/'plugins').mkdir(parents=True);(live/'plugins/private.dll').write_bytes(b'original');inp.parent.mkdir();inp.write_bytes(b'old-input')
   s=mod.ProfileSession(live,inp,r/'session');s.install(pkg)
   self.assertEqual(inp.read_bytes(),b'new-input');self.assertFalse((live/'plugins/private.dll').exists())
   s.restore();self.assertEqual(live.exists(),existing);self.assertEqual(inp.exists(),existing)
   if existing:self.assertEqual((live/'plugins/private.dll').read_bytes(),b'original');self.assertEqual(inp.read_bytes(),b'old-input')
   self.assertEqual(json.loads((r/'session/transaction.json').read_text())['state'],'restored')
 def test_existing(self):self.exercise(True)
 def test_first_install(self):self.exercise(False)
 def test_partial_copy_failure(self):
  with tempfile.TemporaryDirectory() as tmp:
   r=Path(tmp);live=r/'profiles/game';live.mkdir(parents=True);(live/'old').write_bytes(b'keep');inp=r/'input';inp.write_bytes(b'old')
   s=mod.ProfileSession(live,inp,r/'session')
   with self.assertRaises(FileNotFoundError):s.install(r/'missing-package')
   s.restore();self.assertEqual((live/'old').read_bytes(),b'keep');self.assertEqual(inp.read_bytes(),b'old')
 def test_nonce_current_process(self):
  import os
  self.assertTrue(mod.process_nonce(os.getpid()).startswith(str(os.getpid())+':'))
if __name__=='__main__':unittest.main()
