#define WIN32_LEAN_AND_MEAN
#define XR_NO_PROTOTYPES
#include <windows.h>
#include <openxr/openxr.h>
#include <openxr/openxr_loader_negotiation.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define LAYER_NAME "XR_APILAYER_BOLT_exit_order"
typedef BOOLEAN (WINAPI *ShutdownFn)(void);
static ShutdownFn shutdown_in_progress;
static PFN_xrGetInstanceProcAddr next_gipa;
static PFN_xrCreateSession next_create_session;
static PFN_xrEndSession next_end_session;
static PFN_xrDestroySession next_destroy_session;
static PFN_xrDestroyInstance next_destroy_instance;
static XrInstance instance_owned;
static XrSession session_owned;
static int enabled, guard_enabled, test_host;
static HANDLE trace_file=INVALID_HANDLE_VALUE;
static DWORD owner_pid;
static volatile LONG sequence;

#pragma pack(push,1)
typedef struct {uint32_t magic,size,seq,pid,tid,event,api,shutdown;uint64_t tick,handle;int32_t result;} Trace;
#pragma pack(pop)
// event:1 init,2 enter,3 returned,4 process-exit rejection,5 DLL detach.
// api:1 createSession,2 endSession,3 destroySession,4 destroyInstance,0 layer.
// No CRT, heap, locks or dynamic module lookup on the process-exit branch.
static void record(uint32_t event,uint32_t api,uint64_t handle,int32_t result) {
    if(trace_file==INVALID_HANDLE_VALUE||sequence>=128)return;
    Trace t={0x42455854,sizeof(Trace),(uint32_t)InterlockedIncrement(&sequence),owner_pid,GetCurrentThreadId(),event,api,
        shutdown_in_progress?(uint32_t)shutdown_in_progress():0,GetTickCount64(),handle,result};
    DWORD got=0;WriteFile(trace_file,&t,sizeof t,&got,NULL);
}
static int authorize(void) {
    if(trace_file!=INVALID_HANDLE_VALUE&&owner_pid==GetCurrentProcessId())return 1;
    char exe[32768],path[32768],value[128],expected[128],mode[8];
    DWORD n=GetModuleFileNameA(NULL,exe,sizeof exe);if(!n||n>=sizeof exe)return 0;
    test_host=_stricmp(exe,"F:\\VRTools\\BoltgunVR\\Development\\exit-order-v1\\harness\\ExitBoundaryHost.exe")==0;
    if(!test_host&&_stricmp(exe,"F:\\Program Files (x86)\\Steam\\steamapps\\common\\Boltgun\\Boltgun\\Binaries\\Win64\\Boltgun-Win64-Shipping.exe"))return 0;
    n=GetEnvironmentVariableA("BOLT_XR_NONCE_FILE",path,sizeof path);if(!n||n>=sizeof path)return 0;
    FILE* f=fopen(path,"rb");if(!f)return 0;int ok=fgets(value,sizeof value,f)!=NULL;fclose(f);if(!ok)return 0;
    FILETIME c,e,k,u;ULARGE_INTEGER ticks;if(!GetProcessTimes(GetCurrentProcess(),&c,&e,&k,&u))return 0;
    ticks.LowPart=c.dwLowDateTime;ticks.HighPart=c.dwHighDateTime;owner_pid=GetCurrentProcessId();
    snprintf(expected,sizeof expected,"%lu:%llu",owner_pid,ticks.QuadPart+504911232000000000ull);
    value[strcspn(value,"\r\n")]=0;if(strcmp(value,expected))return 0;
    // Resolve while the process is alive, following dotnet/runtime's optional API lookup.
    HMODULE nt=GetModuleHandleW(L"ntdll.dll");shutdown_in_progress=nt?(ShutdownFn)GetProcAddress(nt,"RtlDllShutdownInProgress"):NULL;
    if(!shutdown_in_progress)return 0;
    n=GetEnvironmentVariableA("BOLT_EXIT_TRACE",path,sizeof path);if(!n||n>=sizeof path)return 0;
    trace_file=CreateFileA(path,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,NULL);
    if(trace_file==INVALID_HANDLE_VALUE)return 0;
    n=GetEnvironmentVariableA("BOLT_EXIT_GUARD",mode,sizeof mode);guard_enabled=n==1&&mode[0]=='1';
    return 1;
}
static int late_exit(void){return enabled&&guard_enabled&&shutdown_in_progress&&shutdown_in_progress();}
static XrResult XRAPI_CALL end_session(XrSession s) {
    record(2,2,(uint64_t)s,0);
    if(s==session_owned&&late_exit()){record(4,2,(uint64_t)s,XR_ERROR_INSTANCE_LOST);return XR_ERROR_INSTANCE_LOST;}
    XrResult r=next_end_session(s);record(3,2,(uint64_t)s,r);return r;
}
static XrResult XRAPI_CALL destroy_session(XrSession s) {
    record(2,3,(uint64_t)s,0);
    if(s==session_owned&&late_exit()){record(4,3,(uint64_t)s,XR_ERROR_INSTANCE_LOST);return XR_ERROR_INSTANCE_LOST;}
    XrResult r=next_destroy_session(s);record(3,3,(uint64_t)s,r);
    if(XR_SUCCEEDED(r)&&s==session_owned)session_owned=XR_NULL_HANDLE;return r;
}
static XrResult XRAPI_CALL destroy_instance(XrInstance i) {
    record(2,4,(uint64_t)i,0);
    if(i==instance_owned&&late_exit()){record(4,4,(uint64_t)i,XR_ERROR_INSTANCE_LOST);return XR_ERROR_INSTANCE_LOST;}
    XrResult r=next_destroy_instance(i);record(3,4,(uint64_t)i,r);
    if(XR_SUCCEEDED(r)&&i==instance_owned){instance_owned=XR_NULL_HANDLE;session_owned=XR_NULL_HANDLE;enabled=0;}
    return r;
}
static XrResult XRAPI_CALL create_session(XrInstance i,const XrSessionCreateInfo* info,XrSession* s) {
    record(2,1,(uint64_t)i,0);XrResult r=next_create_session(i,info,s);record(3,1,XR_SUCCEEDED(r)&&s?(uint64_t)*s:0,r);
    if(XR_SUCCEEDED(r)&&s&&i==instance_owned&&!session_owned)session_owned=*s;return r;
}
static XrResult XRAPI_CALL get_proc(XrInstance i,const char* name,PFN_xrVoidFunction* fn) {
    if(!name||!fn)return XR_ERROR_VALIDATION_FAILURE;
    if(!strcmp(name,"xrGetInstanceProcAddr")){*fn=(PFN_xrVoidFunction)get_proc;return XR_SUCCESS;}
    if(enabled&&i==instance_owned){
#define WRAP(n,f) if(!strcmp(name,n)){*fn=(PFN_xrVoidFunction)f;return XR_SUCCESS;}
        WRAP("xrCreateSession",create_session) WRAP("xrEndSession",end_session)
        WRAP("xrDestroySession",destroy_session) WRAP("xrDestroyInstance",destroy_instance)
#undef WRAP
    }
    return next_gipa?next_gipa(i,name,fn):XR_ERROR_FUNCTION_UNSUPPORTED;
}
static XrResult XRAPI_CALL create_instance(const XrInstanceCreateInfo* info,const XrApiLayerCreateInfo* chain,XrInstance* instance) {
    if(!info||!chain||!instance||!chain->nextInfo||chain->structType!=XR_LOADER_INTERFACE_STRUCT_API_LAYER_CREATE_INFO||
       chain->structVersion!=XR_API_LAYER_CREATE_INFO_STRUCT_VERSION||chain->structSize!=sizeof(*chain))return XR_ERROR_INITIALIZATION_FAILED;
    const XrApiLayerNextInfo* n=chain->nextInfo;
    if(n->structType!=XR_LOADER_INTERFACE_STRUCT_API_LAYER_NEXT_INFO||n->structVersion!=XR_API_LAYER_NEXT_INFO_STRUCT_VERSION||
       n->structSize!=sizeof(*n)||strcmp(n->layerName,LAYER_NAME)||!n->nextGetInstanceProcAddr||!n->nextCreateApiLayerInstance)return XR_ERROR_INITIALIZATION_FAILED;
    next_gipa=n->nextGetInstanceProcAddr;
    XrApiLayerCreateInfo forwarded=*chain;forwarded.nextInfo=n->next;
    XrResult r=n->nextCreateApiLayerInstance(info,&forwarded,instance);if(XR_FAILED(r))return r;
    if(instance_owned)return r;
    instance_owned=*instance;enabled=0;
    if(!authorize())return r;
#define RESOLVE(n,f) if(XR_FAILED(next_gipa(*instance,n,(PFN_xrVoidFunction*)&f))||!f)return r;
    RESOLVE("xrCreateSession",next_create_session) RESOLVE("xrEndSession",next_end_session)
    RESOLVE("xrDestroySession",next_destroy_session) RESOLVE("xrDestroyInstance",next_destroy_instance)
#undef RESOLVE
    enabled=1;record(1,0,(uint64_t)*instance,guard_enabled|(test_host?2:0));return r;
}
__declspec(dllexport) XrResult XRAPI_CALL xrNegotiateLoaderApiLayerInterface(const XrNegotiateLoaderInfo* l,const char* name,XrNegotiateApiLayerRequest* r) {
    if(!l||!name||!r||strcmp(name,LAYER_NAME)||l->structType!=XR_LOADER_INTERFACE_STRUCT_LOADER_INFO||
       l->structVersion!=XR_LOADER_INFO_STRUCT_VERSION||l->structSize!=sizeof(*l)||l->minInterfaceVersion>1||l->maxInterfaceVersion<1||
       l->minApiVersion>XR_CURRENT_API_VERSION||l->maxApiVersion<XR_MAKE_VERSION(1,0,0)||r->structType!=XR_LOADER_INTERFACE_STRUCT_API_LAYER_REQUEST||
       r->structVersion!=XR_API_LAYER_INFO_STRUCT_VERSION||r->structSize!=sizeof(*r))return XR_ERROR_INITIALIZATION_FAILED;
    r->layerInterfaceVersion=1;r->layerApiVersion=l->maxApiVersion<XR_CURRENT_API_VERSION?l->maxApiVersion:XR_CURRENT_API_VERSION;
    r->getInstanceProcAddr=get_proc;r->createApiLayerInstance=create_instance;return XR_SUCCESS;
}
BOOL WINAPI DllMain(HINSTANCE module,DWORD reason,LPVOID reserved) {
    if(reason==DLL_PROCESS_DETACH&&trace_file!=INVALID_HANDLE_VALUE){record(5,0,0,reserved?1:0);if(!reserved){CloseHandle(trace_file);trace_file=INVALID_HANDLE_VALUE;}}
    return TRUE;
}
