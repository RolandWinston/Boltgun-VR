-- User-requested physical weapon check. One-time native inventory setup; no input injection.
local api,hook=uevr.api,uevr.types.UObjectHook
local last=-100;local done={};local failed=false
local function valid(o)return o and hook.exists(o)end
uevr.sdk.callbacks.on_post_engine_tick(function()
 local now=os.clock();if failed or now-last<.4 then return end;last=now
 local pawn=api:get_local_pawn(0);if not valid(pawn)or done[pawn]or pawn:get_property('bPlayerFinishedLevelLoad')~=true then return end
 local ok,why=pcall(function()
  local pc=api:get_player_controller(0);local cm=pc:get_property('CheatManager');assert(valid(cm),'Native cheat manager unavailable')
  local completed={}
  for _,n in ipairs{'BGGiveAllWeapons','BGGiveAllGrenades'}do
   local fn=cm:get_class():find_function(n);assert(fn,n);local field=fn:get_child_properties()
   while field do local p=fn:find_property(field:get_fname():to_string());assert(not p or not p:is_param(),'Expected no-argument inventory function');field=field:get_next()end
   fn(cm);completed[#completed+1]=n
  end
  local settings=api:find_uobject('Class /Script/Boltgun.BGGameUserSettings'):get_class_default_object():GetBGGameUserSettings()
  assert(settings:GetPlayerInvulnerability()==true,'Invulnerability setting not active')
  done[pawn]=true;json.dump_file('weapon-test-ready.json',{at=now,pawn=pawn:get_full_name(),completed=completed,invulnerability=true,physical_input=true},-1)
 end)
 if not ok then failed=true;json.dump_file('weapon-test-error.json',{at=now,error=tostring(why)},-1)end
end)
